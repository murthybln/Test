# Datachecks

This repository contains the data checks configuration.

It is continuously built and deployed.

