DECLARE @dt DATETIME = GETDATE(), @dtwhole DATE = GETDATE();
DECLARE @sdate DATETIME = DATEADD(day,1,@dtwhole)
              , @edate DATETIME = DATEADD(day,0,@dtwhole);




SELECT Distinct
		sec.MasterSecID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) as PrimarySymbol
		,sp.SplitDate
		,sp.SplitFactor
		,sp.SplitTerm
		, Case when sp.IsStockDividend = 1 then 'StockDivided' else 'StockSplit' end as 'SplitType'
		,x.EntityGroup as 'HoldingsGroup'
	  ,Case when q.Symbol is null then 'N' else 'Y' end as 'InQuantUniverse' 
	  ,REPLACE(CONVERT(VARCHAR,CAST(x.NetQuantity AS MONEY), 1),'.00', '') as 'NetQuantity'
	 
	  

	
	  
FROM		SMGC.dbo.SecSplit sp
Join		smgc.dbo.sec sec
on			sec.secid = sp.secid
Left Join	lsQuanSQL.Quant2.dbo.QuantUniverse q
on			q.Symbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 

	 Left Join 
				(Select 
							
							t.PrimarySymbol,
							t.EntityGroup,
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									tl.EntityCode,
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol',
									Case when EntityCode in ('LDC','USA','LEV','ELF','BUL','M02','MVK') then 'AMAV'
										 When EntityCode in ('MFN','MFQ','UCQ','QSL','QSN') then 'Quant'
										 When EntityCode in ('CGE') then 'CGE'
										 else 'NotAssigned'
										 end as 'EntityGroup'	

							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @dtwhole) t

							Group by 
									
									t.PrimarySymbol,
									t.EntityGroup) x
		on x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 
		
	 
   
Where	sp.SplitDate = @edate
and		(EntityGroup is not null )
--and		SplitTerm is not null

order by 3


