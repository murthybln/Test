DECLARE @dt DATETIME = GETDATE(), @dtwhole DATE = GETDATE();
DECLARE @sdate DATETIME = DATEADD(day,0,@dtwhole)
              , @edate DATETIME = DATEADD(day,0,@dtwhole);


SELECT    Distinct
            sec.MasterSecID
			,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) as 'PrimarySymbol'
			,Replace(Replace(replace(RTRIM(d.CP_TKR),' ','.'),'.GR','.GY'),'.US.','') as 'Spin-Off Ticker'
			,CONVERT(VARCHAR(10),Cast(d.Eff_date as Date),101) as 'EffectiveDate'
			--,CONVERT(VARCHAR(10),Cast(d.Amd_date as Date),101) as 'AmendmentDate'
           -- ,CONVERT(VARCHAR(10),Cast(d.CP_PAY_DT as Date),101) as 'PaymentDate'
           -- ,CONVERT(VARCHAR(10),Cast(d.CP_RECORD_DT as Date),101) as 'RecordDate'
			,d.CP_SPINOFF_NAME
			,d.CP_RATIO
			,d.CP_ADJ
		    ,x.EntityGroup
			,Case when q.Symbol is null then 'N' else 'Y' end as 'InQuantUniverse'
			,x.NetQuantity
			
FROM          smgc.dbo.sec sec
JOIN          BBGSecMaster.dbo.EQUITY_DESCRIPTIVE bbg on bbg.ID_BB_GLOBAL = isnull(smgc.dbo.fn_GetActualIdentifier (sec.SecId, 666675, @dt),smgc.dbo.fn_GetActualIdentifier (sec.SecId, 300110, @dt))
JOIN          [BBGSecMaster].[dbo].[SPIN] d  on d.ID_BB_GLOBAL = bbg.ID_BB_GLOBAL
Left Join 
				(Select 
							
						
							t.PrimarySymbol,
							t.EntityGroup,
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol',
									Case when EntityCode in ('LDC','USA','LEV','ELF','BUL','M02') then 'AMAV'
										 When EntityCode in ('MFN','MFQ','UCQ','QSL','QSN') then 'Quant'
										 When EntityCode in ('CGE') then 'CGE'
										 else 'NotAssigned'
										 end as 'EntityGroup'	

							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @dtwhole) t

							Group by 
									
																
									t.PrimarySymbol,
									t.EntityGroup) x
on				x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 
Left Join		lsQuanSQL.Quant2.dbo.QuantUniverse q
on				q.Symbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 

CROSS APPLY (SELECT        TOP 1 *
                     FROM          [BBGSecMaster].[dbo].[SPIN]  s
                     WHERE         s.ID_BB_GLOBAL = d.ID_BB_GLOBAL
                     AND                  s.Eff_date Between @sdate and @edate
                     ORDER BY      s.CreateDate DESC) mx
WHERE			d.Eff_Date = @edate 
AND				d.CreateDate = mx.CreateDate
AND				d.ID_BB_GLOBAL = mx.ID_BB_GLOBAL
And				x.EntityGroup is not null