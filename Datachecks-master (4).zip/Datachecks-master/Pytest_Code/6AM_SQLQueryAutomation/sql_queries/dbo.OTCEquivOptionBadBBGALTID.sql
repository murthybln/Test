Select 
		a.Sec_Code,
		a.MasterSecID,
		a.GLOBAL_ID,
		a.BBG_ALT_ID,
		a.LegalEntityUDFGroupID,
		a.OptionStrikePrice,
		a.OptionRedemType,
		a.OptionExpirationDate,
		idlisted.GLOBAL_ID as 'Listed_GlobalID',
		idlisted.BBG_ALT_ID as 'Listed_BBG_ALT_ID',
		idlisted.LegalEntityUDFGroupID as 'Listed_GroupID',
		idlisted.OptionStrikePrice as 'Listed_StrikePrice',
		idlisted.OptionRedemType as 'Listed_RedemType',
		idlisted.OptionExpirationDate as 'Listed_ExpirationDate',
		idlisted.TradingStatus




FROM		smgc.dbvw.SecurityBuilder a with (nolock)
LEFT JOIN	smgc.dbvw.SecurityBuilder idlisted with (nolock)
ON			idlisted.GLOBAL_ID = a.BBG_ALT_ID
and			idlisted.InvestmentType = 'LOPT'

where		a.InvestmentType = 'OOTC'
and			a.TradingStatus not in ('Expired','Expired_old')
and			a.OptionExpirationDate > GetDate()
and			a.BBG_ALT_ID is not null
and			(idlisted.GLOBAL_ID is null
				or	idlisted.LegalEntityUDFGroupID <> a.LegalEntityUDFGroupID
				or	idlisted.OptionExeciseType <> a.OptionExeciseType
				or	idlisted.OptionRedemType <> a.OptionRedemType
				or	idlisted.OptionExpirationDate <> a.OptionExpirationDate)
