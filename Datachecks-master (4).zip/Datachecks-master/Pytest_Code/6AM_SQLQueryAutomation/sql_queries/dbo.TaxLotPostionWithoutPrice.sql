SELECT 
      HistDate,
	  EntityCode,
	  Symbol,
	  Price,
	  Sum(Quantity) as 'Quantity'
     
  FROM Mav.dbo.TaxLotPositionHistView
  where HistDate =(select max(HistDate) from Mav.dbo.TaxLotPositionHistView)
  and Price = 0 and MarketValue = 0
  and Symbol not in ('HEALTHMINECOM','HEALTHMINECOMWTS','BEST.SP','FRESHDE','ROBEKSCOM','FRESHD','FRESHM','UPSIGHTCOM','FRESHCOM','ZENEFITSA1','FRESHL','ROBEKSB','ROBEKSA','UPSIGHT3','UPSIGHT2P','UPSIGHT1A','ZENEFITSCOM','ZENEFITSCOMYC','ZENEFITSA1YC','LGFTY','CSLT_R031224C16O','PROCUREBOND','ROBEKWTSD','1005722Q','MICRORYZA','LETOTEAA','LETOTECOM','0391301C.KSBLLT','DECENTS1','DECENTTKNRTS','FITONCOMWTS','REMRISELN','ZENREACHCOMWTS','ZENREACHCOMWTS2','ZENREACHCOMWTS3','ZENREACHCOMWTS4','ZZZSSEED1','ABMDCVR','DECENTA','DECENTA1')
  and Symbol not like 'KRW%'
  and EntityCode not in ('MAF','MPO')
  and Quantity <> 0
  Group by HistDate,
	  EntityCode,
	  Symbol,
	  Price
