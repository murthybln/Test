DECLARE @dt as Date = GetDate()-1
SELECT 
      
      Description
	  ,Code
      ,StartDate
      ,EndDate
      ,ReportingStartDate
      ,ReportingEndDate
  FROM Polaris.dbo.Polaris_Ref_Strategy pl

  where EndDate >= @dt
  and pl.Code not in ('GenevaStrategy','LCN','LNS','M03','QELOVER','SEL','TPQ')
  and pl.Code not in (Select Code from lsBOBISQL.ReferenceData.mdm.Strategy)
