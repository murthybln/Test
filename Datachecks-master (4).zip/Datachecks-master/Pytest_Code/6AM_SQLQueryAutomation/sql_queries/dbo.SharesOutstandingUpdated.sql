Declare @SD as Date = GetDate() -1
Declare @ED as Date = GetDate() 

-- SharesOutstanding Changed
-- Daily
--Sev2

Select distinct
     rec.MasterSecId
	 ,rec.Seccode
     ,ms.[ChangeDate]
      ,ms.SharesOut
	  ,ms.SharesOutDate
	  
FROM		[AuditSMGC].[dbo].[Audit_SecEquityIssue] ms
join		smgc.dbo.sec sec 
on			sec.secid = ms.secid
Left Join	smgc.client.reconview rec 
on			rec.MasterSecID = sec.MasterSecID
where		ms.ChangeDate > @SD
and			SharesOutDate > @SD
order by 3 desc