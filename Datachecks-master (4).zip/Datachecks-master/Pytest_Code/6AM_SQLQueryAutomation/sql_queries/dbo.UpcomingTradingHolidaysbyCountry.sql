-- Upcoming Trading Holidays by Country
-- Daily
-- Sev 4


SELECT 
		cty.CountryCode
		,cty.Country
		,mic.MIC
		,c.TYPE
		,HolidayDate
		
FROM		Mav.FinancialCalendar.Holidays h
Join		Mav.FinancialCalendar.Centers c
on			c.ID = h.CenterID
Join		mav.dbo.Country cty
on			cty.CountryCode = c.ISOCOUNTRY
Left Join	Mav.FinancialCalendar.MICMappings mic
on			mic.code = c.code
Where		HolidayDate between GetDate() and GetDate()+10
and			c.Type in ('SE Trading','SE Settlement')
and			datepart(DW,h.HolidayDate) not in (1,7)
and			cty.CountryCode not in ('KW','QA','BH','KE','NG')
order by	HolidayDate,cty.CountryCode