SELECT PortfolioCode
      ,PeriodStart
      ,PeriodEnd
      ,KnowledgeDate
  FROM Polaris.dbo.Polaris_DataSanity_WrongKD