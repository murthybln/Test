-- End of Day Price Differences HS vs Mav
-- End of Day
-- Sev 2

DECLARE @sd AS Date = GetDate() -1
DECLARE @ed AS Date = GetDate() -1



SELECT
			Distinct
			convert(DateTime,hs.dayid,103) as 'HistDate'
			
		   ,sm.IdCode as 'MasterSecID'
			,si.IdCode as 'SecCode'
			--,s.Name as 'SecurityName'
		    ,it.Description as 'InvestmentType'
			,cur.IsoCode as 'CurrencyCode'
			,rec.PvtType
			,HS.value as 'HS_LocalPrice'
			,isnull(mav.value,0) as 'Mav_LocalPrice'
			,hs.value-isnull(mav.value,0) as 'LocalPrice_Diff'
			,Case when mav.value= 0 or mav.value is null or hs.value = 0.000000000000000 or hs.value is null
			 then 1 else hs.value/mav.value-1 end *100 as 'Pct_Diff'
			
			
			
  FROM				[PriceMaster].[MarketValue].[Data_HS_EOD35_price] HS with (nolock)
	   Left Join	[PriceMaster].[MarketValue].[Data_RefSrc1_Price_Local] MAV with (nolock)
	   on			mav.SecID = hs.secID
	   and			hs.dayid = mav.dayid
	   Left Join	PriceMaster.dbo.sec s 
	   on			s.SecId = hs.SecID
	   Left Join	PriceMaster.dbo.SecId si 
	   on			si.SecID = hs.SecID  and si.SecIdTypeId = '30010'
	   Left Join	PriceMaster.dbo.SecId sm 
	   on			sm.SecID = hs.secID and sm.SecIdTypeId = '30007'
	   Left Join	PriceMaster.dbo.SecId gb 
	   on			gb.SecID = hs.SecID and gb.SecIdTypeId = '30035'
	   Left Join	PriceMaster.dbo.InvestmentType it 
	   on			it.InvestmentTypeID = s.InvestmentTypeID
	   Left Join	PriceMaster.dbo.sec SecCurr
	   on			SecCurr.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else s.secid end
	   Left Join	PriceMaster.dbo.Currency cur 
	   on			cur.CurrencyId = SecCurr.CurrencyId
	  Join			smgc.client.ReconView rec with (nolock)
	   on			rec.MasterSecID = sm.IdCode

Where convert(DateTime,hs.dayid,103) = @ed
and  Abs(hs.value-isnull(mav.value,0)) > .001
and it.Description not in ('Currency','FX Forward','FX Forward Hedge')
and hs.value is not null
--and si.IdCode not in ('ROBEKSLOAN','1820037D.NA')
order by 1,4