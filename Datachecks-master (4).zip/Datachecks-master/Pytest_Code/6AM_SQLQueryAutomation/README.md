This job is scheduled to run at 6am daily.
