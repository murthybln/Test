import os
import socket
import traceback

import database_results as dr
import json_reader as jr
import send_email as ft
import sql_file_reader as sqlld
import csv_writer as cw


def test_datacheck(sql, job_name, db_name, severity, confluence_link, emails, err_msg, support_emails, summary_report, csv_name):
    abs_path = os.path.dirname(os.path.realpath(__file__))
    job_dir = os.path.join(abs_path, job_name)
    hostname = socket.gethostname()
    actual_result = 1
    result_df = "Runtime Error: Please check the logs for more information"
    try:
        query_list = []
        checks = jr.json_reader(dir=abs_path, filename="config.json")
        support_emails = support_emails if support_emails else checks["support_emails"]
        sql_query = sqlld.load_sql_from_file(file_path=os.path.join(job_dir, "sql_queries"), filename=sql)
        result_df = dr.get_db_data(db_conn=checks["db_conn"][db_name], query=sql_query)
        actual_result = len(result_df)
        query_list.append(result_df)
        email_merge = '{},{}'.format(checks["emails"], emails) if emails else checks["emails"]
        error_, severity_, confluence_link, receiver = err_msg, severity, '<b> Confluence Link: {0}'.format(confluence_link), ','.join(set(email_merge.lower().split(',')))
        err_msg = "Datacheck - {0} ({1})".format(error_, severity_)
        if summary_report:
            cw.write_to_csv(result_df, os.path.join(job_dir, "csv_files"), csv_name, sep=',', conf_link=confluence_link) if actual_result else ''
        ft.send_email(ft.generate_html(query_list[0].to_html(), err_msg, confluence_link), err_msg, receiver) if actual_result else ''
    except Exception as ex:
        job_info = "<b>Job_name:</b> {0} <br> <b>sql_name:</b> {1}<br> <b>db_name:</b> {2}<br> <b>hostname:</b> {3}<br>".format(job_name, sql, db_name, hostname)
        ft.send_error_email(job_info=job_info, traceback=traceback.format_exc(), sql_query=sql_query if sql_query else "Unable to find the {0} sql file".format(sql), subject="[Datachecks] Runtime Error - {0}".format(err_msg), receiver=support_emails)

    assert actual_result == 0, "{0}\n {1}".format(err_msg, result_df) if actual_result else "Need to contact the Support team to investigate on the issue"
