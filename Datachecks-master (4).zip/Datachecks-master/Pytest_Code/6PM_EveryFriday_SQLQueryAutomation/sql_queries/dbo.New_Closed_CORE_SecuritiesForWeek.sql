Declare @sd  as Date = DATEADD(wk, DATEDIFF(wk,0,GETDATE()), -1)
Declare @ed as Date = GetDate()+1
Declare @new_pos_cnt INT, @closed_pos_cnt INT

SET NOCOUNT ON;
IF OBJECT_ID('tempdb..#new_Closed_positions') IS NOT NULL 
BEGIN 
    DROP TABLE #new_Closed_positions 
END

Select      Isnull(m.PrimarySymbol,f.PrimarySymbol) as 'PrimarySymbol',
			Isnull(m.Qty,0) as 'StartingQty',
			isnull(f.Qty,0) as 'EndingQty',
			--Isnull(f.Qty,0) -isnull(m.Qty,0) as 'ChangeQty',
			Case when m.qty is null then 'New Position' else 'Closed Position' end as 'Type'
into #new_Closed_positions		
from

(SELECT 
	    AsOfDate as 'HistDate'
       ,PrimarySymbol
		,sum(NetQuantity) as 'Qty'
FROM	lsplrssql.Polaris.dbo.Polaris_PositionPnLBookDeNormalized
where	Portfolio Not in ('LDC','USA')
and		stratcode in ('LEV','LDC','USA')
and		(secgenevaassettype not in ('Cash') or secinvestmenttypecode = 'FXOP')
and		AsOfDate = @sd
and		NetQuantity <> 0
Group by AsOfDate,PrimarySymbol) m

Full outer Join


(SELECT 
       HistDate
      ,c.PrimarySymbol
      ,sum(Quantity) as 'Qty'
      
FROM		Mav.dbo.TaxLotPositionHist tl
Left Join	mav.dbo.InvestmentView c 
on			c.Symbol = tl.Symbol
Where		Strategy in ('LDC','USA','LEV','MVK')
and			tl.HistDate = @ed
Group by	c.PrimarySymbol, tl.HistDate) f
on			f.PrimarySymbol = m.PrimarySymbol

where		m.qty is null or f.qty is null

order  by 4,1

select @new_pos_cnt = COUNT(1) FROM #new_Closed_positions WHERE Type = 'New Position'
select @closed_pos_cnt = COUNT(1) FROM #new_Closed_positions WHERE Type = 'Closed Position'

IF (@new_pos_cnt = 0 AND @closed_pos_cnt = 0)
BEGIN
SELECT 'None' as 'PrimarySymbol',NULL as 'StartingQty',NULL as 'EndingQty','Closed Position' as 'Type'
UNION ALL
SELECT 'None' as 'PrimarySymbol',NULL as 'StartingQty',NULL as 'EndingQty','New Position' as 'Type'
END
ELSE IF (@closed_pos_cnt = 0 AND @new_pos_cnt > 0)
BEGIN
SELECT * FROM #new_Closed_positions
UNION ALL
SELECT 'None',NULL,NULL,'Closed Position'
END
ELSE IF (@closed_pos_cnt > 0 AND @new_pos_cnt = 0)
BEGIN
SELECT * FROM #new_Closed_positions
UNION ALL
SELECT 'None',NULL,NULL,'New Position'
END
ELSE
BEGIN
SELECT * FROM #new_Closed_positions
END
