select    Mastersecid, count(*) as 'NumberGICS' FROM    smgc..Sec s    
JOIN    smgc..[vwSecAttributeActive] sa on sa.secid = s.secid and sa.customattributeid = 6 --watchlist
JOIN    smgc.client.gics g on g.LegalEntityID = s.LegalEntityID
GROUP BY    mastersecid
HAVING COUNT(*) > 1