SELECT Distinct 
	   a.MasterSecID
       ,a.SecCode     
	   ,a.TradingStatus

	   ,a.AssetType
	   ,a.InvestmentType
	   ,a.TradingStatus
	   ,Custattr.Name
	   ,attr.CustomAttributeID
	   --,attr.InDate
	   --,attr.OutDate

FROM SMGC.client.ReconView a
Left Join	smgc.dbo.sec sec 
on			sec.mastersecid = a.MasterSecID
Left Join	SMGC.dbo.SecAttribute attr
on			attr.SecID = sec.SecID
Left Join SMGC.dbo.CustomAttribute CustAttr
on CustAttr.CustomAttributeID = attr.CustomAttributeID
Where attr.CustomAttributeID in ('24')
and attr.OutDate is null
--and InvestmentType not in ('TRS','BLLT')
and attr.SecID in
	 (Select SecId from SMGC.dbo.SecAttribute
		where CustomAttributeID in ('27') 
		and OutDate is null)