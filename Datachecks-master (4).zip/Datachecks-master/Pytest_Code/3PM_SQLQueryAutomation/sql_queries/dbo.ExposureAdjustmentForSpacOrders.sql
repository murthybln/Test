Declare @dt as Date = GetDate()
SELECT		
			sb.Sec_Code as 'PrimarySymbol', 
			max(sb.ExposureAdjustment) as 'ExposureAdjustment',
			sum(op.Quantity) as 'OpenQty'

FROM		lsTradSQL.MaverickFlexTrade.dbo.CurrentSymbols cs with (nolock)
Left Join	lspaldsql.smgc.dbvw.SecurityBuilder sb with (nolock)
on			sb.Sec_Code = cs.cord_symbol
Left Join	mav.dbo.AllocationOpeningPositionsByFund op
on			op.Symbol = sb.Sec_Code
and			op.HistDate = @dt
		

where		sb.IsSpac = 1
and			datepart(dw,op.HistDate) Not In (1,7) 
group by	sb.Sec_Code

Having abs(sum(isnull(op.Quantity,0))) < 1

