-- End of Day Price Differences Mav vs Bloomberg Close Price
-- End of Day
-- Sev 1

DECLARE @ed AS Date = GetDate()


SELECT
		Distinct
		convert(DateTime,bc.dayid,103) as 'HistDate'
		,sm.IdCode as 'MasterSecID'
		,si.IdCode as 'SecCode'
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300090,GetDate()) as BBG_ALT_ID
		,it.Description as 'InvestmentType'
		,cur.IsoCode as 'CurrencyCode'
		,bc.value as 'Bloomberg_Closing_Price'
		,mav.value as 'Mav_LocalPrice'
		,isnull(bc.value,0) - isnull(mav.value,0) as 'Price_Difference'
FROM		PriceMaster.MarketValue.Data_RefSrc1_Price_Local mav with (nolock)
Left Join	PriceMaster.MarketValue.Data_RefSrc1_BLOOMBERG_CLOSE_PRICE_LOCAL bc with (nolock)
on			mav.SecID = bc.secID
and			bc.dayid = mav.dayid
Left Join	PriceMaster.dbo.sec s 
on			s.SecId = bc.SecID
Left Join	PriceMaster.dbo.SecId si 
on			si.SecID = bc.SecID  and si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = bc.secID and sm.SecIdTypeId = '30007'
Left Join	PriceMaster.dbo.SecId gb 
on			gb.SecID = bc.SecID and gb.SecIdTypeId = '30035'
Left Join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Left Join	PriceMaster.dbo.sec SecCurr
on			SecCurr.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else s.secid end
Left Join	PriceMaster.dbo.Currency cur 
on			cur.CurrencyId = SecCurr.CurrencyId
Join		smgc.dbo.sec sec
on			sec.mastersecid = sm.IdCode
Where		convert(DateTime,bc.dayid,103) = @ed
and			Abs(isnull(bc.value,0)-isnull(Mav.value,0)) > .001
and			Sec.SecID in 
			(
				select Distinct SecID
				from	SMGC.dbo.SecAttribute 
				where	CustomAttributeID in(18,24,30,31) 
				and	OutDate is null
			)
and			si.IdCode not in ('WDI.GR')

