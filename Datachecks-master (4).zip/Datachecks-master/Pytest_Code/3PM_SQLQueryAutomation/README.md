This job is scheduled to run at 3pm daily.
