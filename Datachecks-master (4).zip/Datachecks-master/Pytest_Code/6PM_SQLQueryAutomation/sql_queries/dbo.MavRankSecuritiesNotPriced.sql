DECLARE @DT AS DATE = GETDATE()


SELECT		Distinct
			ss.Symbol,
			pl.value as 'Price_Local'
			
FROM		mav.dbo.StockStats ss with (nolock)
left Join	lspaldsql.PriceMaster.dbo.SecId si 
on			si.IdCode = ss.Symbol 
and			si.SecIdTypeId = '30010'
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_Price_Local pl
on			pl.SecID = si.secid 
and			convert(DateTime,pl.dayid,103)  = @DT
WHERE		SaveDate >= DATEADD(MONTH,-3,GetDate()) 
and			pl.value is null 
and			datepart(dw,@dt) not in (1,7)
and			si.IdCode is not null
and			ss.symbol not in ('MLNX')
order by 1
