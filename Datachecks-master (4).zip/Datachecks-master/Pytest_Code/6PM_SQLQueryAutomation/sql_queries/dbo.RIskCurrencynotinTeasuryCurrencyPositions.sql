
Select 
Distinct
Sec_Code,
RiskCurrency


from smgc.dbvw.RiskFields a with (nolock)
where a.RiskCurrency COLLATE SQL_Latin1_General_CP1_CI_AS  not in (Select Currency_ISOCode from lsmavgsql.Treasury.dbo.TreasuryCurrency with (nolock))
and	  a.IsCurrentPosition = 'Yes'
and InvestmentType not in ('CCY','TRS','BLLT','RATE')
and TradingStatus = 'Active'
