Declare @dt as Date = GetDate()
SELECT
			Distinct
			 pr.Date [HistDate]
			,sm.IdCode [MasterSecID]
			,si.IdCode [SecCode]
			,s.Name [SecurityName]
			--,it.Description [InvType]
			,ISNULL(ritm.Value, rit.Code) InvestmentType
			--,it.code 
		    ,PVTType.code [PVTType]
			,min(HS.value) as 'HS_Price'
			,min(loc.Value) as 'Mav_Price'
			,isnull(min(hs.value),0)-isnull(min(loc.value),0) as 'HS_MAV_Price_Diff' 
			,min(bc.value) as 'Bloomberg_Close_Price'
			,isnull(min(hs.value),0)-isnull(min(bc.value),0) as 'HS_BB_Price_Diff' 
			,isnull(min(bc.value),0)-isnull(min(loc.value),0) as 'BB_MAV_Price_Diff'
			
FROM		PriceMaster.dbo.vSecPositionData pr
Left Join	PriceMaster.dbo.sec s 
on			PR.SecId = s.secid 
Left Join	PriceMaster.dbo.SecId si 
on			si.SecID = pr.SecID 
and			si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = pr.SecID 
and			sm.SecIdTypeId = '30007'
Left Join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Left Join	PriceMaster.MarketValue.Data_HS_EOD35_price HS 
on			hs.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end 
and			convert(DateTime,hs.dayid,103) = pr.date
Left Join	PriceMaster.MarketValue.Data_RefSrc1_Price_Local loc 
on			loc.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end 
and			convert(DateTime,loc.dayid,103) = pr.date
Left Join	Smgc.dbo.Sec sec 
on			sec.MasterSecID = sm.IdCode
Left Join	smgc.dbo.SecAuxCustomValues aux 
ON			sec.SecID = aux.SecID 
LEFT JOIN	smgc.dbo.RefInvestmentType rit 
ON			aux.RefInvestmentTypeID = rit.RefInvestmentTypeID 
LEFT JOIN	smgc.dbo.RefInvestmentTypeCode ritm 
ON			rit.RefInvestmentTypeID = ritm.RefInvestmentTypeID 
AND			ritm.RefExternalCodeTypeID = 2 



Left Join	PriceMaster.MarketValue.Data_RefSrc1_BLOOMBERG_CLOSE_PRICE_LOCAL bc with (nolock)
on			pr.SecID = bc.secID
and			convert(DateTime,bc.dayid,103) = pr.date
outer apply	(
			SELECT		TOP 1 li.*
			from		smgc.[dbo].[UDF_PrivateType_1] udf 
			JOIN		smgc.dbo.UdfListItem li 
			ON			udf.[PVTType$Integer] = li.UdfListItemID 
			WHERE		isnull([PVTTypeDate$Date],getdate()-1) <= getdate()
			AND			sec.SecID = udf.SecID
			order by	ISNULL(DATEDIFF(dd,[PVTTypeDate$Date],getdate()),9999999) ASC
			) PVTTYpe 
join		PriceMaster.dbo.fund f 
on			f.fundid = pr.fundid
where		pr.date = @dt
and			it.code not in ('wrnt','FXOP','FXFW','HEDGE','CCY','TRS','BLLT','RGHT','OOTC','COMMON_R','LOPT','SWOP','CMSV','CDS','CDX','MMKT')
and			ISNULL(ritm.Value, rit.Code) in ('ADR','COMMON','ETF','UNIT','REIT')

and			si.IdCode  not in ('SCHALLOCATION','LGFTY','ROBEKSLOAN')
and			f.FundName not in ('MAF','MPO')

and			abs(isnull(hs.value,0) -isnull(loc.value,0)) > .00001
and			loc.Value is not null 
and			hs.value is not null
and			PVTTYpe.code not like 'Pvt%'

Group by    pr.Date
			,sm.IdCode 
			,si.IdCode
			,s.Name 
			,it.Description
			,it.code 
		    ,PVTType.code
			,ISNULL(ritm.Value, rit.Code)
Having 		abs(sum(pr.Quantity)) > 1
Order by 5