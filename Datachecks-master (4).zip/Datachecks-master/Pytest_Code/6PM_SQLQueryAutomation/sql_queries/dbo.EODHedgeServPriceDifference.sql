 -- End of Day
 -- Sev 2
 
 DECLARE @ed AS Date = GetDate()
 Select Distinct
		HistDate
		,MasterSecID
		,SecCode
		,InvestmentType
		,PvtType
		,HS_LocalPrice
		,round(Mav_LocalPrice,9) 'Mav_LocalPrice' 
		,REPLACE(CONVERT(VARCHAR,CAST(ROUND(LocalPrice_Diff,6) AS MONEY), 1),'.000', '') as 'LocalPrice_Diff'
		,REPLACE(CONVERT(VARCHAR,CAST(ROUND(Pct_Diff,6) AS MONEY), 1),'.000', '') as 'Pct_Diff'
		,ABS(REPLACE(CONVERT(VARCHAR,CAST(ROUND(Pct_Diff,6) AS MONEY), 1),'.000', '')) as 'ABS_Pct_Diff'
	--,TolarencePctLevel
		,TradingStatus
	/*	,Case 
			When TolarencePctLevel = 0.00 then 'N'
			When TolarencePctLevel is null then 'N'
			when Abs(Pct_Diff) < TolarencePctLevel then 'Y'
			else 'N'
			end as 'UpdatePrice'
 */
 from
		(SELECT
					Distinct
					convert(DateTime,hs.dayid,103) as 'HistDate'
					,sm.IdCode as 'MasterSecID'
					,sb.SecCode as 'SecCode'
			--		,sb.BBG_ALT_ID
 					,sb.InvestmentType as 'InvestmentType'
					,sb.PvtType
					,HS.value as 'HS_LocalPrice'
					,isnull(mav.value,0) as 'Mav_LocalPrice'
					,hs.value-isnull(mav.value,0) as 'LocalPrice_Diff'
					,Case when mav.value= 0 or mav.value is null or hs.value = 0.000000000000000 or hs.value is null
					 then 1 else hs.value/mav.value-1 end *100 as 'Pct_Diff'
					,sb.TradingStatus
					,tl.ToleranceLevel * 100 as 'TolarencePctLevel'
			
 			
 			
		FROM		[PriceMaster].[MarketValue].[Data_HS_EOD35_price] HS with (nolock)
		Left Join	[PriceMaster].[MarketValue].[Data_RefSrc1_Price_Local] MAV with (nolock)
		on			mav.SecID = hs.secID
		and			hs.dayid = mav.dayid
		Left Join	PriceMaster.dbo.sec s 
		on			s.SecId = hs.SecID
		Left Join	PriceMaster.dbo.SecId sm
		on			sm.SecID = hs.SecID  
		and			sm.SecIdTypeId = '30007'
		Left Join	smgc.Client.Reconview sb
		on			sb.MasterSecID = sm.IdCode 
		Left Join   SMGC.dbo.UDF_RefPriceToleranceByInvType tl
		on			tl.code = sb.InvestmentType
		Where		convert(DateTime,hs.dayid,103) = @ed
		and			Abs(hs.value-isnull(mav.value,0)) > .0000001
		and			hs.value is not null
		and			sb.InvestmentType not in ('FDWFX','HEDGE','MAVFUND') 
		--and			mav.value is not null
		) x
Where x.MasterSecID not in ('1443021','1288517')

