Declare @dt as Date = GetDate() 
Declare @pd as Date =  Case when (datepart(dw,@dt)) = 2 then DATEADD(day, -3, CAST(GETDATE() AS date)) else DATEADD(day, -1, CAST(GETDATE() AS date)) end

Select 
		x.HistDate,
		x.MasterSecID,
		x.SecCode,
		x.LegalEntityID,
		REPLACE(CONVERT(VARCHAR,CAST(ROUND(x.SharesOut_Prior,0) AS MONEY), 1),'', '') as 'ShareOut_Prior',
		REPLACE(CONVERT(VARCHAR,CAST(ROUND(x.SharesOut,0) AS MONEY), 1),'', '') as 'SharesOut',
		REPLACE(CONVERT(VARCHAR,CAST(ROUND(x.SharesOutDiff,0) AS MONEY), 1),'', '') as 'SharesOutDiff',
		REPLACE(CONVERT(VARCHAR,CAST(ROUND(x.PctDiff,0) AS MONEY), 1),'', '') as 'PctDiff',
		
		x.InvType

from



(SELECT
								
			convert(DateTime,os.dayid,103) [HistDate]
		   ,sm.IdCode [MasterSecID]
			,si.IdCode [SecCode]
			,sec.LegalEntityID
			,aos.value *1000000 as [SharesOut_Prior]
			,os.value*1000000 [SharesOut]
			,os.value*1000000 - aos.value *1000000 as 'SharesOutDiff'
		    ,(os.value*1000000 - aos.value *1000000 ) /(aos.value *1000000) * 100 as 'PctDiff'
			,it.Description [InvType]
			
			
			
FROM		[PriceMaster].[MarketValue].[Data_BBG3_EQY_SH_OUT_ACTUAL] os
Left Join	[PriceMaster].[MarketValue].[Data_BBG3_EQY_SH_OUT_ACTUAL] aos
on			convert(DateTime,aos.dayid,103) = @pd
and			aos.secid = os.secid
Join		PriceMaster.dbo.sec s 
on			s.SecId = os.SecID
Join		PriceMaster.dbo.SecId si 
on			si.SecID = os.SecID  
and			si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = os.secID 
and			sm.SecIdTypeId = '30007'
left join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Left Join	PriceMaster.dbo.sec SecCurr
on			SecCurr.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else s.secid end
Left Join	PriceMaster.dbo.Currency cur 
on			cur.CurrencyId = SecCurr.CurrencyId
Left Join	smgc.dbo.sec sec
on			sec.MasterSecID = sm.IdCode
Where		convert(DateTime,os.dayid,103) = @dt
and			sm.IdCode is not null
and			aos.value is not null
and			abs(os.Value - aos.Value) > 1
and			abs((os.value*1000000 - aos.value *1000000 ) /(aos.value *1000000) * 100) > 5

) x
Where x.LegalEntityID in (Select Distinct INTERNAL_SECURITY_LEGALENTITY_ID from smgc.dbvw.CurrentPositions) 


order by abs(x.PctDiff) desc