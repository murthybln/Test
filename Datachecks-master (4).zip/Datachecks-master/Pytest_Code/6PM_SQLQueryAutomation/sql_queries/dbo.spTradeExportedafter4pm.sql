DECLARE @dt DATE = GETDATE()

SELECT 
	Distinct 
	a.HistDate, 
	a.InvestmentSymbol, 
	a.TradeType, 
	a.FundEntityCode, 
	a.CustodianCode, 
	a.RollupTradeExecutingBrokerCode [BrokerCode],
	a.IsExported,
	tr.TraderLogin
	
	
FROM Mav.dbo.AllocationsView a
	join mav.dbo.Traders tr on tr.TraderId = a.TraderId


WHERE a.HistDate = @dt and datepart(hh, CreateTime) > 17 and IsExported = 1
and tr.TraderID <> 7
