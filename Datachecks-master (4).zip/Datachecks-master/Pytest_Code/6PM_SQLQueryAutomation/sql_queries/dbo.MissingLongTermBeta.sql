-- Missing Long Term Beta for Tax Lot Holdings
-- Daily 
-- Sev 2

DECLARE @dt DATE = GETDATE()


select 
		
			distinct 
			@dt as 'PriceDate',
			s2.PrimarySymbol as Symbol , 
			--s2.SecCode,
			s2.Country, 
			s2.TradingZone,
		--	s2.InvestmentType,
			s2.TradingStatus,
			Case When hc.Country is null then 'No' else 'Yes' end as 'IsTradingHoliday',
			pl.value [Price_Local],
			b.value [LongTermBeta]
		
from		mav.dbo.TaxLotPositionHist s1 with (nolock) 	
Left Join	lsPALDSQL.smgc.client.reconview s2 with (nolock)
on			s2.SecCode = s1.Symbol 
left Join	lspaldsql.PriceMaster.dbo.SecId si 
on			si.IdCode = s2.PrimarySymbol 
and			si.SecIdTypeId = '30010'
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_Price_Local pl
on			pl.SecID = si.secid 
and			convert(DateTime,pl.dayid,103)  = @DT
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_LT_BETA_RAW_OVERRIDABLE b
on			b.SecID = si.secid 
and			convert(DateTime,b.dayid,103)  = @DT

Left Join   mav.FinancialCalendar.HolidayCalendarByCountryView hc
on			hc.Country = s2.Country
and			hc.HolidayDate = @dt
and			hc.Type = 'SE Trading'
Where		s1.HistDate =  @dt 
and         s2.PvtType = 'None'
and			s2.InvestmentType not in ('BKDT','MMKT')
and         s2.GroupID not in ('GOVT-US','LGFTY','SCHALLOCATION','IBOXHYSE')
and			s2.PrimarySymbol not in ('RR/.LN-C','1005722Q','BEST.SP','3333.HK_RIGHTS')
and			hc.Country is null
and			(pl.value is null
or			b.value is null)
and			s2.TradingStatus not in ('Unlisted','Delisted','Expired','Matured')
order by 2,1,6 desc, 4,3