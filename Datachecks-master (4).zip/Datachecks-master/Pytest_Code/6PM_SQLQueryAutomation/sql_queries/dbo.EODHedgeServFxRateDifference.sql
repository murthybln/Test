-- End of Day Price Differences HS vs Mav
-- End of Day
-- Sev 2


DECLARE @ed AS Date = GetDate() 




SELECT
			Distinct
			 convert(DateTime,bl1.dayid,103) [HistDate]
			,sm.IdCode [MasterSecID]
			,si.IdCode [SecCode]
			,it.Description [InvestmentTypeDescription]
			,round(bl1.value,6) [HS_Rate]
			,round(ref.value,6) [Mav_Rate]
			,round(bl1.value - ref.value,6) as [Difference]
		
			
FROM		PriceMaster.MarketValue.Data_HS_EOD35_Rate  bl1
Left Join	PriceMaster.dbo.sec s 
on			s.SecId = bl1.SecID
Left Join	PriceMaster.dbo.SecId si 
on			si.SecID = bl1.SecID  and si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = s.secid and sm.SecIdTypeId = '30007'
Left Join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Left Join   PriceMaster.MarketValue.Data_RefSrc1_Rate  ref
on		    ref.secid = bl1.secid
and			bl1.dayid = ref.dayid


Where		convert(DateTime,bl1.dayid,103) = @ed
and			sm.IdCode is not null
and			abs(round(bl1.value - ref.value,6) ) > .001


order by 3 desc