Declare @sd as Date = GetDate() -4
Declare @ed as Date = GetDate()

SELECT
			Distinct
			convert(DateTime,lp.dayid,103) [HistDate]
		   ,sm.IdCode [MasterSecID]
			,si.IdCode [SecCode]
			,s.Name [SecurityName]
		    ,lp.value as [Bloomberg_Price]
	
			,it.Description [InvestmentTypeDescription]
			
			
FROM		[PriceMaster].[MarketValue].[Data_BBG3_price] lp
left Join		PriceMaster.dbo.sec s 
on			s.SecId = lp.SecID
left Join		PriceMaster.dbo.SecId si 
on			si.SecID = lp.SecID  and si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = lp.secID and sm.SecIdTypeId = '30007'

left join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Where		convert(DateTime,lp.dayid,103) between @sd and @ed

and			si.IdCode is null



order by 1,2