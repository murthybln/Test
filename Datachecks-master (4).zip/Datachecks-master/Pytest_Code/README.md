This contains the code which runs the pytest for all the SQL jobs.
