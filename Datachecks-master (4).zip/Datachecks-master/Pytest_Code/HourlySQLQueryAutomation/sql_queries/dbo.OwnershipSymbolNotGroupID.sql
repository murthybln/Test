

Select 
		a.mastersecid,
		a.Sec_Code,
		a.OwnershipSymbol,
		a.LegalEntityUDFGroupID,
		a.InvestmentType,
		a.TradingStatus
from		smgc.dbvw.Identifiers a with (nolock)
Left JOin	smgc.dbvw.Identifiers b with (nolock)
on			a.OwnershipSymbol = b.Sec_Code
Where	(a.OwnershipSymbol is not null
and		b.Sec_Code is null)
and a.Mastersecid not in ('1284181','1284210','1385014','1284366','1284367','1295071','1301224','1300511')
and a.exceptiontype not in ('Private')
--or		(a.Sec_Code = a.LegalEntityUDFGroupID
	--	and a.Sec_Code <> a.OwnershipSymbol)