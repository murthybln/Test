
Select 
	Sec_Code,
	MasterSecID,
	LegalEntityID,
	LegalEntityUDFGroupID,
	IssuerTicker,
	InvestmentType


from	Smgc.dbvw.SecurityBuilder
where	LegalEntityUDFGroupID is null
and		InvestmentType not in ('INT','Rate','INDEX')
and		LegalEntityID not in ('-7','0')