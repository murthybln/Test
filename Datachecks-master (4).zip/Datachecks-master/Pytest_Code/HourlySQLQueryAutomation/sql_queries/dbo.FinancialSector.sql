SELECT Distinct
		Sec_Code,
		MasterSecID,
		MavSector,
		AttributionSector,
		PerformanceSector,
		TradingStatus,
		InvestmentType
FROM	smgc.dbvw.UserDefinedFields
Where	Sec_Code is not null
and		TradingStatus not in ('Delisted','Expired','Matured','Acquired')
and		(
			MavSector like '%FN%' 
or			PerformanceSector like '%FN%'
or		    AttributionSector like '%FN%'
		)