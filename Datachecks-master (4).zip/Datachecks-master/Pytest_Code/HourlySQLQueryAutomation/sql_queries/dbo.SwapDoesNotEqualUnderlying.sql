Select 
		MasterSecID,
		Sec_Code,
		OwnershipSymbol,
		PrimarySymbol,
		UnderlyingSecCode,
		UnderlyingOwnershipSymbol,
		UnderlyingPrimarySymbol,
		LegalEntityUDFGroupID,	
		TradingStatus,
		UnderlyingTradingStatus,
		ExceptionType

	
from	smgc.dbvw.Identifiers i
Where	(UnderlyingOwnershipSymbol <> OwnershipSymbol
or		 UnderlyingPrimarySymbol <> PrimarySymbol
or		TradingStatus <> UnderlyingTradingStatus)
and		InvestmentType in ('TRS','BLLT')
and		isnull(ExceptionType,'XXX') not in ('Duplicate Identifier','Old TR Security')	