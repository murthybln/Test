Declare @dt as DateTime = GetDate()
Declare @dt1 as DateTime = DATEADD(MINUTE,-122,@Dt)


SELECT [datestamp]  as 'AuditDate' 
      ,[Name]
      ,[FilterText]
	  ,'Filter was Added or Changed' as 'Comments'
  FROM [PriceMaster_Audit].[dbo].[AUDIT_FilterConfiguration]
  where  [datestamp]  > @dt1
   and action_type = 1
  order by 1 desc 

 