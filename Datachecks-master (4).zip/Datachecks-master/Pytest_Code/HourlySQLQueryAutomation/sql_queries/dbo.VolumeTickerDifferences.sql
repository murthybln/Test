

SELECT 	
	Rec.MasterSecID,  
	Rec.SecCode, 
	Rec.BLMBRG_ID,
	Rec.VolumeTicker,
	Rec.Country,
	id.UnderlyingVolumeTicker 
	
	
FROM	SMGC.client.ReconView Rec
Join	smgc.dbvw.Identifiers id
on		id.mastersecid = rec.mastersecid 
WHERE	Rec.isjunksecuritygroup = 'Prod' 
and		Rec.AssetType = 'Equity' 
and		rec.VolumeTicker <> 
		Case when rec.Country in ('TH')
		then Isnull(id.UnderlyingBLMBRG_ID,rec.BLMBRG_ID) 
		else rec.BLMBRG_ID end
and		rec.TradingStatus = 'Active'
and		rec.TradingZone <> 'Europe'
and     rec.InvestmentType not in ('COMMON_R')
	
