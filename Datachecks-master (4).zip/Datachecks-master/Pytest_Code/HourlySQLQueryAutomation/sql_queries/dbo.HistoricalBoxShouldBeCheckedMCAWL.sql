--Historical Box should be checked for MCAWL
-- Hourly
-- Sev 1


Select Code, Name, IsHistorical, 'Historical Box should be checked' as 'Comments'  from SMGC.dbo.CustomAttribute 
where code = 'MCAWL' and IsHistorical <> 1