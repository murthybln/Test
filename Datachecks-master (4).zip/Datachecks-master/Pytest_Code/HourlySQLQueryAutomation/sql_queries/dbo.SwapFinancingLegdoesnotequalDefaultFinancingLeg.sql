-- Swap Financing Leg does not equal Default Financing Leg

Select Sec_Code, MasterSecID,
	Ticker,
	SwapFinancingSecCode,
	PrimarySymbol,
	TradingStatus,
	PrimarySymbol+'_FIN' as 'Default Financing Leg',
	UnderlyingSecCode,
	PrimarySymbol



from	smgc.dbvw.securitybuilder
where	InvestmentType in ('TRS','BLLT')
and		(SwapFinancingSecCode <> PrimarySymbol+'_FIN' or PrimarySymbol is null or SwapFinancingSecCode is null)
and		SwapFinancingSecCode not like '%BLLT%'
and		Sec_Code not like '%\_%' escape '\'
and		Sec_Code not like '%SWAPX%' 
and		MasterSecId not in ('1285549','1300471','1300447','1300470')
and		TradingStatus not in ('Excluded')
