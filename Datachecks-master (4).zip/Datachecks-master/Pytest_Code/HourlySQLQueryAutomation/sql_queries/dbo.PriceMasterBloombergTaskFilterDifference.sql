
Select * from 


(SELECT 
      DIstinct
	  sc.ShortCode [SourceCode]
	  ,sc.Name [SourceName]
      ,sam.Name [TaskName]
      ,fc.Name [FilterName]
	  --,fc.FilterSqlText
	  ,fc.FilterText
	  , Case
		When sam.Name = 'Bloomberg - LT - BETA_RAW_OVERRIDABLE (GBP)' then  'LT BETA - In Portfolio - Bloomberg (GBP)'
		When sam.Name = 'Bloomberg - LT - BETA_RAW_OVERRIDABLE (SPX)' then  'BETA - In Portfolio - Bloomberg (SPX)'
		When sam.Name = 'Bloomberg - ST - BETA_RAW_OVERRIDABLE' then  'ST BETA - In Portfolio - Bloomberg'
		When sam.Name = 'Bloomberg - ST - BETA_RAW_OVERRIDABLE (SPX)' then  'BETA - In Portfolio - Bloomberg (SPX)'
		When sam.Name = 'Bloomberg - ST - BETA_RAW_OVERRIDABLE- Asian\European Instruments' then  'ST BETA - In Portfolio - Bloomberg - Asian\Europe'
		When sam.Name = 'Bloomberg - ST - BETA_RAW_OVERRIDABLE(Adhoc)' then  'ST BETA - In Portfolio - Bloomberg'
		When sam.Name = 'Bloomberg Fixed Income YAS fields' then  'Fixed Income Filter'
		When sam.Name = 'Bloomberg Fixed Income YAS fields (Adhoc)' then  'Fixed Income Filter'
		When sam.Name = 'Bloomberg Fx Forward Curves (BGN, F160)' then  'Fx Forwards Filter'
		When sam.Name = 'Bloomberg Fx Forward Curves (BGN, F160) - Unpriced' then  'Fx Forwards Filter - BGN,F160 - Unpriced'
		When sam.Name = 'Bloomberg Fx Forward Curves (BSYN)' then  'Fx Forwards Filter (KRW)'
		When sam.Name = 'Bloomberg Fx Rates (BGN, F160)' then  'FxRate Filter'
		When sam.Name = 'Bloomberg Fx Rates (BGN, F160) - Unpriced' then  'FxRate Filter - BGN,F160 - Unpriced'
		When sam.Name = 'Bloomberg Fx Rates (BSYN)' then  'FxRate Filter (KRW)'
		When sam.Name = 'Bloomberg Historic AVERAGE_BID_ASK_SPREAD Prices' then  'Adhoc Securities (MCAADHOC) Filter'
		When sam.Name = 'Bloomberg OTC Options by BBG_ALT_ID Prices' then  'OTC Options In Portfolio - Bloomberg - Daily'
		When sam.Name = 'Bloomberg OTC Options by BBG_ALT_ID Prices - Monthly' then  'OTC Options In Portfolio - Bloomberg - Monthly'
		When sam.Name = 'Bloomberg OTC Options by BBG_ALT_ID Prices (ADHOC)' then  'OTC Options In Portfolio - Bloomberg - Daily'
		When sam.Name = 'Bloomberg Peers' then  'ActiveEquities (MCAEQU) Filter'
		When sam.Name = 'Bloomberg Prices' then  'In Portfolio - Daily'
		When sam.Name = 'Bloomberg Prices - Asian Instruments' then  'Asian - In Portfolio - Daily'
		When sam.Name = 'Bloomberg Prices - Asian\European Instruments' then  'Asian\European - In Portfolio - Daily'
		When sam.Name = 'Bloomberg Prices - European Instruments' then  'European - In Portfolio - Daily'
		When sam.Name = 'Bloomberg Prices - Monthly' then  'In Portfolio - Monthly'
		When sam.Name = 'Bloomberg Prices (90days)' then  'Today Created (for GetHist 90days)'
		When sam.Name = 'Bloomberg Prices- ADHOC (In Portfolio) PX LAST' then  'In Portfolio - Daily'
		When sam.Name = 'Bloomberg Prices- ADHOC (PX_LAST_EOD)' then  'Adhoc Securities (MCAADHOC) Filter'
		When sam.Name = 'Bloomberg Prices by BBG_ALT_ID' then  'Price BBG_ALT_ID'
		When sam.Name = 'Bloomberg Prices by BBG_ALT_ID(Adhoc)' then  'Price BLMBRG_ID'
		When sam.Name = 'Bloomberg Prices German GY Equities' then  'In Portfolio - Daily German GY Equities'
		When sam.Name = 'Bloomberg Prices-ADHOC (without current day price)' then  'In Portfolio - Daily'
		When sam.Name = 'Bloomberg VOLUME (by BBG_ALT_ID) Asia' then  'Asian - In Portfolio - Daily'
		When sam.Name = 'Bloomberg VOLUME (by VOLUME_TICKER)' then  'Instruments with VOLUME_TICKER - No VOL'
		When sam.Name = 'Bloomberg VOLUME (by VOLUME_TICKER) - Monthly' then  'Instruments with VOLUME_TICKER - Monthly'
		When sam.Name = 'FUND - Bloomberg Prices' then  'FUND- In Portfolio - Daily'
		When sam.Name = 'Index - Bloomberg Prices' then  'Index - In Portfolio - Daily'
		When sam.Name = 'Index - Bloomberg Prices (Closing Prices)' then  'Index - In Portfolio - Daily'
		When sam.Name = 'Option - Bloomberg Prices (by BBG_ALT_ID)' then  'Options - In Portfolio - Bloomberg - Daily'
		When sam.Name = 'Option - Bloomberg Prices (by BBG_ALT_ID) - Asian\European' then  'Options-In Portfolio-Bloomberg Daily- Asian\Europe'
		When sam.Name = 'Option - Bloomberg Prices (by BBG_ALT_ID) (Adhoc)' then  'Options - In Portfolio - Bloomberg - Daily'
		When sam.Name = 'Option - Bloomberg Prices (by GLOBAL_ID)' then  'Options - In Portfolio - Bloomberg - Daily'
		When sam.Name = 'Option - Bloomberg Prices (by GLOBAL_ID) - Asian\European' then  'Options-In Portfolio-Bloomberg Daily- Asian\Europe'
		When sam.Name = 'Option - Bloomberg Prices (by GLOBAL_ID) (Adhoc)' then  'Options - In Portfolio - Bloomberg - Daily'
		When sam.Name = 'SOVR T-Bill Bloomberg Prices' then  'SOVR T-Bill In Portfolio - Bloomberg - Daily'
		When sam.Name = 'SOVR T-Bill Bloomberg Prices - Monthly' then  'SOVR T-Bill In Portfolio - Bloomberg - Monthly'
		When sam.Name = 'SOVR T-Bill Bloomberg Prices (adhoc)' then  'SOVR T-Bill In Portfolio - Bloomberg - Daily'
	    When sam.Name = 'Price History Request- 180 days' then  'Price History- 180 Days'
	    When sam.Name = 'Bloomberg Prices- Price Only' then  'End Of Day Second Run'
		When sam.Name = 'Bloomberg Prices- ADHOC (End of Day)' then  'End of Day Adhoc Securities'
		When sam.Name = 'Bloomberg Closing Prices' then  'In Portfolio Bloomberg Closing Price'
		When sam.Name = 'Bloomberg Prices- ADHOC (Pricing Late)' then  'Adhoc Late Pricing Securities'
		When sam.Name = 'Bloomberg Prices- ADHOC (Canadian Securities)' then  'In Portfolio - Daily Canadian Securities'
		When sam.Name = 'Bloomberg Data ETF Shares' then  'ETF Shares'						
		When sam.Name = 'Index Test' then  'Test Index'						
		When sam.Name = 'Index Weights' then  'Index Baskets'						
		When sam.Name = 'Fund Apps Fields' then  'Fund App Fields Countries'	
		When sam.Name = 'Fund App Europe Total Voting Rights' then  'Fund App Europe Total Voting Rights Countries'	
		When sam.Name = 'Fund App Treasury Shares' then  'Fund App Treasury Share(MCAFATS)'	
		When sam.Name = 'Index Shares and Weights' then  'Index Baskets'									
		When sam.Name = 'Bloomberg - LT - BETA_RAW_OVERRIDABLE (GBP) Adhoc' then  'Bloomberg EQY_BETA_RAW_OVERRIDABLE (GBP)'
		When sam.Name = 'Bloomberg - ST - BETA_RAW_OVERRIDABLE- Asian\European Instruments Adhoc' then  'ST BETA - In Portfolio - Bloomberg - Asian\Europe'	
		When sam.Name = 'Bloomberg Prices - Asian\European Instruments ADHOC' then  'Asian\European - In Portfolio - Daily'	
		When sam.Name = 'Bloomberg Prices - European Instruments Adhoc' then  'European - In Portfolio - Daily'	
		When sam.Name = 'Bloomberg VOLUME (by VOLUME_TICKER) Adhoc' then  'Instruments with VOLUME_TICKER - No VOL'	
	    When sam.Name = 'Bloomberg - LT - BETA_RAW_OVERRIDABLE' then  'In Portfolio - Daily'	
	    When sam.Name = 'Bloomberg Prices- Ticker' then  'Price BLMBRG_ID'	
		When sam.Name = 'Quant Metrics' then  'Quant Metrics'	
		When sam.Name = 'Price History Request- 5 Days YLD YTM MID' then  'Price History 5 Days'
		When sam.Name = 'Bloomberg BETA' then  'In Portfolio - Daily BETA'		
		When sam.Name = 'Bloomberg BETA Asia/Europe' then  'Asian\European - In Portfolio - BETA'		
		When sam.Name = 'Bloomberg Prices - Asian Pricing Only' then  'Asian - In Portfolio - Daily'		
		When sam.Name = 'Price History Request- 60 Days' then  'Price History- 60 Days'		
		When sam.Name = 'Index Divisor' then  'Index Baskets'		
		When sam.Name = 'Bloomberg Derived' then  'In Portfolio - Daily BETA'		
		When sam.Name = 'Bloomberg Derived Asia/Europe' then  'Asian\European - In Portfolio - BETA'	
		When sam.Name = 'Treasury Benchmarks - Bloomberg Prices (Closing Prices)' then  'Treasury Benchmarks'	
			
		else 'Missing' end as 'DefaultFilter'
		
      

 FROM [PriceMaster].[Config].[SourceAdapterMappings] sam
   Left Join PriceMaster.dbo.Source sc on sc.SourceId = sam.SourceId
   Left Join [PriceMaster].[Configuration].[FilterConfiguration] fc on fc.ConfigurationId = sam.FilterId
   Left Join [PriceMaster].[Config].[SourceAdapterMappingSettings] samc on samc.SourceAdapterMappingId = sam.SourceAdapterMappingId
   where Sc.ShortCode = 'BBG' ) x
   
 where DefaultFilter <> FilterName
