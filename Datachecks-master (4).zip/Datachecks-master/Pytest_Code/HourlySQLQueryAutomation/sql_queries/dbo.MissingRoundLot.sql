SELECT 
	rec.SecCode, 
	rec.MasterSecID
FROM		smgc.client.ReconView rec
Join		smgc.dbo.sec s 
on			s.masterSecID = rec.MasterSecID
Left Join   smgc.dbo.SecAuxCustomValues cv on cv.secId = s.secid
WHERE 
			AssetType = 'Equity'
	AND		TradingStatus Not In ('Excluded','Expired','Matured','Delisted','Ticker Change')
	and		cv.RoundLot is null
	AND		Exchange Not In ('PVT')
	and		ResourceType <> 'Private'
	and		rec.seccode is not null
