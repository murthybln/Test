-- Shares Class Level vs Ownership Symbol
-- Run hourly

Select 
	rec.SHARE_CLASS_LEVEL
	,rec.OwnershipSymbol
	,rec.Sec_Code 
	,rec.MasterSecID
	,rec.LegalEntityUDFGroupID as 'GroupID'
	,rec.InvestmentType
	,rec.TradingStatus
	,rec.IsPrimary
	,p.OwnershipSymbol as 'Primary_OwnershipSymbol'
	


from smgc.dbvw.Identifiers rec
Left Join	smgc.dbvw.Identifiers p
on			p.SHARE_CLASS_LEVEL = rec.SHARE_CLASS_LEVEL
and			p.IsPrimary = 1


where rec.TradingStatus not in ('Delisted','Expired')
and 
rec.OwnershipSymbol <> rec.LegalEntityUDFGroupID
and 
rec.SHARE_CLASS_LEVEL in 

(Select SHARE_CLASS_LEVEL


from 

(Select 
	r.SHARE_CLASS_LEVEL
	,r.OwnershipSymbol
	


from		smgc.dbvw.Identifiers r
where --AssetType not in ('Cash','Financing','Index','Forward')
			r.TradingStatus = 'Active' 
and r.MAsterSecID not in ('1298581','1418793')
and r.TradingStatus not in ('Delisted','Expired')
Group by r.SHARE_CLASS_LEVEL,r.OwnershipSymbol) x
group by SHARE_CLASS_LEVEL
Having Count(OwnershipSymbol) > 1) 



