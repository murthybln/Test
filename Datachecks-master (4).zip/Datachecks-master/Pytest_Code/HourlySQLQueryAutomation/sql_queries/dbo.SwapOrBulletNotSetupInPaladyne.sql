Select SecCode,Ticker,Sedol,ISIN,PrimarySymbol 
from MaverickSMGC..fnGetMissingSecurities ('BLLT,SWAP',default) 
Where SecurityName is not null
