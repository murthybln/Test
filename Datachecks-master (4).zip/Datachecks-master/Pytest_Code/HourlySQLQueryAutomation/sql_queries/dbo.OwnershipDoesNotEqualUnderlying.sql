Select 
		MasterSecID,
		UnderlyingMasterSecID,
		Sec_Code,
		OwnershipSymbol,
		PrimarySymbol,
		UnderlyingSecCode,
		UnderlyingOwnershipSymbol,
		UnderlyingPrimarySymbol,
		LegalEntityUDFGroupID,	
		TradingStatus,
		UnderlyingTradingStatus,
		ExceptionType

	
from	smgc.dbvw.Identifiers i
Where	UnderlyingOwnershipSymbol <> OwnershipSymbol
and		TradingStatus not in ('Delisted','Expired','Matured','Expired_old','Acquired')
and		UnderlyingTradingStatus not in ('Delisted','Expired','Matured','Expired_old','Acquired')
and		isnull(ExceptionType,'XXX') not in ('Duplicate Identifier','Old TR Security')	
and		UnderlyingMasterSecID not in ('1283466','1298581','1409668','1426241')