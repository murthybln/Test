SELECT 
	Distinct
	convert(varchar(100), CONVERT (INT,t.MasterSecID )) [MasterSecID]
	,t.SecCode, t.TradingStatus

FROM			SMGC.client.ReconView t
	Left Join	SMGC.dbo.Sec z
	on			z.MasterSecID = t.MasterSecID
	Left Join	SMGC.dbo.SecEquityIssue sev 
	on			sev.SecID = z.secid
Where		isjunksecuritygroup not in ('TR','JUNK')
	and		TradingStatus not in ('Delisted','Excluded','Matured','Ticker Change','Price Not Available','Restricted','Private Company','Unlisted')
	and		SecType in ('Equity','Depository Receipt','Equity Unit') 
    and		SharesOut is null
	and		SecCode not in ('ASO_R')
