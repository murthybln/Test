Select
		Distinct
		convert(varchar(100), CONVERT (INT,InvID )) [InvId],
		convert(varchar(100), CONVERT (INT,MasterSecID )) [MasterSecID],
		Symbol,
		Ticker
	from mav.dbo.Investment
	Where Symbol in 
		(
			SELECT Symbol
			FROM mav.dbo.Investment
			GROUP BY Symbol
			HAVING (Count(InvId)>1))
		--and MasterSecID not in ('1424760','1424761','1411311','1418913')
order by 2
