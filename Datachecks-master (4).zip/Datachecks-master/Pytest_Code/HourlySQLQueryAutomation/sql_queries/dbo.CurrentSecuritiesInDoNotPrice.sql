Declare @dt as Date = (Select max(HistDate) from lsmavgsql.mav.dbo.TaxLotPositionHist) 

SELECT 
	tl.HistDate,
	tl.CustAccount,
	tl.EntityCode,
	tl.Symbol,
	Sum(tl.Quantity) as Qty,
	i.TradingStatus

from		lsmavgsql.mav.dbo.TaxLotPositionHist tl
Join	    smgc.dbvw.Identifiers i
on			i.mastersecid = tl.mastersecid 
and			i.TradingStatus in ('Delisted','Expired')
where		tl.HistDate = @dt
and			tl.Symbol not in ('LGFTY','1005722Q')
and			Quantity <> 0 
Group by 
		tl.HistDate,
		tl.CustAccount,
		tl.EntityCode,
		tl.Symbol,
		i.TradingStatus