SELECT 	
		MasterSecID ,
		SecCode, 
		InvestmentType,
		Currency, 
		UPPER(Currency) as 'Default Currency',
		'Update Currency' as 'Action'
FROM	SMGC.client.ReconView 
Where	Currency <> UPPER(Currency) 
and		UPPER(Currency) in ('GBP','ILS','ZAR')
and    SecCode is not null