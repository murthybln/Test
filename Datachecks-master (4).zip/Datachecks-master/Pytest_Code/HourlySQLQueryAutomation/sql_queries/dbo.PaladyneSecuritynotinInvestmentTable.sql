Select Distinct 
Rec.MasterSecID,
Rec.SecCode,
Inv.Symbol
	
	

from		lspaldsql.smgc.client.reconview rec 
Left Join	mav.dbo.Investment inv 
on			inv.MasterSecID = rec.MasterSecID

Where		AssetType not in ('Financing','Cash','Forward')
			and (Symbol is null or SecCode <> Symbol)
			and SecCode is not null

