--Quant Universe Security in Do Not Price Security Group
-- Daily
-- Sev 3


SELECT symbol
  FROM lsquansql.Quant2.dbo.QuantUniverse q
Where	symbol in (
  		select 
					Distinct 
					smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as SEC_CODE
		from		smgc.dbo.Sec sec with (nolock)
		Left Join	SMGC.dbo.SecAttribute attr with (nolock)
		on			attr.SecID = sec.SecID
		Left Join	SMGC.dbo.CustomAttribute CustAttr with (nolock)
		on			CustAttr.CustomAttributeID = attr.CustomAttributeID 
		Where		CustAttr.Name = 'Do Not Price' 
		and			attr.OutDate is null)
		and Symbol not in ('SWMA.SS')

