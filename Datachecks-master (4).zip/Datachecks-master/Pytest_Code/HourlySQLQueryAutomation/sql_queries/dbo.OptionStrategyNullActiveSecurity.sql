-- Option Strategy is null for Active Security.
-- Run hourly
-- Serv 2


Select
	rec.SecCode,
	rec.MasterSecID,
	rec.TradingStatus,
	AssetType,
	InvestmentType,
	Case when os.Name is null then 'Missing' else os.name end as 'OptionStrategy'

from		smgc.client.reconview rec
Join		smgc.dbo.sec sec
on			sec.mastersecid = rec.mastersecid
Left Join	SMGC.dbo.UDF_Options o
on			o.SecId = sec.secid
Left Join smgc.dbo.UDF_RefOptionStrategy os
on			os.UDF_RefOptionStrategyID = o.OptionStrategy
where		AssetType = 'OP'
and			rec.TradingStatus not in ('Delisted','Expired','Excluded','Matured','Expired_old') 
and         o.OptionStrategy is null
and			InvestmentType not in ('FUT')
AND			datepart(dw,GetDate()) not in (1,7)

