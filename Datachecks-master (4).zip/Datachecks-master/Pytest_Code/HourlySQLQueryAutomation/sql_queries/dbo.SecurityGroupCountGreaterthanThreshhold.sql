-- Security Group Count Greater than Threshhold'
-- Hourly
-- Sev 2


select
		CustomAttributeID
		,SecurityGroupCode
		,SecurityGroupName
		, NumberOfSecurities
		,SecurityGroupThreshhold
		,SecurityGroupThreshhold - NumberOfSecurities as 'Remaining Count'
		,CustomAttributeID
			



from

(select 
			Distinct sa.CustomAttributeID
			,ca.Code as 'SecurityGroupCode' 
			,ca.Name as 'SecurityGroupName'
			,count(*) as 'NumberOfSecurities'
			,case when sa.CustomAttributeID = 6 then '40000'
			      when sa.CustomAttributeID = 17 then '14200'
				  when sa.CustomAttributeID = 25 then '90000'
				  when sa.CustomAttributeID = 34 then '14200'
				  when sa.CustomAttributeID = 33 then '31000'
				  else '8000' end as 'SecurityGroupThreshhold'
from		SMGC.dbo.SecAttribute sa
Join		smgc.dbo.CustomAttribute ca
on			ca.CustomAttributeID = sa.CustomAttributeID
where		sa.OutDate is null
and			sa.CustomAttributeID not in  (0,1,14,10)		
group by	sa.CustomAttributeID,ca.Code,ca.name) t

where	SecurityGroupThreshhold < NumberOfSecurities     
order by 4 desc

 
