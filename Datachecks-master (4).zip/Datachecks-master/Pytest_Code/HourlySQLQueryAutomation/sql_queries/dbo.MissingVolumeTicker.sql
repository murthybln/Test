-- Missing Volume Ticker
-- Run Hourly
-- Serv 2


SELECT 	
	Rec.MasterSecID,  
	Rec.SecCode, 
	Rec.VolumeTicker, 
	Case when CommissionRegion = 'Europe' then replace(rec.BLMBRG_ID,right(rec.BLMBRG_ID,2),'EU') else BLMBRG_ID end as 'Default_Volume_Ticker' 
FROM	SMGC.client.ReconView Rec 
WHERE	Rec.isjunksecuritygroup = 'Prod' 
and		Rec.AssetType = 'Equity' 
and		VolumeTicker is null 
and		TradingStatus = 'Active'
and		TradingZone = 'Europe'

