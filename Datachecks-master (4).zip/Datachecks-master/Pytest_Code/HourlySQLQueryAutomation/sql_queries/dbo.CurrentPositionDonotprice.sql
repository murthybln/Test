


select
Distinct
convert(varchar(100), CONVERT (INT,sec.MasterSecID )) as 'MasterSecID'
,smgc.dbo.fn_GetActualIdentifier (sec.SecId, 300019, GetDate()) as 'SecCode'
,sb.TradingStatus



from smgc.dbo.Sec sec
Join smgc.dbo.UDF_Miscellaneous_0 cp
on cp.SecID = sec.secid
join smgc.dbo.UDF_RefIsCurrentPosition rcp
on rcp.UDF_RefIsCurrentPositionID = cp.IsCurrentPosition$Integer
join smgc.dbo.RefSecType rt
on rt.RefSecTypeId = sec.RefSecTypeID
Left Join smgc.dbo.SecAttribute attr
on attr.SecID = sec.SecID
Left Join smgc.dbo.CustomAttribute CustAttr
on CustAttr.CustomAttributeID = attr.CustomAttributeID
and CustAttr.Code = 'MCAXPR'
Left Join smgc.dbvw.SecurityBuilder sb
on sb.secid = sec.secid
Where sec.RefSecTypeID not in (801,1,2,59,401,643)
and sec.MasterSecID not in ('1425408','1283470','1442586','1288517', '1288777','1297337','1283833','1408941')
and rcp.Name = 'Yes'
and attr.OutDate is null
and CustAttr.code is not null
and TradingStatus not in ('Excluded')
