-- Security With Underlying that is not setup in Paladyne
-- Run hourly
-- Sev 1

Select
	rec.MasterSecId,
	SecCode,
	UnderlyingSecCode
	,rec.MavSector
	,rec.mavRegion
	, smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300001,GetDate()) as CUSIP
, smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300003,GetDate()) as SEDOL
, smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300015,GetDate()) as TICKER
, smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300007,GetDate()) as BLMBRG_ID



from smgc.client.reconview rec
Join smgc.dbo.sec sec
on sec.mastersecid = rec.mastersecid
Join smgc.dbo.Sec u
on u.masterSecId = sec.MasterSecID_Underlying
where Underlying is not null and UnderlyingSecCode is null
