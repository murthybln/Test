-- Missing BBG_ALT_ID
-- Hourly
--Sev 2


Select
	rec.MasterSecId,
	SecCode,
	BBG_ALT_ID,
	smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 300110,GetDate()) as GLOBAL_ID,
	BLMBRG_ID,
	PricingReference,
	PvtType,
	TradingStatus



 from	smgc.client.reconview rec
 Join	smgc.dbo.sec s 
 on		s.mastersecid = rec.mastersecid

 where TradingStatus not in ('Delisted','Expired','Matured','Ticker Change','Excluded','Restricted','Expired_old')
 and	InvestmentType not in ('OOTC','INT','TRS','BLLT','FDWFX','HEDGE','MAVFUND','CDX','CDS','RCVYLOCK','ABACK','FXOP')

 and	PVTType not like 'Pvt%'
 and	RegTypeName not in ('INDEX- BENCHMARK')
 and	SecCode not in ('OAC_R','UCITS','GB03','JUNKINDEX','CSLT_R031224C16O','ZVZZT','O1BC.GY','LGFTY')
 and	BBG_ALT_ID is null

 order by PricingReference
