SELECT 
		MasterSecID
		,SecCode
		,MavRegion
FROM	SMGC.client.ReconView
where	(MavRegion not in ('EMERGING MARKETS','EUROPE','JAPAN','USA') or MavRegion is null)
		and SecCode is not null
		and AssetType not in ('Index','Cash','Financing','Commodity','Forward')
		and InvestmentType not in ('TRS','BLLT')
		and isjunksecuritygroup = 'Prod'

