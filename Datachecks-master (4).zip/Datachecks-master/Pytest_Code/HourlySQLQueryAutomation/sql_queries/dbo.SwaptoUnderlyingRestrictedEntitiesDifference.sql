-- Swap to Underlying Restricted Entities Difference
-- Run hourly
-- Sev 3


Select 
sw.MasterSecID
, sw.SecCode as 'SwapSecCode'
,u.SecCode as 'UnderlyingSecCode'
,sw.RestrictedEntities as 'SwapRestrictedEntities'
,U.RestrictedEntities as 'UnderlyingRestrictedEntities'
,u.TradingStatus as 'UnderlyingTradingStatus'

from


(SELECT MasterSecID
      ,SecCode
     , PrimarySymbol
	  ,InvestmentType
	  ,UnderlyingSecCode
	  ,RestrictedEntities
	  ,TradingStatus
	 
  FROM SMGC.client.ReconView
  Where InvestmentType in ('TRS','BLLT') and isjunksecuritygroup = 'Prod' and TradingStatus not in ('Excluded','Delisted','Expired','Matured')
  ) SW

Left Join

  (SELECT MasterSecID
      ,SecCode
     , PrimarySymbol
	  ,InvestmentType
	  ,UnderlyingSecCode
	  ,RestrictedEntities
	  ,TradingStatus
	  
  FROM SMGC.client.ReconView
  Where InvestmentType not in ('TRS','BLLT') and isjunksecuritygroup = 'Prod' and TradingStatus not in ('Excluded','Delisted','Expired','Matured')
  
  ) U

  on u.SecCode = Sw.UnderlyingSecCode and  U. PrimarySymbol = sw. PrimarySymbol

  Where U.RestrictedEntities <> sw.RestrictedEntities

  order by 2

 