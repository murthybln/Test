Select * 
	from

		(select 
				MasterSecID,
				SecCode,
				MavSector,
				MavSectorDate,
				SharePercent,
				SectorHead1,
				SectorHead2,
				SectorHead3,
				LEN(MavSector) - LEN(REPLACE(MavSector, '+', '')) +1 as 'NumberOfSectors',
				LEN(SharePercent) - LEN(REPLACE(SharePercent, '+', '')) +1 as 'NumberOfSharePercent',
				Case when SectorHead3 is not null then 3
						When SectorHead2 is not null then 2
				Else 1 end as 'NumberOfSectorHeads'
			from	smgc.client.ReconTimeSeriesView
			where	SecCode is not null 
			and		SharePercent is not null) x
Where	NumberOfSectorHeads <> NumberOfSectors 
or		NumberOfSharePercent <> NumberOfSectors