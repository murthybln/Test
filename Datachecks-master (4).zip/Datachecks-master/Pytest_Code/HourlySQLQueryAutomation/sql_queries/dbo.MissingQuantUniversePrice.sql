select 
		a.MasterSecID,
		a.Symbol,
		isnull(rec.SEC_CODE,'NotSetup') as 'SecCode',
		a.Country,
		a.LastBusDay, 
		rec.TradingStatus,
		lp.HistDate as 'Last Price Date',
		lp.Local_Price as 'Last Local Price',
		lp.MarketStatus
		
from	MaverickSMGC.Quant.SecuritiesWIthoutPriorDayPricing a
left  Join	smgc.dbvw.Identifiers rec 
on		rec.MasterSecID = a.MasterSecID 
Outer Apply
		(SELECT Top 1
		convert(DateTime,bc.dayid,103) as 'HistDate'
		,sm.IdCode as 'MasterSecID'
		,si.IdCode as 'SecCode'
		,bc.value as 'Local_Price'
		,it.Description as 'InvestmentType'
		,mst.value as 'MarketStatus'
		
FROM		PriceMaster.MarketValue.Data_RefSrc1_Price_Local bc with (nolock)
Left Join	PriceMaster.dbo.sec s 
on			s.SecId = bc.SecID
Left Join	PriceMaster.dbo.SecId si 
on			si.SecID = bc.SecID  and si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId sm 
on			sm.SecID = bc.secID and sm.SecIdTypeId = '30007'
Left Join	PriceMaster.dbo.SecId gb 
on			gb.SecID = bc.SecID and gb.SecIdTypeId = '30035'
Left Join	PriceMaster.dbo.InvestmentType it 
on			it.InvestmentTypeID = s.InvestmentTypeID
Left Join	PriceMaster.dbo.sec SecCurr
on			SecCurr.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else s.secid end
Left Join	PriceMaster.dbo.Currency cur 
on			cur.CurrencyId = SecCurr.CurrencyId
left Join	smgc.dbo.sec sec
on			sec.mastersecid = sm.IdCode
Left Join	PriceMaster.MarketValue.Data_BBG3_MARKET_STATUS mst 
on			mst.SecID = bc.secID 
Where		sm.IdCode = a.MasterSecID
order by	convert(DateTime,bc.dayid,103) DESC) lp 

Where	a.MasterSecID not in ('1411918','-4758','1426331')	
and		isnull(rec.TradingStatus,'None') not in ('Delisted','Suspended')
AND		isnull(lp.HistDate,'12/01/99') <> isnull(a.LastBusDay,'12/01/98')
and     isnull(lp.HistDate,'12/01/01') <> convert(varchar, getdate(), 110)

