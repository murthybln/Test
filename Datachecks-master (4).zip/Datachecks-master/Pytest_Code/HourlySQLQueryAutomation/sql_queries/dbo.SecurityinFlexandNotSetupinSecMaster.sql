-- Security in Flex and Not Setup in SecMaster
-- Hourly
--

select 
a.Symbol, 'Security in Flex and Not Setup in SecMaster' as 'Comments' 
from lsTRADSQL.MaverickFlexTrade.dbo.TodaysTrades a
where a.Symbol not in (Select SecCode from lspaldsql.smgc.client.reconview)
and a.Symbol <> 'JWS'