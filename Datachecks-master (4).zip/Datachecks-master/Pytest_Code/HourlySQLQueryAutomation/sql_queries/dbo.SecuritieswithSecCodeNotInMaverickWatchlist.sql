--Securities with SecCode and not in Maverick Watchlist. Exlcudes 'WL'
-- Daily
-- Sev 4


with dt as (SELECT CONVERT(DATE,GETDATE()) currdt)
select        sec.SecCode
from          smgc..sec s
CROSS JOIN    dt 
CROSS APPLY (
                     SELECT        TOP 1 * 
                     FROM          SecIdCode sc
                     WHERE         secidcodetypeid = 300019
                     and                  idstartdate < dt.currdt
                     AND                  sc.SecID = s.secid
                     ORDER BY      IdStartDate DESC
                     ) sec
WHERE         NOT EXISTS 
                     (
                     SELECT        *
                     FROM          smgc..CustomAttribute ca
                     JOIN          smgc..SecAttribute sa
                     ON                   ca.CustomAttributeID = sa.CustomAttributeID
                     JOIN          dt
                     ON                   currdt between sa.InDate and ISNULL(sa.OutDate,'29991231')
                     WHERE         s.secid = sa.secid
                     );
