Select
	MasterSecID,
	Sec_Code,
	PrimarySymbol,
	OwnershipSymbol,
	TICKER,
	IssuerTicker,
	InvestmentType,
	LegalEntityID,
	LegalEntityUDFGroupID,
	TradingStatus


From smgc.dbvw.Identifiers
where
	(Sec_Code like '%.GY%'
or	PrimarySymbol like '%.GY%'
or	OwnershipSymbol like '%.GY%'
or	TICKER like '%.GY%'
or	IssuerTicker like '% GY%'
or  LegalEntityUDFGroupID like '%.GY%')
and MasterSecId not in ('1283961','1284366','1284367','1286722','1286723','1406605')
and TradingStatus not in ('Delisted','Expired','Ticker Change')
