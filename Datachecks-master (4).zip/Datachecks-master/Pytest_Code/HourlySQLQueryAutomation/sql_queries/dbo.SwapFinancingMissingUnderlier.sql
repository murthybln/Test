Select MasterSecID,SecCode,Name 
from smgc.client.ReconView 
where	InvestmentType = 'INT' 
	and (UnderlyingSecCode is null or Name = 'Financing')
	and IsjunkSecurityGroup <> 'Junk'
	and SecCode is not null
