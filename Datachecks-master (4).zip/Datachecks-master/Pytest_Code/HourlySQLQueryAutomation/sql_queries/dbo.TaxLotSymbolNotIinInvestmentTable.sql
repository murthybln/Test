--Tax Lot Symbol not in Investment Table
--Hourly
--Sev 2


DECLARE @DT as Date = (Select max(HistDate) from Mav.dbo.TaxLotPositionHist)


SELECT Distinct
      tl.HistDate
      ,tl.Symbol as 'TaxLotSymbol'
	  ,INV.Symbol as 'InvestmentTableSymbol'
	  ,'Tax Lot Symbol not in Investment Table' as 'Comments'
	


	
    
  FROM			Mav.dbo.TaxLotPositionHist tl
 Left Join      mav.dbo.Investment inv
 on				inv.Symbol = tl.symbol
 --and			inv.mastersecid is not null
 and			inv.mastersecid > 1
 where			HistDate = @dt
and			inv.Symbol is null
 --and			inv.symbol not like '%\_FIN%' escape '\'