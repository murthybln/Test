-- Security where Current Sector equals MT
-- Hourly
--Sev 2

Select 

	SecCode,
	MasterSecId,
	MavSector,
	AttributionSector,
	PerformanceSector
	

from smgc.client.reconview 
where 
	MavSector like '%MT%'
or	AttributionSector like '%MT%'
or	PerformanceSector like '%MT%'