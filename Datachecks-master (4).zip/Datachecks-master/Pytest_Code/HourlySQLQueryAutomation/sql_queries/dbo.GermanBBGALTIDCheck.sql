Select 
		Sec_Code,
		MasterSecID,
		IssuerTicker,
		Global_ID,
		BBG_ALT_ID ,
		ExchangeDescription,
		eq.Ticker+' '+eq.EQY_PRIM_EXCH_SHRT as 'Default BBG_ALT_ID'
	
from	smgc.dbvw.Identifiers i with (nolock) 
Left Join	BBGSecMaster.dbo.Equity_Descriptive eq
on			eq.ID_BB_GLOBAL = i.Global_ID
where	Sec_Code like '%.GR' 
and		(BULK_ALT_ID is null 
or		GLOBAL_ID = BBG_ALT_ID)
and	ExchangeDescription not in ('DEUTSCHE BOERSE AG','OTC Others','HANSEATISCHE WERTPAPIERBOERSE HAMBURG','BOERSE STUTTGART') and TradingStatus not in ('Expired','Private Company','Delisted','Matured')