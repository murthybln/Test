Declare @date DATE = DATEADD(day,-1,GetDate())

Select 
		AsOfDate,
		z.PrimarySymbol,
		--z.securityname as 'Polaris_Name',
		SecInvestmentGroup_TS,
		--sb.SecurityName as 'Paladyne_Security_Name',
		--Case when lck.FieldName is null then 'No' else 'Yes' end as 'Name Is Locked'
		sb.LSTrackingSide
from 



(SELECT 
		AsOfDate,
		PrimarySymbol,
		a.securityname,
		a.SecInvestmentGroup_TS,
		--Portfolio,
		--stratcode,
		
		a.LongShortNet,
		--a.LongShortGross,
		sum(LongQty) [LongQty],
		Sum(ShortQty) [ShortQty],
		Sum(NetQuantity) [NetQuantity]
		,sum(AssetAllocation_MarketValueBook) [MarketValueBook]
	

    FROM	Polaris.dbo.Polaris_PositionPnLBookDeNormalized  a with (nolock)
	--join	polaris.dbo.Polaris_Security sec 
	--on		sec.SecurityId = a.SecMasterID

	Where	AsOFDate = @date
	--and		LongShortGross <> LongShortNet
	and		(LongQty <> 0 or ShortQty <> 0 )
	and		StratCode in ('LDC','USA','LEV')
	and		secgenevaassettype not in ('Cash','OP')
	and		a.SecInvestmentGroup_TS 
	in	
(SELECT 
		
		a.SecInvestmentGroup_TS
		
	

    FROM	Polaris.dbo.Polaris_PositionPnLBookDeNormalized  a with (nolock)
	join	polaris.dbo.Polaris_Security sec with (nolock)
	on		sec.SecurityId = a.SecMasterID

	Where	AsOFDate = @date
	and		LongShortGross <> LongShortNet
	
	and		StratCode in ('LDC','USA','LEV')
	and		secgenevaassettype not in ('Cash','OP')
Group by AsOfDate,
		--Portfolio,
		--stratcode,
		a.SecInvestmentGroup_TS
Having Sum(NetQuantity) <> 0)  
Group by  
		AsOfDate,
		--Portfolio,
		--stratcode,
		a.LongShortNet,
		a.PrimarySymbol,
		a.securityname,
		a.SecInvestmentGroup_TS
		--,a.LongShortGross

Having		Sum(NetQuantity) <> 0) z
Join		lspaldsql.smgc.dbvw.UserDefinedFields sb with (nolock)
on			sb.Sec_Code = z.PrimarySymbol
where		z.NetQuantity < 0
and			sb.LSTrackingSide is null
and         SecInvestmentGroup_TS <> '1005722Q'


	
	
