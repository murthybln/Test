--dba Request
--Sev-2

SELECT        COUNT(*) as 'NumberCount'
FROM          quant2..numbers
WHERE         n <6
AND                  NOT EXISTS (
                                         SELECT        * 
                                         FROM          quant2.xprs.PriceEquities c (nolock)
                                         WHERE         c.PricingDate = DATEADD(day,-n,getdate()))
