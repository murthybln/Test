SELECT  SecCode
	,sec.MasterSecID
	,sep.StrikePrice 
	,sep.Maturity
FROM		smgc.client.SecConcatView scv
Join		smgc.dbo.sec sec
on			sec.secid = scv.secid	
Join		smgc.dbo.SecEquityPipe sep
on			sep.secid = scv.secid
LEFT JOIN	smgc.dbo.SecAuxCustomValues aux 
ON			scv.SecID = aux.SecID  
LEFT JOIN	smgc.dbo.RefTradingStatus rts 
ON			aux.RefTradingStatusID = rts.RefTradingStatusID
LEFT JOIN   smgc.dbo.UDF_Accounting_0 udf 
on			udf.secid = scv.secid
where		InvestmentType = 'RGHT'
and			rts.Name not in ('Matured','Expired','Delisted')
and			sep.StrikePrice is null

