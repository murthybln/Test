SELECT 
		MasterSecID
FROM		mav.dbo.Investment Investment
WHERE		MasterSecID Is Not Null
GROUP BY	MasterSecID
HAVING	Count(Investment.InvId)>1

