-- Security not in WatchList
-- Hourly
-- Sev 1


Select masterSecId, smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as SEC_CODE,RefSecTypeID,IssueTicker
from smgc.dbo.sec sec with (nolock)
where MasterSecID  not in (Select Distinct MasterSecID
			from smgc.dbo.Sec sec
		
			Left Join SMGC.dbo.SecAttribute attr with (nolock)
				on attr.SecID = sec.SecID
			Left Join SMGC.dbo.CustomAttribute CustAttr with (nolock)
				on CustAttr.CustomAttributeID = attr.CustomAttributeID 
		Where CustAttr.Code = 'MCAWL' and Outdate is null)
and IssueTicker is not null 
and smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) is not null
and RefSecTypeID <> 2


