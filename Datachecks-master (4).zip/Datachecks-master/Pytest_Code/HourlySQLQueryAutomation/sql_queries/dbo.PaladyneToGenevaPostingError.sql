--Paladyne to Geneva Posting Error
-- Serv 3
-- Run Hourly


DECLARE @dt DATETime = DATEADD(mi,-60,GETDATE())


Select 

		Distinct 
		ps.Date
		,ce.ControlDate
		,pr.SecID 
		,sec.MasterSecID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as SEC_CODE
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667,GetDate()) as PRIMARY_SYMBOL
		,ps.ResponseText
		,ps.SystemName
		,ps.FullActionName
		,ce.Descr as 'Details'


from		smgc.dbo.PostingRequest pr
Join		smgc.dbo.PostingStatus ps 
on			ps.PostingRequestID = pr.PostingRequestID
Join		smgc.dbo.Sec sec 
on			sec.Secid = pr.secid
Left join	smgc.dbo.vw_CoraxEvent ce 
on			ce.CoraxEventID = pr.CoraxEventID
where		ps.Date > @dt
and			ps.Status = 3
and			ce.Descr not like '%deleted%'
and			smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) is not null
order by	Date