SELECT 
	t1.MasterSecID 
	,SECCODE
	FROM		smgc.client.reconview t1
	Join		smgc.dbo.sec s on s.mastersecid = t1.mastersecid
	Left Join smgc.dbo.UDF_Sanctions sanc on sanc.secid = s.secid
	where ((Country in (   Select FICode from smgc.dbo.refcountry t2
	Left Join [SMGC].[dbo].[UDF_RefCountry] t3 on t3.RefCountryID = t2.RefCountryID
	where t3.IsSanction = 1)
	or 
	CountryLegalEntity in (   Select FICode from smgc.dbo.refcountry t2
	Left Join [SMGC].[dbo].[UDF_RefCountry] t3 on t3.RefCountryID = t2.RefCountryID
	where t3.IsSanction = 1)
or 
	CountryOfRegistration in (Select FICode from smgc.dbo.refcountry t2
	Left Join [SMGC].[dbo].[UDF_RefCountry] t3 on t3.RefCountryID = t2.RefCountryID
	where t3.IsSanction = 1))
	and t1.InvestmentType not in ('RATE','CCY','HEDGE','FDWFX','Index','INT','TRS','BLLT'))
	and t1.SecCode not in ('MAIL.LI_A','MAIL.LI_S','YNDX_H_OLD')
	and 
		(
				sanc.OFACSANCTIONED$String is null
				or 
				sanc.AUSTRALIASANCTIONED$String is null
				or sanc.CANADASANCTIONED$String is null
				or sanc.EUSANCTIONED$String is null
				or sanc.HONGKONGSANCTIONED$String is null
				or sanc.JAPANSANCTIONED$String is null
				or sanc.OFACFRGNFINLINSTSANCT$String is null
				or sanc.OFACFULLSANCTIONED$String is null
				or sanc.OFACSECTORAL$String is null
				--or sanc.SINGAPORESANCTIONED$String is null
				or sanc.SWITZERLANDSANCTIONED$String is null
				or sanc.UKSANCTIONED$String is null
				or sanc.UNSANCTIONED$String is null 
		)
	and TradingStatus not in ('Unlisted','Delisted','Expired','Ticker Change')
