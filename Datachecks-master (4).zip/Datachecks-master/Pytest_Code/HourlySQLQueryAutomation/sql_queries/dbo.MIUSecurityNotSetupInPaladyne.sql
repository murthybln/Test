Select 
		a.SecType,
		a.CalcSecCode,
		a.Sedol,
		a.MavSector,
		a.gvkey,
		a.iid,		
		p.Sec_Code as 'Paladyne SecCode for Quant ID',
		p.Quant_Gvkey,
		p.Quant_IID,
		p.SEDOL as 'Paladyne SEDOL for Quant ID'
from		mavcapiq.dbo.fnGetSEcurityInformationToLoad() a
Left Join	lspaldsql.smgc.dbvw.UserDefinedFields p
on			p.Quant_Gvkey = a.gvkey
and			p.Quant_iid = a.iid
where		a.MavSector is not null 
AND			p.Quant_Gvkey is null 