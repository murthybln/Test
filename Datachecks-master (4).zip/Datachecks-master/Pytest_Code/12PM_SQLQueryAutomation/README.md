This folder contains the sql and json files which will trigger at 12pm.
