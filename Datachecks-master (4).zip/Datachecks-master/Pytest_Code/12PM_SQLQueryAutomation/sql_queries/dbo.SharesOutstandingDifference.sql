--SharesOutstanding Difference

Select 
		Sb.SecCode, 
		sb.MasterSecID,
		eq.EQY_SH_OUT_REAL [Bulk_SharesOutstanding], 
		eq.EQY_SH_OUT_DT [SharesOutstanding Date], 
		eq.TICKER_AND_EXCH_CODE,
		round(os.SharesOut,0) [Paladyne SharesOutstanding],
		os.SharesOutDate [Paladyne SharesOutstanding Date],
		round(os.SharesOut,0) - eq.EQY_SH_OUT_REAL [SharesOutstanding_Difference],
		Case when eq.EQY_SH_OUT_DT = os.SharesOutDate 
			then 'Y' else 'N' 
			end as[SameDate],
		Case when lck.MasterSecID is null then 'N' else 'Y' end [FieldLocked]
from		smgc.dbo.vw_secBasic sb 
outer apply	
			(SELECT		TOP 1 so.* 
			from		[SMGC].[dbo].[SecEquityIssue] so 
			WHERE	isnull(SharesOutDate,getdate()-1) <= getdate() 	
			AND sb.SecID = so.SecID 
			order by ISNULL(DATEDIFF(dd,SharesOutDate,getdate()),9999999) ASC ) OS
Left Join	smgc.dbo.sec sec
on			sec.mastersecid = sb.MasterSecID
Join		BBGSecMaster.dbo.EQUITY_DESCRIPTIVE eq	
on			eq.ID_BB_GLOBAL = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666675,GetDate())
Left Join	smgc.client.LockedColumnsBySecurity  lck
on			lck.MasterSecID = sb.MasterSecID
and			lck.FieldName = 'SharesOut'
Where		sb.SecCode is not null 
and			(round(os.SharesOut,0) <> round(eq.EQY_SH_OUT_REAL,0) 
or			eq.EQY_SH_OUT_DT <> os.SharesOutDate)
and			os.SharesOut <> 0