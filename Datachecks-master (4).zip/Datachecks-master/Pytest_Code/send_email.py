import smtplib

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from smtplib import SMTPException


def generate_html(data, subject=None, confluence_link=None):
    subject_, confluence_link_ = subject if subject else '', confluence_link if confluence_link else ''
    html = """
    <html>
    <head>
    <style> 
     table, th, td {{ border: 2px solid black; border-collapse: collapse; }}
      th, td {{ padding: 5px; }}
    </style>
    </head>
    <body>
    <p>{0}<br>{1}<p>
    </table>
    <br>{2}<br>
    </body>
    </html>
    """.format(subject_, data, confluence_link_)
    return html


def send_email(html_data, subject, receiver):
    message = MIMEMultipart("alternative", None, [MIMEText(html_data,'html')])

    sender = 'DevSupport@maverickcap.com'
    server = 'mavsmtp.mcap.off:25'
    message['Subject'] = subject
    message['From'] = sender
    message['To'] = receiver
    try:
        server = smtplib.SMTP(server)
        server.sendmail(sender, receiver.split(','), message.as_string())
        server.quit()
        print ("Successfully sent email to {0}".format(receiver))
    except SMTPException:
        print ("Error: unable to send email")


def send_error_email(traceback, subject, receiver, job_info=None, sql_query=None):
    html_str = ""
    html_str += job_info if job_info else ""
    html_str += "<br/>"
    html_str += "<br/>".join(traceback.splitlines())
    html_str += "<br/>"
    html_str += "<br/>"
    html_str += sql_query if sql_query else ''
    html_str += "<br/>"
    message = MIMEMultipart("alternative", None, [MIMEText(html_str, 'html')])

    sender = 'DevSupport@maverickcap.com'
    server = 'mavsmtp.mcap.off:25'
    message['Subject'] = subject
    message['From'] = sender
    message['To'] = receiver
    try:
        server = smtplib.SMTP(server)
        server.sendmail(sender, receiver.split(','), message.as_string())
        server.quit()
        print ("Successfully sent email to {0}".format(receiver))
    except SMTPException:
        print ("Error: unable to send email")
