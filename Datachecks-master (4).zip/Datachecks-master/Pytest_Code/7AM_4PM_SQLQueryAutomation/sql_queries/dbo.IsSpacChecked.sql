Select 
		Sec_Code,
		MasterSecID,
		IsSPAC,
		LegalEntitySPACEndDate,
		BloombergSubIndustry,
		TradingStatus

from	smgc.dbvw.UserDefinedFields
Where	((IsSpac = 0 
and		BloombergSubIndustry = 'Specified Purpose Acquis' )
or		(IsSpac = 1
and		BloombergSubIndustry <> 'Specified Purpose Acquis' ))
and		InvestmentType not in ('INT')
and		TradingStatus not in ('Delisted','Acquired')