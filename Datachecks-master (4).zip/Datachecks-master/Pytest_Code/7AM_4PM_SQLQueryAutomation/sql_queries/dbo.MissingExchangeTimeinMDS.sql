SELECT DISTINCT
			
	c.Country
	,bc.[Counterparty BIC]
	,c.Exchange 
	,ex.[GMT Open Time]
	,ex.[GMT Close Time]
			
FROM  lsPALDSQL.smgc.client.ReconView c  	
	
LEFT JOIN	lsBOBISQL.[ReferenceData].[mdm].[BrokerClearing] bc 
ON			bc.Country_Code = c.country AND bc.PrimaryBroker_Code = 37
LEFT JOIN	lsBOBISQL.[ReferenceData].[mdm].[Exchanges] ex 
ON			ex.Code = c.Exchange

WHERE
c.TradingStatus NOT IN ('Delisted','Expired','Matured','Excluded')
AND (ex.[GMT Open Time] IS NULL OR ex.[GMT Close Time] IS NULL OR ex.[GMT Open Time] ='' OR ex.[GMT Close Time] = '')
AND c.InvestmentType NOT IN ('Rate','CCY','INT','Index','Hedge','FDWFX','TRS','BLLT','CDS','CDX','CMSV','ABACK','CORB','SV','MUNI','BKDT','PFDNOTE','CVTB')
AND c.Exchange NOT IN ('PVT','OTC')
AND c.Country <> 'PK'
