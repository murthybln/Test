-- Option with wrong PriceList
-- Run Daily


Select
		MasterSecID,
		SecCode,
		InvestmentType,
		PriceList,
		TradingStatus,
		Case When InvestmentType in('OOTC','Swaption') then 'BLoomL2' else 'BloomL1' end as 'DefaultPriceList'
		

from smgc.client.reconview
Where AssetType = 'OP' and TradingStatus <> 'Expired'  and InvestmentType not in ('FXOP')
and IsJUnkSecurityGroup = 'Prod'
and Case When InvestmentType in('OOTC','Swaption') then 'BLoomL2' else 'BloomL1' end <> PriceList