
select 
			Distinct 
			e.Symbol, 
			e.Sector, 
			urm.Name as 'MavRegion' 
from		lsquansql.quant2.dbo.etfshares e 
join		SMGC.client.SecBaseView sb 
on			Replace(Replace(Replace(sb.BLMBRG_ID,' US',''),' ','.'),'.GR','.GY') = e.Symbol 
Left Join	SMGC.dbo.RefCountry c 
on			c.EqCode = sb.ISOCountry 
Left Join	SMGC.dbo.UDF_RefMavRegionByCountry um 
on			um.Code = c.FICode 
Left Join	SMGC.dbo.UDF_RefMavRegionMavRegion urm 
on			urm.UDF_RefMavRegionMavRegionID = um.MavRegion 
where		sb.SecCode is null