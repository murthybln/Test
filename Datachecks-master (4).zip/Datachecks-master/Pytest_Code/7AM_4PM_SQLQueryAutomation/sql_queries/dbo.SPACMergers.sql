
DECLARE @dt DATETIME = GETDATE(), @dtwhole DATE = GETDATE();
DECLARE @sdate DATETIME = DATEADD(day,0,@dtwhole)
 , @edate DATETIME = DATEADD(day,300,@dtwhole);






Select Distinct
       
	 
		ca.ControlDate [CorporateAction Date],
		hld.PrimarySymbol,
		ca.LegalEntityID,
		ca.CodeName [CorpActionCodeName],
		Case when ca.IsSpac = 1 then 'Y' Else 'N' end as 'IsSpac',
		Case when ca.LegalEntitySPACDealAnnounced = 1 then 'Y' Else 'N' end as 'LE_SPACDealAnnouncedChecked'





from
				(Select 
							
							t.PrimarySymbol,
							t.Hld_Symbol,
							--t.EntityCode,
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol as 'Hld_Symbol',
									tl.Quantity,
									tl.EntityCode,
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol'
									

							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @dtwhole) t

							Group by 
									
									t.PrimarySymbol,
									t.hld_Symbol
									--t.EntityCode
									) hld
	Join
	
		(	
			SELECT 
			   a.ControlDate ,t.MasterSecID  ,b.CodeName  ,a.Descr  ,b.CodeDescription, t.PrimarySymbol ,t.IsSpac,t.LegalEntitySPACDealAnnounced,t.Sec_Code,t.LegalEntityID
			FROM SMGC.dbvw.UserDefinedFields t
				Left Join SMGC.dbo.Sec z
					on z.MasterSecID = t.MasterSecID
				Left Join SMGC.dbo.CoraxEvent a
					on a.SecID = z.SecID
				Left Join SMGC.dbo.RefCoraxEventCode b
					on b.RefCoraxEventCodeID = a.RefCoraxEventCodeID
			 Where a.ControlDate between @sdate and @edate
					AND RefCoraxEventTypeID = 1 and b.CodeName = 'Merger'
		) ca 
	on ca.primarySymbol = hld.PrimarySymbol
where ca.IsSpac = 1
and ca.LegalEntitySPACDealAnnounced is null
order by 1
	