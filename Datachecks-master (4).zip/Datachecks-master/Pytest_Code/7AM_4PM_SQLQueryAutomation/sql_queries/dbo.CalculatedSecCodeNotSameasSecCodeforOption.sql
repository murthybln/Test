--Calculated SecCode not same as SecCode for Option
-- Twice a day



DECLARE @dt DATETIME = GETDATE()



Select MasterSecID, SecCode, CalcSecCode, ExpDate, CalcExpirationDate,OptionType
from

(Select 
			
			sec.MasterSecID,
			smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate()) as 'UnderlyingSecCode' ,	
			smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as 'SecCode' ,		
			sec.MasterSecID_Underlying,
			a.RedemType,
			a.StrikePrice,			
			Case when (datepart(dw,a.ExpDate) = 7) then a.ExpDate-1 else a.ExpDate end [CalcExpirationDate],
			a.ExpDate,
			Case 
				when sec.RefSecTypeID = 62  and ot.Description = 'Flex Option'
				then smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate())+right('0' + cast(MONTH(a.ExpDate-1) as varchar),2)+ right('0'+ cast(Day(a.ExpDate-1) as varchar),2)+right(cast(Year(a.ExpDate-1) as CHAR(4)),2)+a.RedemType+convert(varchar(100),cast(a.StrikePrice as float)) +'F'
				when sec.RefSecTypeID = 62 
				then smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate())+right('0' + cast(MONTH(a.ExpDate-1) as varchar),2)+ right('0'+ cast(Day(a.ExpDate-1) as varchar),2)+right(cast(Year(a.ExpDate-1) as CHAR(4)),2)+a.RedemType+convert(varchar(100),cast(a.StrikePrice as float)) 
				when sec.RefSecTypeID = 634 and ot.Description = 'Flex Option'
				then smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate())+right('0' + cast(MONTH(a.ExpDate-1) as varchar),2)+ right('0'+ cast(Day(a.ExpDate-1) as varchar),2)+right(cast(Year(a.ExpDate-1) as CHAR(4)),2)+a.RedemType+convert(varchar(100),cast(a.StrikePrice as float))+'OF' 
				when sec.RefSecTypeID = 634 and ot.Description = 'Swaption'
				then smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate())+right('0' + cast(MONTH(a.ExpDate-1) as varchar),2)+ right('0'+ cast(Day(a.ExpDate-1) as varchar),2)+right(cast(Year(a.ExpDate-1) as CHAR(4)),2)+a.RedemType+convert(varchar(100),cast(a.StrikePrice as float))+'S' 
				when sec.RefSecTypeID = 634 
				then smgc.[dbo].[fn_GetActualIdentifier] (u.SecId, 300019,GetDate())+right('0' + cast(MONTH(a.ExpDate-1) as varchar),2)+ right('0'+ cast(Day(a.ExpDate-1) as varchar),2)+right(cast(Year(a.ExpDate-1) as CHAR(4)),2)+a.RedemType+convert(varchar(100),cast(a.StrikePrice as float))+'O' 
				else 'Missing' end [CalcSecCode],
			ot.Description as 'OptionType',
			rts.Name as 'TradingStatus'

	from SMGC.dbo.SecOptions a
			Join		smgc.dbo.sec sec 
			on			sec.SecId = a.SecId
			Left Join	smgc.dbo.sec u 
			on			u.mastersecid = sec.MasterSecID_Underlying
			Join		smgc.dbo.RefOptionType ot 
			on			ot.RefOptionTypeID = a.RefOptionTypeID
			LEFT JOIN	smgc.dbo.SecAuxCustomValues aux 
			ON			a.SecID = aux.SecID  
			LEFT JOIN	smgc.dbo.RefTradingStatus rts 
			ON			aux.RefTradingStatusID = rts.RefTradingStatusID
			where sec.RefSecTypeID not in ('634')
			
			
			
			) x


		where x.CalcSecCode <> x.SECCODE and CalcExpirationDate > @dt and CalcExpirationDate <> ExpDate and TradingStatus not in ('Expired','Delisted','Matured')