--Trading Status Active for Old Swaps
-- Run Hourly

Select
    MasterSecID,
	Sec_Code,
	UnderlyingSecCode,
	InvestmentType,
	TradingStatus,
	ExceptionType


from	smgc.dbvw.SecurityBuilder
where	UnderlyingSecCode is not null
and		TradingStatus = 'Active'
and		Sec_Code <> UnderlyingSecCode+ Case when InvestmentType = 'TRS' then 'SWAP' else InvestmentType end
and		InvestmentType in ('TRS','BLLT')
and     ExceptionType Not in ('Unpaid Corporate Action')
and		MasterSecID not in ('1403453','1407042')
order by 3