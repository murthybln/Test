

select        q.*
from          MaverickSMGC.quant.primaryiidsecurities q
JOIN          (select gvkey,count(*) cnt from MaverickSMGC.Quant.PrimaryIIDSecurities group by gvkey having count(*) > 1) d
ON                   q.gvkey = d.gvkey
order by      q.gvkey, mastersecid