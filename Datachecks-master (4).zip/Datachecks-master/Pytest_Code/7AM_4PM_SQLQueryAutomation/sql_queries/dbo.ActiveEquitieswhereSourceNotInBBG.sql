Select 
	s.SecID,
	s.MasterSecID,
	s.SecuritySource,
	s.Sec_Code,
	s.TradingStatus
from	smgc.dbvw.Identifiers s
where	s.SecuritySource <> 'BBGBULK'
and		s.MasterSecID in 
				(	Select Distinct sec.MasterSecID
					from		SMGC.dbo.SecAttribute a (nolock)
						Join	SMGC.dbo.CustomAttribute CustAttr (nolock)
						on		CustAttr.CustomAttributeID = a.CustomAttributeID
						join	smgc.dbo.Sec sec (nolock)
						on		sec.SecID = a.SecID
					where		CustAttr.Name = 'ActiveEquities')
and		s.Sec_code is not null
and		s.TradingStatus not in ('Unlisted','Price Not Available','Private Company') 
