Select 
convert(varchar(100), CONVERT (INT,a.MasterSecID )) [MasterSecID],
a.Sec_Code, TradingStatus,a.ExceptionType


from			SMGC.dbvw.UserDefinedFields a with (nolock)
	Left Join	SMGC.dbo.sec sec with (nolock)
	on			sec.MasterSecID = a.MasterSecID 
	

where 		TradingStatus not in ('Acquired','Unlisted','Delisted','Excluded','Matured','Ticker Change','Price Not Available','Restricted','Expired')
	and		ExceptionType not in ('Restricted','CORE Box','Unpaid Corporate Action','Other','YCF Placeholder','Requires Conversion','Legend Shares')
	and		SecurityType in ('Equity','Depository Receipt','Equity Unit','Equity Unit') 
	and		a.MasterSecId not in ('1283470','1285903') 
	and		a.Sec_Code is not null
	and		a.MasterSecID not in 
				(	Select Distinct sec.MasterSecID
					from		SMGC.dbo.SecAttribute a
						Join	SMGC.dbo.CustomAttribute CustAttr
						on		CustAttr.CustomAttributeID = a.CustomAttributeID
						join	smgc.dbo.Sec sec
						on		sec.SecID = a.SecID
					where		CustAttr.Name = 'ActiveEquities')
