SELECT
		CONVERT(VARCHAR(100), CONVERT (INT,MasterSecID )) [MasterSecID],
		SecCode,
		RestrictedFromTrading,
		TradingStatus
FROM smgc.client.reconview
WHERE RestrictedFromTrading = 'True' and TradingStatus NOT  IN ('Delisted','Expired','Matured','Excluded','Ticker Change')
	AND		SecCode NOT LIKE '%SWAPX'
	AND		SecCode NOT LIKE '%BLLTX%'
	AND		IsJunkSecurityGroup NOT IN ('Junk','TR')
	AND		SecCode NOT LIKE '%\_OLD%' {escape '\'}
	AND		SecCode NOT LIKE '%\_A%' {escape '\'}
	AND		SecCode NOT LIKE '%\_S%' {escape '\'}
	AND		AssetType NOT IN ('Index')
	AND		primarySymbol <> 'SBMAM.AU'
