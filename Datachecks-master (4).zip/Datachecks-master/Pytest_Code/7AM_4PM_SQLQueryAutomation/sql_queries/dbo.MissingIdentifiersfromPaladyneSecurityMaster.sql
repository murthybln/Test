SELECT Distinct
	Rec.MasterSecID, 
	Isnull(Rec.SecCode,'Missing') as 'SecCode',
	isnull(Rec.Name,'Missing') as 'Name', 
	isnull(Rec.PrimarySymbol,'Missing') as 'PrimarySymbol' ,
	isnull(Rec.OwnershipSymbol,'Missing')  as 'OwnershipSymbol' ,
	isnull(Rec.GroupID, 'Missing') as 'Issuer Ticker',
	isnull(Rec.Ticker,'Missing') as 'Ticker',
	Rec.Cusip,
	Rec.CINS
	
	
  

FROM	SMGC.client.ReconView Rec
Join	smgc.dbo.Sec s
on		s.MasterSecID = Rec.MasterSecID


WHERE	Rec.SecCode Not In ('C_A','CLA.Comdty','NGA.Comdty','SCHALLOCATION','HGA.Comdty') 
and		Rec.isjunksecuritygroup = 'Prod' 
and		Rec.AssetType not in ('Cash','Financing','Index','Rates','Forward') 
and		InvestmentType not in ('TRS','BLLT')
and		rec.MasterSecID not in ('1408740')
and		rec.TradingStatus not in ('Delisted','Expired','Matured')
and 
	(			Rec.Name is null
			or	PrimarySymbol is null
			or	OwnershipSymbol is null
			or	Ticker is null
			or	GroupID is null
			or	rec.SecCode is null)
			
		
