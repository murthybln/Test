-- Price in Multiple Price List
-- Run twice a day
-- Sev 2


Select 
	HistDate,
	t.SecID,
	sm.IdCode as 'MasterSecID',
	si.IdCode as 'SecCode',
	Price_BloomL1,
	Price_BloomL2,
	Price_ManualL3
from 

(Select 

	Isnull(bl1.HistDate,bl2.HistDate) as 'HistDate',
	Isnull(bl1.SecId,bl2.SecId) as 'SecID',
	bl1.Price_BloomL1,
	bl2.Price_BloomL2,
	ml.Price_ManualL3
from 
(Select convert(DateTime,dayid,103) as 'HistDate', SecID, value as 'Price_BloomL1'

from PriceMaster.MarketValue.Data_RefSrc1_Price_BloomL1 
where convert(DateTime,dayid,103)  > GetDate() -1) bl1

full outer join 
(Select convert(DateTime,dayid,103) as 'HistDate', SecID, value as 'Price_BloomL2'

from PriceMaster.MarketValue.Data_RefSrc1_Price_BloomL2
where convert(DateTime,dayid,103)  > GetDate() -1) bl2

on bl2.SecId = bl1.SecId and bl2.HistDate = bl1.HistDate


full outer join 

(Select convert(DateTime,dayid,103) as 'HistDate', SecID, value as 'Price_ManualL3'

from PriceMaster.MarketValue.Data_RefSrc1_Price_ManualL3
where convert(DateTime,dayid,103)  > GetDate() -1) ml

on (ml.SecId = bl1.SecId and ml.HistDate = bl1.HistDate) or (ml.SecId = bl2.SecId and ml.HistDate = bl2.HistDate)


) t

Left Join	PriceMaster.dbo.SecId sm 
	   on			sm.SecID = t.SecID and sm.SecIdTypeId = '30007'  
Left Join	PriceMaster.dbo.SecId si 
	   on			si.SecID = t.SecID  and si.SecIdTypeId = '30010'

Where 
((Price_BloomL1 is not null and Price_BloomL2 is not null)
or (Price_BloomL1 is not null and Price_ManualL3 is not null)
or (Price_BloomL2 is not null and Price_ManualL3 is not null))
and si.IdCode not in ('MHCINV','BEST.SP')
order by 1








