SELECT 
	Rec.MasterSecID, 
	Rec.SecCode,
	Rec.LegalEntityID,
	Rec.GICS,
	bloom.IndustryCodeID [BloomIndustry_ID]


FROM		SMGC.client.ReconView Rec
JOIN		smgc.dbo.Sec s
ON			s.MasterSecID = Rec.MasterSecID
Left Join	SMGC.dbo.vw_SecIndustry secind with (nolock)
on			secind.SecID = s.SecID 
Left Join	smgc.dbo.vw_RefIndustryCode gics with (nolock)
on			gics.RefIndustryCodeID = secind.RefIndustryCodeID_GICS
Left Join	smgc.dbo.vw_RefIndustryCode bloom with (nolock)
on			Bloom.RefIndustryCodeID = secind.RefIndustryCodeID_Bloomberg
		


WHERE	Rec.LegalEntityID NOT IN ('91759')
AND		Rec.isjunksecuritygroup = 'Prod' 
AND		Rec.AssetType NOT IN ('Cash','Financing','Index','Rates','Forward') 
AND		InvestmentType NOT IN ('TRS','BLLT')
AND     GICS IS NULL
and     Rec.SecCode is not null