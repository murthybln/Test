SELECT 
	Rec.MasterSecID, 
	Rec.Sec_Code,
	isnull(Rec.ExposureAdjustment,9999) as 'ExposureAdjustment',
	isnull(Rec.CommissionRegion,'Missing') as 'CommissionRegion',
	isnull(Rec.MavRegion,'Missing') as 'MavRegion',
	isnull(Rec.MavSector,'Missing') as 'MavSector',
	isnull(Rec.Segment,'Missing') as 'Segment',
	isnull(Rec.PerformanceSector,'Missing') as 'PerformanceSector',
	isnull(Rec.PVTType,'Missing') as 'PVTType',
	isnull(Rec.ResourceType,'Missing') as 'ResourceType',
	isnull(Rec.AttributionSector,'Missing') as 'AttributionSector',
	isnull(Rec.InvAnalyst1,'Missing') as 'InvAnalyst1',
	rec.InvestmentType

FROM	SMGC.dbvw.SecurityBuilder Rec



WHERE	Rec.Sec_Code Not In ('C_A','NGA.Comdty','CLA.Comdty','SCHALLOCATION','HGA.Comdty','ZVZZT.ADR') 
and		Rec.InvestmentType not in ('CCY','INT','Index','Rates','Forward','TRS','BLLT','FDWFX','HEDGE','RATE') 

and
	(			ExposureAdjustment is null
			or	CommissionRegion is null
			or	MavRegion is null
			or	MavSector is null
			or	Segment is null
			or	PerformanceSector is null
			or	PvtType is null
			or	ResourceType is null
			or	AttributionSector is null
			or	InvAnalyst1 is null
		
			)
