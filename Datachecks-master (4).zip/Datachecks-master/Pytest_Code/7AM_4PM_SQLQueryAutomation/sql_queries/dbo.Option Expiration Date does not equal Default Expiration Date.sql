-- Option Expiration Date does not equal Default Expiration Date
-- Run Daily
-- Sev-3

Select MasterSecID,Sec_Code,UnderlyingSecCode,OptionExpirationDate, CalcExpirationDate

from 


(Select 
			sec.refsecTypeID,
			a.MasterSecID,
			Cast(Substring(Substring(a.Sec_Code,Len(a.UnderlyingSecCode)+1 ,6),0,3) +'-'+ Substring(Substring(a.Sec_Code,Len(a.UnderlyingSecCode)+1 ,6),3,2) +'-'+ Substring(Substring(a.Sec_Code,Len(a.UnderlyingSecCode)+1 ,6),5,2) as datetime)  CalcExpirationDate,
			a.InvestmentType,
			a.UnderlyingSecCode,
			a.OptionRedemType,
			a.OptionStrikePrice,	
			a.OptionExpirationDate,		
			Case when (datepart(dw,a.OptionExpirationDate) = 7) then a.OptionExpirationDate else a.OptionExpirationDate end [CalcOptionExpirationDate],
			Case when RefSecTypeID = 62 
				then a.UnderlyingSecCode+right('0' + cast(MONTH(a.OptionExpirationDate-1) as varchar),2)+ right('0'+ cast(Day(a.OptionExpirationDate) as varchar),2)+right(cast(Year(a.OptionExpirationDate-1) as CHAR(4)),2)+a.OptionRedemType+convert(varchar(100),cast(a.OptionStrikePrice as float)) 
				when RefSecTypeID = 634 
				then a.UnderlyingSecCode+right('0' + cast(MONTH(a.OptionExpirationDate-1) as varchar),2)+ right('0'+ cast(Day(a.OptionExpirationDate) as varchar),2)+right(cast(Year(a.OptionExpirationDate-1) as CHAR(4)),2)+a.OptionRedemType+convert(varchar(100),cast(a.OptionStrikePrice as float))+'O' 
				else 'Missing' end [CalcSecCode],
		
			a.Sec_Code,
			a.BLMBRG_ID,
			a.BBG_ALT_ID,
			a.SecurityName,	
			u.TradingStatus
		
			
		

		from		smgc.dbvw.investmentdetails a
		Join		smgc.dbo.sec sec on sec.MasterSecID = a.MasterSecID
		Left Join	smgc.dbvw.investmentdetails u on u.MasterSecID = a.UnderlyingMasterSecID
		where		a.TradingStatus Not in ('Expired','Delisted') 
		and			a.InvestmentType in ('OOTC','LOPT')
		and			u.TradingStatus Not in ('Expired','Delisted','Matured','Excluded')
		) x

		where		CalcExpirationDate <> OptionExpirationDate 
		and			OptionExpirationDate > GetDate()


