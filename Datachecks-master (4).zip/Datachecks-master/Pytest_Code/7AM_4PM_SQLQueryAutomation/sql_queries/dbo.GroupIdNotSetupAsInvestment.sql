select 
	b.MasterSecId,
	a.SecCode,
	a.GroupID,
	b.LegalEntityUDFGroupID

FROM SMGC.client.GroupNotInvesment a with (nolock)
Left Join smgc.dbvw.Identifiers b with (nolock)
on b.SEC_CODE = a.SecCode
where a.SecCode is not null