
SELECT Distinct   
		LegalEntityID
		,LegalEntityUDFGroupID
		,RiskCountry_TS
		,LegalEntityRiskCountryCode
		,LegalEntityCountryCode
		,LegalEntityCountryOfIncorpCode
		,Case when LegalEntityRiskCountryCode is not null then LegalEntityRiskCountryCode
			when LegalEntityCountryOfIncorpCode is not null then LegalEntityCountryOfIncorpCode
			When LegalEntityCountryCode is not null then LegalEntityCountryCode 
			else CountryCode
			end as 'DefaultRiskCountry_TS'
 FROM [SMGC].[dbvw].[Identifiers]
  where RiskCountry_TS is null