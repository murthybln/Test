-- SecurityCode in SensitiveIssuersList Entity, but not setup in Paladyne
-- Run Twice a day
-- Serv 2

Select Distinct  
		s.SecurityCode, 
		'SecurityCode in MDS SensitiveIssuersList and not setup in Paladyne' as 'Comments'
FROM	lsBOBISQL.ReferenceData.mdm.SensitiveIssuersList s

 where	replace(s.SecurityCode,' ','.') not in (Select Sec_Code from smgc.dbvw.SecurityBuilder)
