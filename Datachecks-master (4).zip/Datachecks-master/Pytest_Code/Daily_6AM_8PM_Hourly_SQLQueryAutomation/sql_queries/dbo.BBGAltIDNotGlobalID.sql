-- BBG_ALT_ID not a GlobalID for Maverick Security
-- Hourly
-- Sev2

Select 	
		Sec_Code, 
		MasterSecID, 
		GLOBAL_ID, 
		BBG_ALT_ID, 
		UnderlyingBBG_ALT_ID,
		TradingStatus, 
		InvestmentType, 
		SecurityType 
from	smgc.dbvw.UserDefinedFields with (nolock) 
where	BBG_ALT_ID is null 
and		(GLOBAL_ID is not null or ExceptionType in ('Unpaid Corporate Action'))
and		isnull(TradingStatus,'Missing') not in ('Delisted','Expired','Excluded','Matured','Private Company','Unlisted') 
and		InvestmentType not in ('TRS','BLLT')