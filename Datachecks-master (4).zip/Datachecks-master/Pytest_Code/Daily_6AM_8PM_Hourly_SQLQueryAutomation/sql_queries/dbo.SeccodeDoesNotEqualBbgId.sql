Select  Distinct
		rec.MasterSecID,
		rec.Sec_Code, 
		rec.BLMBRG_ID,
		Replace(replace(rec.BLMBRG_ID,' ','.'),'.US','') as 'DefaultSecCode',
		Case when cp.MasterSecID is null then 'N' else 'Y' end as 'CurrentHoldings',
		Case when q.MasterSecID is null then 'N' else 'Y' end as 'QuantTargets',
	    Case when fs.MasterSecID is null then 'N' else 'Y' end as 'FlexSecuritiesGroup',
		rec.InvestmentType as 'Investment Type',
		rec.Tradingstatus,
		Case when rec.IsSpac = 1 then 'Y' else 'N' end as 'IsSpac'
		
		
from		smgc.dbvw.MaverickWatchlist wl with (nolock)
Join		smgc.dbo.RefSecType st
on			st.RefSecTypeId =  wl.INTERNAL_SECURITY_SECTYPE_ID
Join        smgc.dbvw.Userdefinedfields rec with (nolock)
on			rec.MasterSecID = wl.MasterSecID 
Left Join   smgc.dbvw.QuantTargets q with (nolock)
on			q.MasterSecID = rec.MasterSecID
Left Join   smgc.dbvw.CurrentPositions cp with (nolock)
on			cp.MasterSecID = rec.MasterSecID
Left Join   smgc.dbvw.FlexSecuritiesGroup fs with (nolock)
on			fs.MasterSecID = rec.MasterSecID
where		Replace(replace(rec.BLMBRG_ID,' ','.'),'.US','') <> rec.Sec_Code
and			rec.Global_ID is not null
and			st.RefSecClassID = 2
and			Isnull(rec.ExceptionType,'XXX') not in ('Duplicate Identifier','CORE Box')
and			rec.TradingStatus not in ('Expired','Delisted','Matured')
and			rec.resourcetype <> 'Private'
and			rec.MasterSecID not in ('1383785')
