import argparse
import pandas as pd
import os

import send_email as ft
import json_reader as jr

def read_csv_file(file):
    with open(file, 'r') as fp:
        link =  fp.readlines()[0]
        file_df = pd.read_csv(file, sep=",", header=1, quotechar='"', keep_default_na=False)
        file_name = os.path.basename(file)
        return file_name.split('.')[0], link, file_df

if __name__ == "__main__":
    try:
        parser = argparse.ArgumentParser(description='DataChecks Summary report')
        parser.add_argument('-f', "--csv_path", help="csv file path")

        args = parser.parse_args()
        abs_path = os.path.dirname(os.path.realpath(__file__))
        csv_files_path = os.path.join(abs_path, args.csv_path)
        checks = jr.json_reader(dir=abs_path, filename="config.json")
        receiver= checks["summary_report_emails"]
        df_list = []
        for root,dirs,files in os.walk(csv_files_path):
            for file in files:
                if file.endswith(".csv"):
                    full_file_path= os.path.join(root, file)
                    df_list.append(read_csv_file(full_file_path))
                    os.remove(full_file_path)
    
        str = ''
        for desc, link, dframe in df_list:
            str += "<b>" +desc
            str += "<br/>"
            str += link
            str += "<br/>"
            str += dframe.to_html()
            str += "<br/>"

        err_msg= "DataChecks - {0} Summary Report".format(args.csv_path)
        parseddata= ft.generate_html(data= str, subject= None, confluence_link= None)
        ft.send_email(parseddata, err_msg, receiver) if df_list else "No failed testcases to display"
    except Exception as ex:
        print("Exception occured: {0}".format(ex))
