import os

import json_reader as jr
import send_email as ft


def pytest_addoption(parser):
    parser.addoption("--checks_json", action="store", required=True)


def pytest_generate_tests(metafunc):
    if metafunc.definition.name != 'test_datacheck':
        return

    all_jsons = []

    abs_path = os.path.dirname(os.path.realpath(__file__))
    dir_name = metafunc.config.option.checks_json

    checks = jr.json_reader(dir=abs_path, filename="config.json")

    support_emails = checks["support_emails"]

    for root, dirs, files in os.walk(abs_path):
        if dir_name in dirs:
            job_dir_path = os.path.join(root, dir_name)
            all_jsons = jr.json_reader(dir=job_dir_path)
        else:
            print("User provided directory not found. Please provide a proper directory name")

    new_checks = []
    args = ['sql', 'job_name', 'db_name', 'severity', 'confluence_link', 'emails', 'err_msg', 'support_emails',
            'summary_report', 'csv_name']
    for check in all_jsons:
        try:
            if check['enabled']:
                check['job_name'] = dir_name
                new_checks.append([check[arg] for arg in args])
        except Exception as ex:
            json_file = os.path.splitext(check['sql'])[0] + '.json'
            ft.send_error_email(traceback="Missing the following fields {0} in the {1} file".format(ex.__str__(), json_file),
                          subject="[Datachecks] Error email missing fields", receiver=support_emails)

    metafunc.parametrize(args, new_checks)

