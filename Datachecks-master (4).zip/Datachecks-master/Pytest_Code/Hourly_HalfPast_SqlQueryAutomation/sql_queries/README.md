This folder consists of all the sql queries which are scheduld to run at hourly half past the hour daily.
