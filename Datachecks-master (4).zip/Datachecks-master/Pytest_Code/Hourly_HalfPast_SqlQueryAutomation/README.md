This job is scheduled to run at hourly half past the hour daily.
