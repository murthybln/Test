import time
from functools import wraps


def retry(max_tries):
    """
    Implements the retry backoff pattern where it continuosly tries
    to run every 5,10,30 seconds on sql connection error
    :param max_tries: int
    :return:
    """
    def decor(func):
        @wraps(func)
        def innerretry(*args, **kwargs):
            tries = 1
            delay = 5
            while tries <= max_tries:
                try:
                    return func(*args, **kwargs)
                except Exception as ex:
                    print(ex)
                    delay *= tries
                    time.sleep(delay)
                    tries += 1
            return func(*args, **kwargs)
        return innerretry
    return decor
