Declare @dt as Date = GetDate()


SELECT
			Distinct
			U.PrimarySymbol [SecCode]
			,ltbeta.Value [Maverick LT Beta]
			,isnull(eb.Value,bro.Value) [Bloomberg LT Beta]
			,stbeta.value [Maverick ST Beta] 
			,BBGstbeta.value [Bloomberg ST Beta]
			,case when abs(ltbeta.Value) = 3 and abs(stbeta.value) = 3 then 'LT/ST'
				when abs(ltbeta.Value) = 3 then 'LT'
				else 'ST' end [LT/ST]
			 


 
FROM		PriceMaster.dbo.vSecPositionData pr with (nolock)
Join		PriceMaster.dbo.sec s with (nolock)on s.SecId = pr.SecID
Join		PriceMaster.dbo.SecId si with (nolock) on si.SecID = pr.SecID and si.SecIdTypeId = '30010'
Left Join	PriceMaster.dbo.SecId gb with (nolock) on gb.SecID = pr.SecID and gb.SecIdTypeId = '30025'
Left Join	PriceMaster.dbo.SecId sm  with (nolock) on sm.SecID = pr.SecID and sm.SecIdTypeId = '30007'
Left Join	PriceMaster.dbo.SecId ai with (nolock) on ai.SecID = pr.SecID and ai.SecIdTypeId = '30035'
Left Join	smgc.dbvw.UserDefinedFields u on u.MasterSecID = sm.IdCode
Left Join	PriceMaster.dbo.InvestmentType it with (nolock) on it.InvestmentTypeID = s.InvestmentTypeID
Left Join	PriceMaster.MarketValue.Data_RefSrc1_LT_BETA_RAW_OVERRIDABLE ltbeta with (nolock) on ltbeta.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end and convert(DateTime,ltbeta.dayid,103) = pr.date
Left Join	PriceMaster.MarketValue.Data_BBG3_BETA_RAW_OVERRIDABLE BRO with (nolock) on bro.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end and convert(DateTime,bro.dayid,103) = pr.date
Left Join	PriceMaster.MarketValue.Data_BBG3_EQY_RAW_BETA eb with (nolock) on eb.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end and convert(DateTime,eb.dayid,103) = pr.date
Left Join	PriceMaster.MarketValue.Data_RefSrc1_ST_BETA_RAW_OVERRIDABLE stbeta with (nolock) on stbeta.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end and convert(DateTime,stbeta.dayid,103) = pr.date
Left Join	PriceMaster.MarketValue.Data_BBG3_ST_BETA_RAW_OVERRIDABLE BBGstbeta with (nolock) on BBGstbeta.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else pr.secid  end and convert(DateTime,BBGstbeta.dayid,103) = pr.date

join		PriceMaster.dbo.fund f with (nolock) on f.fundid = pr.fundid
where		pr.date = @dt
and			f.FundName not in ('MDI','MAF','MPO','YCF','PEL')
and			it.Description  not in ('Maverick Internal Fund','Investment Fund Equities','Credit Default Swap','Money Market','FX Option','Listed Option','OTC Option','Unit')
and			isnull(u.ResourceType,u.UnderlyingResourceType) not in ('Private')
and			sm.IdCode not in ('1283833','1295302','1283470','1300336')
and			(ltbeta.Value is null or  stbeta.value is null)
and			U.PrimarySymbol  is not null


 order by 6 ,4,5