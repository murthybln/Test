Declare @sdate  as DATE = DATEADD(day,-1,GetDate());
Declare @edate  as DATE = DATEADD(day,3,GetDate());



SELECT DIstinct 
		 ce.ControlDate
		,convert(varchar(100), CONVERT (INT,ce.SecID)) [SecID]
		,convert(varchar(100), CONVERT (INT,s.MasterSecID )) [MasterSecID]
		,i.Sec_Code
		,i.Global_ID
		,ce.Descr

FROM		SMGC.dbo.CoraxEvent ce
Join		smgc.dbo.sec s 
on			s.secid = ce.secid
Join	    SMGC.dbo.RefSecType st 
on			st.RefSecTypeId = s.RefSecTypeID
Join		Smgc.dbvw.Identifiers i
on			i.MasterSecId = s.MasterSecId
where		s.RefSecTypeID not in ('1','2','3','801','401')
and			ce.ControlDate between @sdate and @edate
and			ce.RefCoraxEventCodeID = 1660

