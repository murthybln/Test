Declare @sdate  as DATE = DATEADD(day,1,GetDate());
Declare @edate  as DATE = DATEADD(day,3,GetDate());
Declare @tldate as DATE = (Select max(HistDate) from lsmavgsql.mav.dbo.TaxLotPositionHist)




SELECT Distinct
		sec.MasterSecID
		,sec.secid
		,ce.CoraxDetailID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) as PrimarySymbol
		,ce.ControlDate 
		--,sp.SplitDate
		,sp.SplitFactor
		,sp.SplitTerm
		, Case when sp.IsStockDividend = 1 then 'StockDivided' else 'StockSplit' end as 'SplitType'
		,x.EntityCode 
	  ,Case when q.Symbol is null then 'N' else 'Y' end as 'InQuantUniverse' 
	  ,REPLACE(CONVERT(VARCHAR,CAST(x.NetQuantity AS MONEY), 1),'.00', '') as 'NetQuantity'
	 ,'Confirm with Bloomberg or Broker' as 'Comments'
	 ,ce.Deleted
	 

	
	  
FROM		SMGC.dbo.SecSplit sp
Join		smgc.dbo.sec sec
on			sec.secid = sp.secid
Join	    smgc.dbo.CoraxEvent ce
on			ce.CoraxDetailID = sp.SecSplitID
and			ce.secid = sp.secid
Left Join	lsQuanSQL.Quant2.dbo.QuantUniverse q
on			q.Symbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 

	 Left Join 
				(Select 
							
							t.PrimarySymbol,
							t.EntityCode,
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									tl.EntityCode,
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol'
									

							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @tldate) t

							Group by 
									
									t.PrimarySymbol,
									t.EntityCode) x
		on x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 
		
	 
   
Where	ce.ControlDate between @sdate and  @edate
AND		datepart(dw,GetDate()) not in (7)
and		(EntityCode is not null or q.Symbol is not null)
and		SplitTerm is not null
and     ce.Deleted <> 1		


order by 3


