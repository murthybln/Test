Declare @sdate  as DATE = DATEADD(day,1,GetDate());
Declare @edate  as DATE = DATEADD(day,3,GetDate());
Declare @tldate as DATE = (Select max(HistDate) from lsmavgsql.mav.dbo.TaxLotPositionHist)


SELECT DIstinct 
		convert(varchar(100), CONVERT (INT,si.SecID)) [SecID]
		,convert(varchar(100), CONVERT (INT,s.MasterSecID )) [MasterSecID]
		
		  
		,st.TypeName as 'SecTypeName'
		,si.IdStartDate
		,si.SecIdCodeTypeId
		,sit.CodeTypeName as 'SecIdCodeTypeName'
		,si.SecCode as 'New BLMBRG_ID',
		isnull(tl.symbol,tl2.Symbol) as 'HoldingsSymbol',
		inv.Symbol as 'Current SecCode',
		ind.TradingStatus,
		'Confirm with Bloomberg' as 'Comments'


FROM		LSPALDSQL.SMGC.dbo.SecIdCode si
Join		LSPALDSQL.SMGC.dbo.RefSecIDCodeType sit 
on			sit.SecIDCodeTypeID = si.SecIdCodeTypeId
Join		LSPALDSQL.smgc.dbo.sec s 
on			s.secid = si.secid
Join	    LSPALDSQL.SMGC.dbo.RefSecType st 
on			st.RefSecTypeId = s.RefSecTypeID
Join		mav.dbo.investment inv 
on			inv.mastersecid = s.mastersecid
Left Join	mav.dbo.TaxLotPositionHist tl 
on			tl.symbol = inv.symbol 
and			HistDate = @tldate
Left Join	mav.dbo.TaxLotPositionHist tl2 
on			inv.UnderlyingSymbol = @tldate
Left Join	lspaldsql.Smgc.dbvw.Identifiers ind with (nolock)
on			ind.mastersecid = s.MasterSecID
where		sit.CodeTypeName in ('BLMBRG_ID')
and			s.RefSecTypeID not in ('1','2','3','801','401')
and			si.IdStartDate between @sdate and @edate
and			ind.TradingStatus not in ('Delisted','Expired','Matured')

Order by 4
