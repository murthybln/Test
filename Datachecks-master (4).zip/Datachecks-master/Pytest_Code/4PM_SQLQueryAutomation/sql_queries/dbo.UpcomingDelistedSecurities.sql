DECLARE @dt DATE = GetDate()
DECLARE @dt1 DATE = GetDate()+1
DECLARE @dt2 DATE = GetDate()+1



SELECT Distinct
		sec.MasterSecID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) as 'PrimarySymbol'
		,d.Eff_date
		,sum(isnull(tl.quantity,0)+isnull(tls.quantity,0)+isnull(tlb.quantity,0)) as 'Holdings'
		,Case when q.Symbol is null then 'N' else 'Y' end as 'InQuantUniverse'
		,dr.BLANK_FIELD as 'Delisted Reason'
		,aq.CP_ACQ_TKR as 'Acquired Ticker'
		,'Confirm with Bloomberg or Broker' as 'Comments'
   
      
FROM			smgc.dbo.sec sec
	left Join		smgc.dbo.RefSecType st 
	on			sec.RefSecTypeID = st.RefSecTypeID
	Left Join	BBGSecMaster.dbo.EQUITY_DESCRIPTIVE bbg 
	on			bbg.ID_BB_GLOBAL = smgc.dbo.fn_GetActualIdentifier (sec.SecId, 300110, GetDate())
	Left Join	BBGSecMaster.dbo.EQY_DELIST d 
	on			d.ID_BB_GLOBAL = bbg.ID_BB_GLOBAL
	Left Join		BBGSecMaster.dbo.LU_CP_DELIST_REASON dr 
	on			dr.CP_DELIST_REASON = d.CP_EQY_DELIST_REASON
	Left Join	BBGSecMaster.dbo.ACQUIS aq 
	on			aq.CP_TARGET_ID_BB_GLOBAL = d.ID_BB_GLOBAL 
	and			aq.Eff_date = d.Eff_date 
	Left Join		lsmavgsql.mav.dbo.investment inv 
	on			inv.mastersecid = sec.mastersecid 
	Left Join	lsmavgsql.mav.dbo.TaxLotPositionHist tl 
	on			tl.symbol =  inv.symbol and tl.HistDate > @dt
	Left Join	lsmavgsql.mav.dbo.TaxLotPositionHist tls 
	on			tls.symbol = inv.Symbol+'Swap' and tls.HistDate > @dt
	Left Join	lsmavgsql.mav.dbo.TaxLotPositionHist tlb 
	on			tlb.symbol = inv.Symbol+'BLLT' and tlb.HistDate > @dt
	Left Join	lsQuanSQL.Quant2.dbo.QuantUniverse q
	on			q.Symbol = inv.symbol

Where			d.Eff_Date = @dt2
AND				datepart(dw,GetDate()) not in (1,7)
and				(tl.quantity <> 0 or tlb.quantity <> 0 or tls.quantity <> 0)

Group by
		sec.MasterSecID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate())
		,d.Eff_date
		,dr.BLANK_FIELD 
		,aq.CP_ACQ_TKR 
		,q.Symbol
order by 3
