Declare @sdate  as DATE = DATEADD(day,0,GetDate());
Declare @edate  as DATE = DATEADD(day,5,GetDate());
Declare @tldate as DATE = (Select max(HistDate) from lsmavgsql.mav.dbo.TaxLotPositionHist)

SELECT Distinct 
		lea.EffectiveDate
		,lea.AcquiringTicker
		,smgc.[dbo].[fn_GetActualIdentifier] (sa.SecId, 300019,GetDate()) as 'AcquiringSecCode'
		,lea.TargetTicker
		,smgc.[dbo].[fn_GetActualIdentifier] (st.SecId, 300019,GetDate()) as 'TargetSecCode'
		,rat.Name as 'AcquisitionType'
		,lea.CashTerms
		,lea.ShareRatio
		,x.EntityCode
	    ,x.NetQuantity
	--	,'Confirm with Bloomberg or Broker' as 'Comments'
		,aq.CP_NOTES
		
FROM		SMGC.dbo.LegalEntityAcquisition lea
Left Join	SMGC.dbo.RefAcquisitionType rat
on			rat.RefAcquisitionTypeID = lea.RefAcquisitionTypeID
Left Join	SMGC.dbo.RefAcquisitionDescription red
on			red.RefAcquisitionDescriptionID = lea.RefAcquisitionDescriptionID
Left Join	SMGC.dbo.RefShareRatioBasisType srbt
on			srbt.RefShareRatioBasisTypeID = lea.RefShareRatioBasisTypeID
Left Join	SMGC.dbo.RefFractionalSharesType fst
on			fst.RefFractionalSharesTypeID = lea.RefFractionalSharesTypeID
Left Join	Smgc.dbo.sec sa
on			smgc.[dbo].[fn_GetActualIdentifier] (sa.SecId, 666675,GetDate()) = lea.AcquiringGlobalID
and			sa.RefSecTypeID not in ('801','401')
Left Join	Smgc.dbo.sec st
on			smgc.[dbo].[fn_GetActualIdentifier] (st.SecId, 666675,GetDate()) = lea.TargetGlobalID 
and			st.RefSecTypeID not in ('801','401')
Left Join   SMGC.dbo.CoraxEvent ca
on			ca.CoraxDetailID = lea.LegalEntityAcquisitionID
 CROSS APPLY (SELECT        TOP 1 *
                     FROM          BBGSecMaster.etl.vwBBG_Acquisition bbg 
                     WHERE         bbg.ActionID = ca.ActionID
					 and		   bbg.ActionID is not null
                     ORDER BY      bbg.EventID DESC) etl


Join	    BBGSecMaster.dbo.ACQUIS aq
on			aq.EventID = etl.eventid


	 Left Join 
				(Select 
							
							t.PrimarySymbol,
							
							t.EntityCode,
							
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									tl.EntityCode,
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol'
									
							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @tldate) t

							Group by 
									
									t.PrimarySymbol,
									t.EntityCode
									) x
		on x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (st.SecId, 666667, GetDate()) 
	
where		lea.EffectiveDate between @sdate and @edate
and			lea.RefAcquisitionDescriptionID = '-2'	
and			smgc.[dbo].[fn_GetActualIdentifier] (st.SecId, 300019,GetDate()) is not null	
and			x.EntityCode is not null
and			lea.LegalEntityAcquisitionID not in ('2713')
order by 1 
	
