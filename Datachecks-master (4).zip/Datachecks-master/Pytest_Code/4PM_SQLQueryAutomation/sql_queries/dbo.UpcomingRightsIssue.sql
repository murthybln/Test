Declare @sdate  as DATE = DATEADD(day,1,GetDate());
Declare @edate  as DATE = DATEADD(day,25,GetDate());
Declare @hdate  as DATE = DATEADD(day,0,GetDate());


SELECT Distinct
		sec.MasterSecID
		,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) as PrimarySymbol
		,sp.EffectiveDate
		,sp.RecordDate
		,sp.RightsIssueTicker
		,sp.SpinoffTerm
		,sp.SpinoffFactor
		,sp.CostAdjustment
		,x.EntityCode
		,x.NetQuantity
		,'Confirm with Bloomberg' as 'Comments'
  
FROM		SMGC.dbo.SecRightsIssue sp
Join		smgc.dbo.sec sec
on			sec.secid = sp.secid
  

Left Join 
				(Select 
							
						
							t.PrimarySymbol,
							t.EntityCode,
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									tl.EntityCode,
									
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol'
									
							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @hdate) t

							Group by 
									
																
									t.PrimarySymbol,
									t.EntityCode
									) x
on				x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 

Where	sp.EffectiveDate between @sdate and @edate and x.EntityCode is not null

