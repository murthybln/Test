--Missing End of Day Prices for TaxLotHoldings and Flex Orders
-- Sev 2


exec MaverickSMGC.DataChecks.MissingTaxLotPrices2