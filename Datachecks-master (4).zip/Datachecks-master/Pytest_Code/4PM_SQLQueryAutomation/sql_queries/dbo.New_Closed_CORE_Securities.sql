Declare @dt as Date = GetDate()
Declare @new_pos_cnt INT, @closed_pos_cnt INT

SET NOCOUNT ON;
IF OBJECT_ID('tempdb..#new_Closed_positions_data') IS NOT NULL 
BEGIN 
    DROP TABLE #new_Closed_positions_data
END

Select 
			z.PrimarySymbol,
			z.Pos as 'PosType',
			--z.Txn_Type as 'TradeType',
			--z.Trader,
			z.Sector,
			z.Type
into #new_Closed_positions_data
From
			(SELECT 
				   Allocations.PrimarySymbol,  
				   --Allocations.Trader,
				   Pos = Case when Allocations.Done < 0 then 'S' else 'L' end,
					Allocations.TradingSector as 'Sector',
					Allocations.Trade_Date,
					Allocations.Txn_Type,
					'New Core Securities' as Type
			FROM
				   (SELECT 
						 a.Symbol, 
						 Sum(a.Shares) as Done, 
                    	-- a.TraderLogin as Trader,
						 a.Trade_Date,
						 a.Txn_Type,
						 InvestmentView.TradingSector,
						 InvestmentView.PrimarySymbol
					FROM 
								mav.dbo.AllocatedTradesByBrokerForBrokers a
					Left Join	mav.dbo.InvestmentView 
					on			InvestmentView.Symbol = a.Symbol
					WHERE		a.Trade_Date =  @dt 
					and			a.FundEntityCode in ('MVK','LEV')
					Group by    a.Symbol,
								--a.TraderLogin,
								a.Trade_Date,
								InvestmentView.TradingSector,
								InvestmentView.PrimarySymbol,
								Txn_Type
       
				   ) Allocations
			LEFT JOIN 
				   (Select 
								c.PrimarySymbol,
								OpeningPosition.HistDate,
								sum(OpeningPosition.Quantity) Qty 
					from		mav.dbo.AllocationOpeningPositionsByFund as OpeningPosition
					Left Join	mav.dbo.InvestmentView c 
					on			c.Symbol = OpeningPosition.Symbol
					Where		OpeningPosition.HistDate = @dt 
					and			OpeningPosition.EntityCode in ('MVK','LEV')
				   Group by		c.PrimarySymbol,OpeningPosition.HistDate

				   ) Positions   
       
		on				Positions.HistDate = Allocations.Trade_Date 
		AND				Positions.PrimarySymbol = Allocations.PrimarySymbol
WHERE	Isnull(Positions.Qty,0) = 0 
)z

Where	z.Txn_Type in ('Buy','Short')

UNION ALL


Select 
			z.PrimarySymbol,
			z.Pos as 'PosType',
			--z.Txn_Type as 'TradeType',
			--z.Trader,
			z.Sector,
			'Closed Core Securities' SecurityType
From
			(SELECT 
				   Allocations.PrimarySymbol,  
				   Pos = Case when Allocations.Done < 0 then 'S' else 'L' end,
					Allocations.TradingSector as 'Sector',
					Allocations.Trade_Date,
					'MAV' as Type
			FROM
				   (SELECT 
						 a.Symbol, 
						 Sum(a.Shares) as Done, 
                    	
						 a.Trade_Date,
						 InvestmentView.TradingSector,
						 InvestmentView.PrimarySymbol
					FROM 
								mav.dbo.AllocatedTradesByBrokerForBrokers a
					Left Join	mav.dbo.InvestmentView 
					on			InvestmentView.Symbol = a.Symbol
					WHERE		a.Trade_Date =  @dt 
					and			a.FundEntityCode in ('LDC','USA','LEV','MVK')
					Group by    a.Symbol,
							
								a.Trade_Date,
								InvestmentView.TradingSector,
								InvestmentView.PrimarySymbol
       
				   ) Allocations
			LEFT JOIN 
				   (Select 
								c.PrimarySymbol,
								OpeningPosition.HistDate,
								sum(OpeningPosition.Quantity) Qty 
					from		mav.dbo.AllocationOpeningPositionsByFund as OpeningPosition
					Left Join	mav.dbo.InvestmentView c 
					on			c.Symbol = OpeningPosition.Symbol
					Where		OpeningPosition.HistDate = @dt 
					and			OpeningPosition.EntityCode in ('LDC','USA','LEV','MVK')
				   Group by		c.PrimarySymbol,OpeningPosition.HistDate

				   ) Positions   
       
		on				Positions.HistDate = Allocations.Trade_Date 
		AND				Positions.PrimarySymbol = Allocations.PrimarySymbol
   
WHERE
       isnull(Positions.Qty, 0) + Allocations.Done = 0 )z

select @new_pos_cnt = COUNT(1) FROM #new_Closed_positions_data WHERE Type = 'New Core Securities'
select @closed_pos_cnt = COUNT(1) FROM #new_Closed_positions_data WHERE Type = 'Closed Core Securities'

IF (@new_pos_cnt = 0 AND @closed_pos_cnt = 0)
BEGIN
SELECT 'NONE' as 'PrimarySymbol',NULL as 'PosType',NULL as 'Sector','Closed Position' as 'Type'
UNION ALL
SELECT 'NONE' as 'PrimarySymbol',NULL as 'PosType',NULL as 'Sector','New Position' as 'Type'
END
ELSE IF (@closed_pos_cnt = 0 AND @new_pos_cnt > 0)
BEGIN
SELECT * FROM #new_Closed_positions_data
UNION ALL
SELECT 'NONE',NULL,NULL,'Closed Position'
END
ELSE IF (@closed_pos_cnt > 0 AND @new_pos_cnt = 0)
BEGIN
SELECT * FROM #new_Closed_positions_data
UNION ALL
SELECT 'NONE',NULL,NULL,'New Position'
END
ELSE
BEGIN
SELECT * FROM #new_Closed_positions_data
END
