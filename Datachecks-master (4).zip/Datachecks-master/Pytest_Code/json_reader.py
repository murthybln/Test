import json
import os
import traceback

import send_email as ft


def json_reader(dir, filename=None, include_folder=None):
    all_json = []
    json_dir = os.path.join(dir, include_folder) if include_folder else dir
    abs_path = os.path.dirname(os.path.realpath(__file__))

    if not filename:
        for root, dirs, files in os.walk(json_dir):
            for file in files:
                if file.endswith(".json"):
                    file_path = os.path.join(root, file)
                    try:

                        with open(file_path, 'r') as jp:
                            json_checks = json.load(jp)
                            all_json.append(json_checks)
                    except Exception as ex:
                        checks = json_reader(dir=abs_path, filename="config.json")
                        error_msg = traceback.format_exc().splitlines()
                        ft.send_error_email(traceback="{0} file is incorrectly formatted with below error: <br>{1}"
                                      .format(file_path, error_msg), subject="[Datachecks] Error - Incorrect JSON format", receiver=checks["support_emails"])
        return all_json

    else:
        file_path = os.path.join(json_dir, filename)
        try:

            with open(file_path, 'r') as jp:
                json_checks = json.load(jp)
                return json_checks
        except Exception as ex:
            checks = json_reader(dir=abs_path, filename="config.json")
            error_msg = traceback.format_exc().splitlines()
            ft.send_error_email(traceback="{0} file is incorrectly formatted with below error: <br>{1}"
                          .format(file_path, error_msg), subject="[Datachecks] Error - Incorrect JSON format", receiver=checks["support_emails"])
