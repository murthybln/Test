import os

"""
    Writes the data to csv file based on the given delimiter/separator
"""


def write_to_csv(data, file_path, file_name, sep=None, encoding=None, conf_link=None):
    csv_file = os.path.join(file_path, file_name)
    with open(csv_file, 'w', newline='\n') as csvf:
        csvf.write(conf_link + '\n')
    data.to_csv(csv_file, sep, encoding, mode='a', index=False)

