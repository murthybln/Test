SELECT 
		
	
		f.figi [GlobalID],
		f.Symbol,
		f.AccountType,
		isnull(i.Symbol,'Missing') as 'PaladyneSymbol',
		f.EquityType,
		f.SecurityType

From		Mav.FlexOne.BlotterSymbols f with (nolock)
Left Join	mav.dbo.investment i
on			i.Symbol = f.Symbol
WHERE		f.figi is not null
and			f.SecurityType = 'Index'

