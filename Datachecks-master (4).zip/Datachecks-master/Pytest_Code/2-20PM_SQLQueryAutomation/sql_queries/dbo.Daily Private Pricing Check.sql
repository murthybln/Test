Declare @dt as Date = GetDate()
SELECT Count(*) as 'Number of Privates Priced Today','Check PriceMaster-Manual Price Load Job' as 'Comments'
FROM PriceMaster.MarketValue.Data_RefSrc1_Price_ManualL3 lp 
JOIN PriceMaster.dbo.sec s ON s.SecId = lp.SecID
JOIN PriceMaster.dbo.SecId si on  si.SecID = lp.SecID  and si.SecIdTypeId = '30010'
Left JOIN PriceMaster.dbo.SecId sm ON sm.SecID = lp.secID and sm.SecIdTypeId = '30007'
left JOIN PriceMaster.dbo.InvestmentType it ON it.InvestmentTypeID = s.InvestmentTypeID
Left JOIN PriceMaster.dbo.sec SecCurr ON SecCurr.SecId = Case when it.Code in ('BLLT','TRS') then s.UnderlyingId else s.secid end
Left JOIN PriceMaster.dbo.Currency cur on cur.CurrencyId = SecCurr.CurrencyId
WHERE CONVERT(DateTime,lp.dayid,103) = @dt
AND sm.IdCode is not null
and		it.Code <> 'MAVFUND'
having     COunt(*) < 25

