This folder contains the sql queries for respective datachecks which run at 7 pm daily.
