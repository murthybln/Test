SELECT 
		Distinct 
		s.MasterSecID
		,sb.SecCode  
		,sb.GlobalID  
		,ISNULL(ritm.Value, rit.Code) InvestmentType
		,rts.Name TradingStatus
	
FROM		smgc.dbo.Sec s  with (nolock)
Left Join	Smgc.dbo.vw_SecBasic sb with (nolock)
on			sb.secid = s.Secid
LEFT JOIN	smgc.dbo.SecAuxCustomValues aux with (nolock)
ON			s.SecID = aux.SecID  
LEFT JOIN	smgc.dbo.RefInvestmentType rit with (nolock)
ON			aux.RefInvestmentTypeID = rit.RefInvestmentTypeID    
LEFT JOIN	smgc.dbo.RefInvestmentTypeCode ritm with (nolock)
ON			rit.RefInvestmentTypeID = ritm.RefInvestmentTypeID 
AND			ritm.RefExternalCodeTypeID = 2
LEFT JOIN	smgc.dbo.RefRegType reg with (nolock)
ON			aux.RefRegTypeID = reg.RefRegTypeID
LEFT JOIN	smgc.dbo.RefTradingStatus rts with (nolock)
ON			aux.RefTradingStatusID = rts.RefTradingStatusID

Where s.MasterSecID in (
  		select 
					Distinct MasterSecID
		from		smgc.dbo.Sec sec with (nolock)
		Left Join	SMGC.dbo.SecAttribute attr with (nolock)
		on			attr.SecID = sec.SecID
		Left Join	SMGC.dbo.CustomAttribute CustAttr with (nolock)
		on			CustAttr.CustomAttributeID = attr.CustomAttributeID 
		Where		CustAttr.Name IN ('Current Position') 
		and			attr.OutDate is null)

and		InvestmentType not in ('TRS','BLLT','INT','MAVFUND')
and		sb.SecCode not in ('SCHALLOCATION','ZVZZT','1005722Q','LGFTY')
and		s.MasterSecID not in ('1416466','1442036','1288517')
and		rts.Name in ('Delisted','Acquired')
and		sb.GlobalID is not null
order by 3
