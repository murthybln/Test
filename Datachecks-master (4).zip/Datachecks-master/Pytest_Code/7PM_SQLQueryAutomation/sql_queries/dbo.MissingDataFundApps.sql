Select 
	MasterSecId,
	Sec_Code,
	CountryCode,
	InvestmentType,
	ResourceType,
	ExceptionType,
	SharesOutstanding,
	VotingRights,
	TotalVotingShares,
	TOTAL_NON_VOTING_SHARES_VALUE,
	EQY_SH_OUT_TOT_MULT_SH

from	smgc.dbvw.UserDefinedFields
where	MastersecID in (Select MasterSecID from smgc.dbvw.CurrentPositions)
AND		InvestmentType not in ('TRS','BLLT','FIN','LOPT','OOTC','INVFUNDEQ','Index','MMKT','FXOP','WTS','FUT','RIGHTS')
and		ResourceType <> 'Private'
and		isnull(ExceptionType,'9999') <> 'Exclude from Fund Apps'
and 	Sec_Code not in ('LGFTY')
AND (
			SharesOutstanding IS NULL
		OR	VotingRights IS NULL
		OR	TotalVotingShares IS NULL
		OR	TOTAL_NON_VOTING_SHARES_VALUE IS NULL
		OR	EQY_SH_OUT_TOT_MULT_SH IS NULL
	)
