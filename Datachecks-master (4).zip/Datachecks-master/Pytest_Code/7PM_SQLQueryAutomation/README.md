This folder contains the json and sql related folders.
