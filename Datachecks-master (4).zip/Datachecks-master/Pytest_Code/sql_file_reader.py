import os
import sys

def load_sql_from_file(file_path, filename=None, include_dir=None):
    sql_dir = os.path.join(file_path, include_dir) if include_dir else file_path
    try:
        if not filename:
            for root, dirs, files in os.walk(sql_dir):
                for file in files:
                    if file.endswith(".sql"):
                        file_path = os.path.join(root, file)
                        file = open(file_path, 'r')
                        sql = " ".join(file.readlines())
            return sql
        else:
            file_path = os.path.join(sql_dir, filename)
            file = open(file_path, 'r')
            sql = " ".join(file.readlines())
            return sql
    except Exception:
        print("Unexpected error:", sys.exc_info()[0])
