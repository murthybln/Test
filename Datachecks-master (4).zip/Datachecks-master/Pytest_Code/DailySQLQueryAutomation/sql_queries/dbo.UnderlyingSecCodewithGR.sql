Select SecCode, UnderlyingSecCode
from Smgc.client.reconview
where UnderlyingSecCode like '%.GY'
and TradingStatus = 'Active'

