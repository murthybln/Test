-- MQM Universe Securities not in Paladyne
-- Daily
-- Sev 2

SELECT	
		a.SecType,
		a.Sedol,
		a.MavSector,
		a.Exchange,
		a.MavRegion,
		a.CommissionRegion,
		Replace(Replace(Replace(s.BloombergID,' US',''),' ','.'),'.GR','.GY') SecCode , 
		Replace(Replace(s.IssueTicker,' ','.'),'.GR','.GY') IssueTicker, 
		s.GlobalID, 
		s.MasterSecID 
FROM		[MavCapIQ].[dbo].[MQMUniverse_NotInPaladyne] a 
Left Join	lspaldsql.[SMGC].[dbo].[vw_SecBasic] s 
on			s.sedol = a.sedol 
where		s.ExchangeCode not in ('SGMX','TRQ','BTE','INS')