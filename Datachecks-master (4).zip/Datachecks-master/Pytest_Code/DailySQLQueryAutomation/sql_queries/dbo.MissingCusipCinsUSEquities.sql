SELECT		
			a.MasterSecID , 
			SecCode, 
			et.code as 'ExceptionType',
			a.TradingStatus
FROM		smgc.client.ReconView a
Left Join	smgc.dbo.sec s 
on			s.mastersecid = a.MasterSecId
Left Join	SMGC.dbo.UDF_Miscellaneous_0 u 
on			u.Secid = s.secid
Left Join	SMGC.dbo.UDF_RefExceptionType et 
on			et.UDF_RefExceptionTypeID = u.ExceptionType

WHERE 
	AssetType= 'Equity'
	and Country In ('US','CA')
	and CUSIP Is Null 
	and CINS Is Null
	and InvestmentType Not In ('INVFUNDEQ','PART')
	and isjunksecuritygroup='Prod'
	and TradingStatus Not In ('Delisted','Private Company','Unlisted','Excluded')
	and et.code is null
	and a.MasterSecID not in ('1420453','1417418','1418119')