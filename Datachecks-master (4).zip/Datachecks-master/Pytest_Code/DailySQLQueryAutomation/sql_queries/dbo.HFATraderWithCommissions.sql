Declare @sd as Date = GetDate() -360
Declare @ed as Date = GetDate() 



SELECT 
      GenevaTaxLotId,
	  GenevaTradeDate,
	  GenevaTransactionType	        
	  ,GenevaPortfolio
	  ,GenevaCustodianAccount
	   ,GenevaSymbol
	  ,GenevaBrokerQuantity
	  ,GenevaBrokerCommissionLocal
	  ,GenevaBrokerTradeFeesLocal
	  ,GenevaBroker   
	  ,GenevaTradername
	
FROM	Mav.dbo.TradeView tv
Where	GenevaTradeDate between @sd and @ed
and		GenevaTradername = 'HFA' 
and		GenevaBrokerCommissionLocal <> 0
and		GenevaTransactionType in ('Buy','Sell','SellShort','CoverShort')
and		GenevaAssetType not in ('Cash','Financing')  
	
  order by  2,1