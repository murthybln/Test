Declare @sd as Date = GetDate() - 90
Declare @ed as Date = GetDate()

SELECT
Distinct 	   
tc.GenevaTransactionType
,tc.GenevaTaxLotId
,syn.Synd_Id	
,st.SyndType_Desc
,tc.GenevaTradeDate
,tc.GenevaSymbol
,sb.IsSpac
,tc.GenevaCustodianAccount
,tc.GenevaPortfolio
,tc.CAPSSynd_Id [GenevaSyndicateID]
,tc.GenevaAccountType
,TC.GenevaTradername
,Case When GenevaTradername in ('SN','SD') and (tc.CAPSSynd_Id is null or tc.CAPSSynd_Id = '') then 'Missing' else 'Good' end as 'MissingSyndicateID'
,Case When tc.GenevaAccountType in ('HOT','HTI','HSW') AND	GenevaTradername NOT in ('SN','SD') then 'Difference' else 'Good' end as 'TraderCheck'
,CAse when GenevaTradername in ('SN') and tc.GenevaAccountType not in ('HOT','HTI','HSW') and sb.IsSpac <> 1 then 'Difference' else 'Good' end as 'AccountTypeCheck'
--,CAse when tc.GenevaAccountType in ('HOT','HTI','HSW') and sb.IsSpac = 1 then 'Difference' else 'Good' end as 'SPAC In HOT AccountType'




From		MavNY.dbo.SyndicateExecutionDesk sed with (nolock)
	Join	MavNY.dbo.Syndicate syn  with (nolock)
	on		syn.Synd_Id = sed.Synd_Id
	Join	MavNY.dbo.ExecutionDesk ed  with (nolock)
	on		ed.ExecDesk_Id = sed.ExecDesk_Id
	Join    Mav.dbo.TradeView tc  with (nolock)
	on      syn.Synd_TradeDate = tc.GenevaTradeDate
	and		syn.Synd_Symbol = tc.GenevaPrimarySymbol
	Join	MavNY.dbo.SyndicateType st  with (nolock)
	on		st.SyndType_Id = syn.SyndType_Id
	Join	lspaldsql.smgc.dbvw.SecurityBuilder sb
	on		sb.mastersecid = tc.GenevaMasterSecId

Where	tc.GenevaTransactionType IN ('Buy','CoverShort')
and		tc.GenevaTradeDate between @sd and @ed
and     syn.Synd_Id is not null

/*(	

(GenevaTradername in ('SN','SD')  
and			(tc.CAPSSynd_Id is null or tc.CAPSSynd_Id = ''))

or		    (tc.GenevaAccountType in ('HOT','HTI','HSW')
AND			GenevaTradername NOT in ('SN','SD') )

or		    (GenevaTradername in ('SN')  
and			sb.IsSpac <> 1
AND			tc.GenevaAccountType not in ('HOT','HTI','HSW') )
*/
and			tc.CAPSSynd_Id  is null

--or			(tc.GenevaAccountType in ('HOT','HTI','HSW') and sb.IsSpac = 1)






	