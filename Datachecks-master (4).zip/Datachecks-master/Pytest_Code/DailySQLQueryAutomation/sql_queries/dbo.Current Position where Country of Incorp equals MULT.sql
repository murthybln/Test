

Select
	Sec_Code,
	MasterSecID,
	SecurityType,
	InvestmentType,
	TradingStatus,
	eq.CNTRY_OF_INCORPORATION,
	'Need to Confirm with Legal' 'Comments'	
	


from		smgc.dbvw.Identifiers i with (nolock)
Left Join	BBGSecMaster.dbo.Equity_descriptive eq
on			eq.ID_BB_GLOBAL = i.GLOBAL_ID
where	     eq.CNTRY_OF_INCORPORATION = 'MULT'
and MasterSecID not in ('1297168')
and 
MasterSecID in 
				(	Select Distinct sec.MasterSecID
					from		SMGC.dbo.SecAttribute a
						Join	SMGC.dbo.CustomAttribute CustAttr
						on		CustAttr.CustomAttributeID = a.CustomAttributeID
						join	smgc.dbo.Sec sec
						on		sec.SecID = a.SecID
					where		CustAttr.Name = 'Current Position' and OutDate is null)

--Remove Master Secids that have been implemented into Fund Apps








