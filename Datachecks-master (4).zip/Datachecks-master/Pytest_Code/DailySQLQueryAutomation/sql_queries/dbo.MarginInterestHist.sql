


SET NOCOUNT ON; exec mav.Checks.spMarginInterestHist