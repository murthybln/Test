DECLARE @dt DATE = DATEADD(dd,-1,GETDATE());

SELECT        
				DISTINCT 
				--sm.secmasterid, 
				p.SecMasterID, 
				p.Sedol, 
				s.UnderlyingMasterSecId, 
			--	ss.UnderlyingMasterSecId,
				p.securitycode,
				p.PvtType,
				ss.SecurityCode as 'UnderlyingSecCode',
				ss.GenevaInvestmentType
				
				/*q.Gvkey as 'Quant_GvKey',
				q.iid as 'Quant_IID',
				q.EFFFROM as 'Quant_EFFFROM',
				q.EFFTHRU as 'Quant_FFTHRU'
				*/
				
FROM			Polaris.dbo.Polaris_PositionPnLBookDeNormalized p
JOIN			Polaris.dbo.Polaris_Security s
ON              p.SecMasterID = s.securityid
LEFT JOIN		Polaris.dbo.Polaris_Security ss
ON              s.UnderlyingMasterSecId = ss.Securityid
CROSS APPLY (	SELECT COALESCE(ss.UnderlyingMastersecid, s.UnderlyingMastersecid,SecMasterID) secmasterid) sm
								WHERE  asofdate = @dt
								AND    NetQuantity <> 0
								AND    AccountType <> 'PVT'
								and	   Isnull(ss.TradingStatus,'None') not in ('Unlisted')
								AND    (secgenevaassettype = 'Equity' or secinvestmenttypecode in ('TRS','BLLT'))
								AND    NOT EXISTS (
													SELECT        *
													FROM   lspaldsql.mavericksmgc.[Quant].[SecuritiesWithGvKeyIID] q
													WHERE  @dt BETWEEN startdate and enddate
													AND    sm.SecMasterID = q.mastersecid 
													 )     
And			sm.secmasterid not in ('1283833','1288777','1421482','1421483','1394624')
and			p.SecMasterID not in ('1290068','1288302')
and			PvtType not like ('pvt%')
and			isnull(ss.GenevaInvestmentType,'99') not in ('INDEX','FUT')
