SELECT 
FieldName, 
SecCode, 
MasterSecID
FROM smgc.client.LockedColumnsBySecurity 
WHERE FieldName = 'SharesOut'
and MasterSecID not in ('1283470','1422174')
