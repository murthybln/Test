SELECT 
a.SecCode
,a.MasterSecID
,a.Country
,a.CountryLegalEntity
,a.CommissionRegion
,isnull(y.Name,z.Name) [CommissionRegionDefault]
FROM SMGC.client.ReconView a
Left Join  
	(Select 
			Cty.Code
		,CommRegion.Name 

	From 	SMGC.dbo.UDF_RefCommissionRegionByCountry Cty
		Left Join 
		SMGC.dbo.UDF_RefCommissionRegionCommissionRegion CommRegion 
		on CommRegion.UDF_RefCommissionRegionCommissionRegionID = Cty.CommissionRegion) z
		on z.Code = a.Country
Left Join 
 	(Select 
			LECty.Code
		,CommRegion.Name

	From 	SMGC.dbo.UDF_RefCommissionRegionByLegalEntityCountry LECty
		Left Join 
		SMGC.dbo.UDF_RefCommissionRegionCommissionRegion CommRegion 
		on CommRegion.UDF_RefCommissionRegionCommissionRegionID = LECty.CommissionRegion) y
		on y.Code = a.CountryLegalEntity
	Where AssetType not in ('Index','Cash','Financing') and isjunksecuritygroup = 'Prod' and 
	(isnull(y.Name,z.Name)) <> a.CommissionRegion

