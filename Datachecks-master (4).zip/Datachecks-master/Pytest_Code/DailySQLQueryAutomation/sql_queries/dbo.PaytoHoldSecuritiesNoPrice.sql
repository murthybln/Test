Declare @dt as Date = GetDate()-1

SELECT 
			
			p.PrimarySymbol,
			p.MavPriceBook,
			sum(p.SectorPnL_PayToHoldFeesMonthlyBook) as 'PayToHoldFeesMonthlyBook'
		
FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized p
Left Join	Polaris.dbo.Polaris_Security s
on			s.SecurityId = p.SecMasterID
Left Join	Polaris.dbo.Polaris_Security u
on			u.SecurityId = s.UnderlyingMasterSecId
Where		p.AsOFDate = @dt
and			abs(p.SectorPnL_PayToHoldFeesMonthlyBook) > .01
and			p.MavPriceBook = 0
and			p.secgenevaassettype not in ('Cash','Financing')
Group by	p.PrimarySymbol,
			p.MavPriceBook



