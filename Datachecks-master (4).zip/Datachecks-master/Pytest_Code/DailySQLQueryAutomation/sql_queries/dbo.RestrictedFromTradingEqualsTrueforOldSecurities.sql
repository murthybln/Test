-- Restricted From Trading Equals True for Old Securities
-- Daily
-- Sev 2
Select 
		SecCode,
		MasterSecID,
		InvestmentType, 
		TradingStatus, 
		IncludeinTraderToolbox,
		RestrictedFromTrading,
		'NO' as 'DefaultIncludeinTrderToolbox',
		'TRUE' as 'DefaultRestrictedFromTrading'
from	smgc.client.reconview
where	(SecCode like '%\_OLD%' escape '\' or TradingStatus not in ('Halt-Regulatory Concerns','Active','Clean Notional','Halted','Pending','Halt - News Dissemination','Price Not Available','Private Company','Suspended','Unit Traded','Unlisted','Excluded','Restricted','PreNotice','Intraday Suspension','Volatility Interrupt','When Issued','Price Not Available','Order Imbalance','Halt - News Dissemination'))
and		RestrictedFromTrading <> 'True'
and		InvestmentType not in ('INT','TRS','BLLT')


order by 4