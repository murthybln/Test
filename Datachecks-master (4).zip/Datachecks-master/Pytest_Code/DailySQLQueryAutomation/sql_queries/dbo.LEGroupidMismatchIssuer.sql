
select
	SEC_CODE,
	MasterSecID,
	IssuerTicker,
	LegalEntityUDFGroupID,
	LegalEntityID,
	InvestmentType,
	TradingStatus,
	ExceptionType
from	smgc.dbvw.Identifiers
where	InvestmentType not in ('INT','RATE','Index','CMDT')
and		(isnull(LegalEntityUDFGroupID,'Missing') <>  replace(IssuerTicker,' ', '.')
or		IssuerTicker is null)
--and		ExceptionType <> 'Old TR Security'
--and		TradingStatus not in ('Delisted','Expired')
and		MasterSecID not in ('1293014','1403806','1393700','24218','1290660','1294584','1293625','1300098','1300422','1303926','1397443','1397442','1397444','1397446','1283961','1284366','1284367','1285473')
order by 4