SELECT 
	Distinct 
	AsOfDate,
	a.PrimarySymbol,
	a.SecurityCode,
	a.securityname,
	a.ResourceType,
	LongShortNet AS 'LongShortNet',
	sb.LSTrackingSide

	
FROM Polaris.dbo.Polaris_PositionPnLBookDeNormalized  a with (nolock)
Left Join	lspaldsql.smgc.dbvw.UserDefinedFields sb with (nolock)
on			sb.MasterSecID = a.SecMasterID
Where AsOfDate = (Select max(AsOfDate) from Polaris.dbo.Polaris_PositionPnLBookDeNormalized)
		and	(ShortQty <> 0 or LongQty <> 0 ) 
		and secgenevaassettype in ('OP')
		and secinvestmenttypecode not in ('FXOP')
		and LongShortNet <> Isnull(sb.LSTrackingSide,'NONE')