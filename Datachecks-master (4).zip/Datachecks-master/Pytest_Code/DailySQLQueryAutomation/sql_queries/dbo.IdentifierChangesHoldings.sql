--Upcoming Identifier Changes (Holdings)
-- Daily
--Sev 1

DECLARE @sd as Date = GetDate()+1
DECLARE @ed as Date = GetDate()+2

SELECT Distinct 
	
		convert(varchar(100), CONVERT (INT,s.MasterSecID )) [MasterSecID]
		,st.TypeName as 'SecTypeName'
		,si.IdStartDate
		,sit.CodeTypeName as 'SecIdCodeTypeName'
		,si.SecCode as 'New ID',
		isnull(tl.symbol,tl2.Symbol) as 'HoldingsSymbol',
		inv.Symbol
		--Case when tl.EntityCode in ('MFN','MFQ','UCQ','QSL','QSN','UCM') then 'Y' else 'N' end as 'QuantHoldings'
		--Case when q.Symbol is null then 'N' else 'Y' end as 'InQuantUniverse' 



FROM		LSPALDSQL.SMGC.dbo.SecIdCode si
Join		LSPALDSQL.SMGC.dbo.RefSecIDCodeType sit 
on			sit.SecIDCodeTypeID = si.SecIdCodeTypeId
Join		LSPALDSQL.smgc.dbo.sec s 
on			s.secid = si.secid
Join	    LSPALDSQL.SMGC.dbo.RefSecType st 
on			st.RefSecTypeId = s.RefSecTypeID
Join		mav.dbo.investment inv 
on			inv.mastersecid = s.mastersecid
Left Join	mav.dbo.TaxLotPositionHist tl 
on			tl.symbol = inv.symbol 
and			HistDate between @sd and @ed
Left Join	mav.dbo.TaxLotPositionHist tl2 
on			inv.UnderlyingSymbol = tl2.Symbol 
and			tl2.HistDate between @sd and @ed
Left Join	lsQuanSQL.Quant2.dbo.QuantUniverse q
on			q.Symbol = inv.Symbol 





where		sit.CodeTypeName in ('SEDOL','ISIN','CUSIP','BLMBRG_ID','Name')
and			s.RefSecTypeID not in ('1','2','3','801','401')
and			si.IdStartDate between @sd and @ed
and			si.SecCode is not null
and			inv.TradingZone is not null
and			(tl.EntityCode is not null or Q.Symbol is not null)
 

Order by 3,1
