-- Bulk vs Paladyne Voting Details
-- Daily
-- Sev-4



Select Distinct 
     rec.SecCode
    ,rec.MasterSecID
    ,sei.SharesOut [Paladyne_OS]
    ,eq.EQY_SH_OUT_REAL [Bulk_OS]
	,sei.VotingRights [Paladyne_Rights]
	,eq.VOTING_RIGHTS [Bulk_Rights]
	,ms.TotalVotingShares [Paladyne_VotingShares]
	,eq.TOTAL_VOTING_SHARES_VALUE [Bulk_VotingShares]	
	,sei.SharesOutDate [Paladyne_OS_Date]
	,eq.EQY_SH_OUT_DT [Bulk_OS_Date]
	,eq.MARKET_STATUS
	

	
	
	


from		smgc.dbo.vw_SecBasic rec
Join		smgc.dbo.sec sec 
on			sec.MasterSecId = rec.MasterSecID
Join		smgc.dbo.SecEquityIssue sei
on			sei.secid = sec.secid
Join        SMGC.dbo.[UDF_Miscellaneous_0] ms
on			ms.SecId = sec.Secid
Join		BBGSecMaster.dbo.EQUITY_DESCRIPTIVE eq
on			eq.ID_BB_GLOBAL = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666675,GetDate()) 
where       rec.SecCode is not null
and			(sei.SharesOut <>eq.EQY_SH_OUT_REAL
				or sei.VotingRights <> eq.VOTING_RIGHTS
				or ms.TotalVotingShares <> eq.TOTAL_VOTING_SHARES_VALUE	
				or sei.SharesOutDate <> eq.EQY_SH_OUT_DT
			)
and			sei.SharesOut <> 0
and			eq.MARKET_STATUS not in ('DLST','ACQU')