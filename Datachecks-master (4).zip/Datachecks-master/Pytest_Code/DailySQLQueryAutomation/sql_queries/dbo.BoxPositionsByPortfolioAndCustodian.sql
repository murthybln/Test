Declare @date DATE = DATEADD(day,-1,GetDate())

SELECT 
		b.AsOfDate,
		b.securitycode,
		b.Portfolio,
		--stratcode,
		b.CustodianNameCode,
		REPLACE(CONVERT(VARCHAR,CAST(ROUND(sum(b.LongQty),0) AS MONEY), 1),'.00', '') as 'LongQty',		
	REPLACE(CONVERT(VARCHAR,CAST(ROUND(sum(b.ShortQty),0) AS MONEY), 1),'.00', '') as 'ShortQty',		
	REPLACE(CONVERT(VARCHAR,CAST(ROUND(sum(b.NetQuantity),0) AS MONEY), 1),'.00', '') as 'NetQuantity',		
	 max(b.ClosingPriceBook) [ClosingPriceBook], 
	REPLACE(CONVERT(VARCHAR,CAST(ROUND(sum(b.AssetAllocation_MarketValueBook),0) AS MONEY), 1),'.00', '') as 'NetMarketValueBook'		
	FROM	Polaris.dbo.Polaris_PositionPnLBookDeNormalized b   with (nolock)

Join 

		(SELECT 
				AsOfDate,
				a.securitycode,
				Portfolio
			FROM	Polaris.dbo.Polaris_PositionPnLBookDeNormalized  a with (nolock)
			Where	a.AsOFDate = @date
			and		a.Portfolio not in ('GRO','MDI','C01')
			Group by  
				AsOfDate,
				a.portfolio,
				a.LongShortNet,
				a.securitycode
			having Sum(ShortQty) <> 0 and sum(LongQty) <> 0) x

on		x.AsofDate = b.AsOfDate
and		x.Portfolio = b.Portfolio
and		x.SecurityCode = b.SecurityCode

Where	b.AsOFDate = @date
and		(b.LongQty <> 0 or b.ShortQty <> 0)

Group By
		b.AsOfDate,
		b.securitycode,
		b.Portfolio,
		b.CustodianNameCode



	