Select 
	AsOfDate,
	SecurityCode,
	SecMasterID,
	SecMavSector,
	SectorHead,
	AccountType,
	Flip_Desc,
	DefaultMavSector,
	DefaultSectorHead




From


			(SELECT Distinct
					p.AsOfDate
				,p.securitycode
				,p.SecMasterID
				,P.SecMavSector
				,p.SectorHead
				,p.AccountType
				,flp.Flip_Desc
				,Case when syn.Flip_Id = 1 then 'SN' else P.SecMavSector end [DefaultMavSector]
				,Case when syn.Flip_Id = 1 then 'Syndicate' else p.SectorHead end [DefaultSectorHead]
				,Case when syn.Flip_Id = 1 and (P.SecMavSector <> 'SN' or p.SectorHead <> 'Syndicate') then 'Difference' else 'Good' end [Syndicate_Check]
				,Case when syn.Flip_Id <> 1 and (P.SecMavSector = 'SN' or p.SectorHead = 'Syndicate') then 'Difference' else 'Good' end [SyndicateSH_Check]




			FROM			lsplrsSQL.Polaris.dbo.Polaris_PositionPnLBookDeNormalized p with (nolock)
				Left Join	MavNY.dbo.Syndicate syn 
				on			Syn.Synd_Symbol = p.securitycode
				Left Join	MavNY.dbo.DeskFlipType flp 
				on			flp.Flip_Id = syn.Flip_Id
	

			WHERE 
						p.AsOfDate > (Select max(AsOFDate) - 5 from  lsplrsSQL.Polaris.dbo.Polaris_PositionPnLBookDeNormalized)
				and		(AccountType = 'HOT' or P.SecMavSector in ('SD','SN'))
				and		(p.LongQty <> 0 or p.ShortQty <> 0 or IVPGroup_Summary_AllRevExpDailyBook <> 0)
				and		secgenevaassettype not in ('Cash','Financing')) x

Where		(x.SecMavSector <> x.DefaultMavSector
	or		x.SectorHead <> x.DefaultSectorHead
	or		x.Syndicate_Check <> 'Good'
	or		x.SyndicateSH_Check <> 'Good')
and		SecMasterID not in ('1418497')

