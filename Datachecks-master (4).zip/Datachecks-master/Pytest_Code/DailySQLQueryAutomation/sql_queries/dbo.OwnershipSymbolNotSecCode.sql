-- Ownership Symbol not current SecCode
-- Daily
-- Serv 2



select		s.MasterSecID
			,smgc.dbo.fn_GetActualIdentifier(s.SecID, 300019, GETDATE()) SecCode
			, smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 666669,GetDate()) as OWNERSHIP_SYMBOL
			,  ISNULL(ritm.Value, rit.Code) InvestmentType
				,replace(s.issueticker,' ','.') as 'GroupID'
		
from		smgc.dbo.sec s
INNER JOIN	smgc.dbo.[vwSecAttributeActive] sa on sa.secid = s.secid and sa.customattributeid = 6
INNER JOIN 
			(
			SELECT			ss.MasterSecID
							, RefClientID = MAX( ISNULL( ss.RefClientID, 0)) 
			FROM			smgc.[dbo].[Sec] ss WITH(NOLOCK) 
			WHERE			(ss.RefClientID IS NULL OR ss.RefClientID = 2) 
			GROUP BY		ss.MasterSecID 
			) t1 
 ON			t1.MasterSecID = s.MasterSecID 
 AND		(t1.RefClientID = s.RefClientID OR t1.RefClientID = 0 AND s.RefClientID IS NULL)
LEFT JOIN	smgc.dbo.SecAuxCustomValues aux ON s.SecID = aux.SecID    
LEFT JOIN	smgc.dbo.RefInvestmentType rit ON aux.RefInvestmentTypeID = rit.RefInvestmentTypeID    
LEFT JOIN	smgc.dbo.RefInvestmentTypeCode ritm ON rit.RefInvestmentTypeID = ritm.RefInvestmentTypeID AND ritm.RefExternalCodeTypeID = 2 --GENEVA CODE
where		ISNULL(ritm.Value, rit.Code) not in ('INT','INDEX','HEDGE','CASH','FDWFX','CCY') 
and			s.issueticker not in (' ','YCINV','YCJAN13','YCJUN13')
and			NOT EXISTS (select * from smgc.dbo.SecAttribute sa where CustomAttributeID in (10,11) and sa.secid = s.secid)
and			NOT EXISTS (select * from smgc.dbo.SecIdCode c WITH(NOLOCK) where c.secidcodetypeid = 300019 and c.IdStartDate <= getdate() and seccode = smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 666669,GetDate()) )
and			s.RefSecTypeID != 2 
AND			datepart(dw,GetDate()) not in (7)
and			smgc.dbo.fn_GetActualIdentifier(s.SecID, 300019, GETDATE()) is not null
and			 ISNULL(ritm.Value, rit.Code) not in ('TRS','BLLT','CMDT')
and			s.MasterSecID not in ('1412198','1412288','1377912')
