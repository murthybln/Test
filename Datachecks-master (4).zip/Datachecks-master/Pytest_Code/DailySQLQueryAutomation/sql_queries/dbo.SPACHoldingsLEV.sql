Declare @dt as Date = GetDate()-1

SELECT 
		p.AsOfDate
		,p.Portfolio
		,p.SecurityCode
		,p.PrimarySymbol
        ,p.SecInvestmentGroup_TS as 'InvGroup'
		,p.secinvestmenttypecode as 'InvType'
		,Bloom.Description [BloomIndustry_Name]
		,sum(p.NetQuantity) as 'NetQuantity'
		,sum(p.TradeDateCashBalanceBook) as 'TradeDateCashBalanceBook'

FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized p with (nolock)
Left Join	lspaldsql.smgc.dbo.Sec sec with (nolock)
on			sec.MasterSecID = p.SecMasterID
Left Join	lspaldsql.SMGC.dbo.vw_SecIndustry secind with (nolock)
on			secind.SecID = sec.SecID 
Left Join	lspaldsql.smgc.dbo.vw_RefIndustryCode bloom with (nolock)
on			Bloom.RefIndustryCodeID = secind.RefIndustryCodeID_Bloomberg
Join        (SELECT 
					p.AsOfDate
					,p.Portfolio 
					,sum(p.TradeDateCashBalanceBook) as 'TradeDateCashBalanceBook'

			FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized p with (nolock)
			Left Join	lspaldsql.smgc.dbo.Sec sec with (nolock)
			on			sec.MasterSecID = p.SecMasterID
			Left Join	lspaldsql.SMGC.dbo.vw_SecIndustry secind with (nolock)
			on			secind.SecID = sec.SecID 
			Left Join	lspaldsql.smgc.dbo.vw_RefIndustryCode bloom with (nolock)
			on			Bloom.RefIndustryCodeID = secind.RefIndustryCodeID_Bloomberg


			where		NetQuantity <> 0
			and			p.AsOfDate = @dt
			and		    bloom.IndustryCodeID = '308'
			and			p.portfolio = 'LEV'
			Group By	p.AsOfDate
		   ,p.Portfolio		
			
				) l
on			l.AsOfDate = p.AsOfDate
and			l.portfolio = p.portfolio





where		NetQuantity <> 0
and			p.AsOfDate = @dt
and		    bloom.IndustryCodeID = '308'
and			p.portfolio = 'LEV'	

Group By	p.portfolio
			,p.AsOfDate
			,p.SecurityCode
			,Bloom.Description
			,p.PrimarySymbol
			,p.SecInvestmentGroup_TS
			,p.secinvestmenttypecode
