Select * from 
(SELECT 
		HistDate
		,AMAVName
		,AMAVSymbol
		,Case when AmavName like '%Long' then 'L'
			when AmavName like '%Short' then 'S'
			Else PosType end as [DefaultPosType]
		,PosType
	FROM Mav.dbo.AllMavPositionHistView
	Where HIstDate = (Select max(HistDate) from Mav.dbo.AllMavPositionHistView) and (AmavName like '%Long' or AmavName like '%Short') ) x
	Where DefaultPosType <> PosType
	and		AmavSymbol not in ('IFF')
