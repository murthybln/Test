

SELECT        i.*,s.MasterSecID
FROM          smgc.dbo.UDF_QuantInvID i
JOIN          smgc.dbo.UDF_QuantInvID i2
ON            i.secid = i2.SecID
AND            i.UDF_QuantInvIDID <> i2.UDF_QuantInvIDID
Join			smgc.dbo.sec s 
on				s.secid = i.secid
WHERE         i.startdate between i2.startdate AND i2.endDate
OR                   i.enddate between i2.startdate and i2.enddate



