DECLARE @dt DATETIME = GETDATE(), @dtwhole DATE = GETDATE();
DECLARE @sdate DATETIME = DATEADD(day,0,@dtwhole)
    , @edate DATETIME = DATEADD(day,7,@dtwhole);



SELECT           Distinct
				  sec.MasterSecID
				  ,smgc.dbo.fn_GetActualIdentifier (sec.SecId, 666667, GetDate()) as 'PrimarySymbol'
				   ,CONVERT(VARCHAR(10),Cast(d.Eff_date  as Date),101) as 'EX_DT'
				   ,CONVERT(VARCHAR(10),Cast(d.CP_PAY_DT as Date),101) as 'CP_PAY_DT'
				  ,d.CP_DVD_CRNCY as 'DVD_Currency'
				  ,bbg.CRNCY as 'SecurityCurrency'
				  ,Case when d.CP_DVD_CRNCY = bbg.CRNCY then 'Yes' else 'No' end as 'SameCurrency'
				  ,t.BLANK_FIELD as 'DividendType'
				  ,d.CP_BONUS_AMT as 'Bonus_Amount'
				  ,s.BLANK_FIELD as 'OptionType'
				  ,d.CP_NOTES as 'Notes'
				  ,Isnull(d.CP_NET_AMT,0) as 'Net_Amount'
				  ,isnull(d.CP_TAX_AMT,0) as 'Tax_Amount'
				  ,d.CP_GROSS_AMT as 'Gross_Amount'
				  ,x.NetQuantity
				  ,x.EntityCode
		
      
			  FROM			    BBGSecMaster.dbo.EQUITY_DESCRIPTIVE bbg 	
				 Join 			smgc.dbo.sec sec
				 on 			bbg.ID_BB_GLOBAL =	isnull(smgc.dbo.fn_GetActualIdentifier (sec.SecId, 666675, GetDate()),smgc.dbo.fn_GetActualIdentifier (sec.SecId, 300110, GetDate()))
				 Join			smgc.dbo.RefSecType st
				 on				sec.RefSecTypeID = st.RefSecTypeID
				 Join			BBGSecMaster.dbo.DVD_CASH d 
				 on				d.ID_BB_GLOBAL = bbg.ID_BB_GLOBAL
				 Join			BBGSecMaster.dbo.LU_CP_DVD_TYP t 
				 on				t.CP_DVD_TYP = d.CP_DVD_TYP
				 Join			BBGSecMaster.dbo.LU_CP_STOCK_OPT s 
				 on				s.CP_STOCK_OPT = d.CP_STOCK_OPT
				  Left Join 
				(Select 
							t.HistDate,
							t.Symbol,
							t.EntityCode,
							t.PrimarySymbol,
							
							sum(t.Quantity) as 'NetQuantity'


				from 
							(Select 
									tl.HistDate,
									tl.Symbol,
									tl.Quantity,
									tl.EntityCode,
		
									Case when inv.Product = 'Swap' then inv.Ticker 
										 else  tl.Symbol
										 end as 'PrimarySymbol'

							from	lsmavgsql.mav.dbo.TaxLotPositionHist tl
							Join	lsmavgsql.mav.dbo.Investment inv
							on		inv.Symbol = tl.Symbol
							where	tl.HistDate = @dtwhole) t

							Group by 
									t.HistDate,
									t.Symbol,
									t.EntityCode,
									t.PrimarySymbol
									) x
		on x.PrimarySymbol = smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 666667, GetDate()) 

   CROSS APPLY (SELECT        TOP 1 *
                     FROM          BBGSecMaster.dbo.DVD_CASH s
                     WHERE         s.ID_BB_GLOBAL = d.ID_BB_GLOBAL
                     AND                  s.Eff_date Between @sdate and @edate
                     ORDER BY      s.CreateDate DESC) mx
WHERE         d.Eff_Date Between @sdate and @edate
AND                  d.CreateDate = mx.CreateDate
AND                  d.ID_BB_GLOBAL = mx.ID_BB_GLOBAL
and			smgc.dbo.fn_GetActualIdentifier (sec.SecId, 666667, GetDate())  is not null
and			x.EntityCode is not null
AND			datepart(dw,GetDate()) not in (1,7)
and			s.BLANK_FIELD = 'Script Dividend'
order by 3,2


