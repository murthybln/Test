SELECT     
	Distinct
	GenevaBroker 
	,GenevaPrimaryBroker
	,GenevaBrokerType
	,isnull(b.Code,'Missing') [MDS_Broker]
	,isnull(p.PrimaryBroker,'Missing') [MDS_PrimaryBroker]
	,isnull(b.BrokerType_Code,'Missing') [MDS_BrokerType]
--	,isnull(t2.Code,'Missing') [MAVG_Broker]
	--,t2.Description [MAVG_BrokerName]
	


FROM		Mav.dbo.TradeView t1
--Left Join	mav.dbo.ExecutingBroker t2 
--on			t2.Code = t1.GenevaBroker
Left Join	lsbobisql.ReferenceData.mdm.Brokers b 
on			b.code = t1.GenevaBroker
Left JOIN	lsbobisql.referencedata.mdm.PrimaryBroker p 
ON			GenevaPrimaryBroker = p.PrimaryBroker

Where Isnull(CAPSSyndicateBroker,GenevaBroker) <> '' 
	and GenevaTradeDate > GetDate() - 30
	and GenevaBrokerType not in ('Sweep','OTHER','REBAL','REORG','Private')
	and GenevaAssetType not in ('Cash') 
	and (p.PrimaryBroker is null or b.Code is null)

