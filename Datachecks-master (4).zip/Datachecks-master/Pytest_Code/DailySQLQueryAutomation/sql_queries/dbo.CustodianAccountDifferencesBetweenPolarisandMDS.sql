-- Custodian Account Differences between Polaris and MDS
-- Serv 4
-- Run Daily
SELECT
       Isnull(NameSort,md.code) as 'CustodianAccount'
   --   ,NameLine1 as 'Name_Polaris'
	--  ,md.name as 'Name_MDS'
      ,HotIssueFlag
      ,[Custodian Namesort] as 'Custodian_Polaris'
	  ,md.Custodian_Code as 'Custodian_MDS'
      ,UDF_AccountType as 'AccountType_Polaris'
	  ,md.AccountType_Code as 'AccountType_MDS'
      ,UDF_PrimaryEntity as 'PrimaryEntity_Polaris'
	  ,md.Portfolio_Code as 'PrimaryEntity_MDS'
	  ,NameLine1 as 'Name_Polaris'
	  ,md.name as 'Name_MDS'
	  ,Case when NameLine1 = md.name then 'Y' else 'N' end as 'IsSameName'
      ,Case when [Custodian Namesort] = md.Custodian_Code then 'Y' else 'N' end as 'IsSameCustodian'
	  ,CAse when UDF_AccountType = md.AccountType_Code then 'Y' else 'N' end as 'IsSameAccountType'
	  ,Case when UDF_PrimaryEntity = md.Portfolio_Code then 'Y' else 'N' end as 'IsSamePrimaryEntity'
  FROM Polaris.dbo.Polaris_Ref_CustodianAcc pl
  Full Outer Join lsBOBISQL.ReferenceData.mdm.CustodianAccount md
  on	md.code = pl.NameSort
  where EndDate > GetDate()
  and
  (
		NameLine1 <> md.name
	or  [Custodian Namesort] <> md.Custodian_Code
	or	UDF_AccountType <> md.AccountType_Code
	or  UDF_PrimaryEntity <> md.Portfolio_Code
	or md.code is null
	or NameSort is null
	)
and NameSort not in ('CS-TRN-LNS','CS-TRN-SEL','GenevaCustodianAccount','GenevaModelCustodianAccount','GenevaUnallocatedCustodianAccount','MS-COL-TPQ','MS-CSH-TPQ','MS-MGN-TPQ','PV-PVT-DGF','PV-PVT-DGL','PV-PVT-DGU')