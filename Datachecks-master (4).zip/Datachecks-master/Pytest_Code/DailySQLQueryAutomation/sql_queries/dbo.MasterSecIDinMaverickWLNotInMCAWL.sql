 --MasterSecID in MCA Security Group and Not in MCAWL
 --Daily
 --Sev2
 
 
 select  
		smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as 'SecCode'
		,sec.MasterSecID
		,sa.Secid 
		,ca.Code as 'SecurityGroup'
 from	SMGC.dbo.SecAttribute sa
 Join	smgc.dbo.CustomAttribute ca
 on		ca.CustomAttributeID = sa.CustomAttributeID
 join   smgc.dbo.sec sec 
 on		sec.secid = sa.secid
where	sa.OutDate is null
and		sa.CustomAttributeID not in (0,1)
and     sa.Secid not in (Select distinct SecId from SMGC.dbo.SecAttribute where CustomAttributeID = 6 and OutDate is null)	
 	
group by sa.secid,ca.code,sec.secid,sec.mastersecid

order by 3
 



 