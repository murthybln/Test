Declare @dt as Date = (Select max(AsOfDate) from Polaris.dbo.Polaris_PositionPnLBookDeNormalized with (nolock))  
Declare @sdate  as DATE = DATEADD(day,0,GetDate());
Declare @edate  as DATE = DATEADD(day,6,GetDate());
SELECT 
		Distinct
		p.portfolio,
		p.SecMasterID 	,
		p.securitycode ,
		p.PrimarySymbol ,
		sum(isnull(p.LongQty,0)) as 'LongQty',
		sum(isnull(p.ShortQty,0)) as 'ShortQty',
		dv.ExDivDate,
		dv.RecordDate,
		dv.PayDate,
		dv.DivGrossAmt,
        dv.NetDividend,
        dv.TaxAmount
	

FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized p with (nolock)
Left Join	lsPALDSQL.SMGC.dbvw.Identifiers t 
on			t.PrimarySymbol = p.PrimarySymbol
Left Join	(Select Distinct 
					ExDivDate,
					RecordDate,
					PayDate,
					DivGrossAmt,
					NetDividend,
					TaxAmount,
					RefCurrencyID,
					SecId
		from lsPALDSQL.[SMGC].[dbo].[SecDividends]) dv 
on			dv.secId = t.SecID
and			dv.ExDivDate between @sdate and @edate
Where		p.AsOfDate = @dt
and			p.secgenevaassettype not in ('Cash','Financing') 
and			(P.LongQty <> 0 or p.ShortQty <> 0) 
and			dv.SecID is not null 
and			(dv.PayDate is null or dv.DivGrossAmt is null or abs(dv.DivGrossAmt) < 0.0001)

Group by	

		p.portfolio,
		dv.ExDivDate,
		dv.PayDate,
		p.SecMasterID 	,
		p.securitycode ,
		p.PrimarySymbol ,
		dv.DivGrossAmt,
        dv.NetDividend,
        dv.TaxAmount,
		dv.RecordDate
	

order by	dv.ExDivDate,p.PrimarySymbol 