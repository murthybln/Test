-- RegType Recon Paladyne to MDS
-- Daily
--Sev 4

SELECT
	   m.Code as [MDS_Code]
      ,m.Name as [MDS_Name]
	  ,p.RegTypeName as [Paladyne_Name]
	 
 
  FROM lsBOBISQL.ReferenceData.mdm.RegTypes m
 Left join SMGC.dbo.RefRegType p
  on p.RegTypeName = m.Code

 where (m.code is null or m.code <> p.RegTypeName)
 and Len(p.Code) > 3

 order by p.code



