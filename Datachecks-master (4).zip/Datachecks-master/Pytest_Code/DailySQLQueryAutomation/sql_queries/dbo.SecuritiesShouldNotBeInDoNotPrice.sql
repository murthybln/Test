--Securities should not be in Do Not Price Security Group
-- Daily
-- Sev 2


SELECT 
		Distinct 
		a.MasterSecID
		,a.SecCode     
		,a.TradingStatus
		,RestrictedFromTrading
FROM	SMGC.client.ReconView a with (nolock)
Where	a.MAsterSecID in (
  		select 
					Distinct MasterSecID
		from		smgc.dbo.Sec sec with (nolock)
		Left Join	SMGC.dbo.SecAttribute attr with (nolock)
		on			attr.SecID = sec.SecID
		Left Join	SMGC.dbo.CustomAttribute CustAttr with (nolock)
		on			CustAttr.CustomAttributeID = attr.CustomAttributeID 
		Where		CustAttr.Name = 'Do Not Price' 
		and			attr.OutDate is null)
and		TradingStatus not in ('Delisted','Expired','Matured','Excluded','Ticker Change','Price Not Available','Private Company','Unlisted')
and		InvestmentType not in ('TRS','BLLT','INT')
and		a.SecCode not in ('iRN1W','IRN1M','IRN3M','KWN+1W','KWN+1M','KWN+3M','CCN+1W','CCN+1M','CCN+3M')
and		isjunksecuritygroup = 'Prod'
order by 3
