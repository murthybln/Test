Select 	
        
		MasterSecID, 
		Sec_Code, 
		sb.SHARE_CLASS_LEVEL, 
		sb.BULK_ALT_ID, 
		sb.InvestmentType, 
		bbg.ID_BB_GLOBAL_SHARE_CLASS_LEVEL 
from		smgc.dbvw.securitybuilder sb 
Left Join   BBGSecMaster.dbo.EQUITY_DESCRIPTIVE bbg 
on			bbg.ID_BB_GLOBAL = sb.BULK_ALT_ID 
where		bbg.ID_BB_GLOBAL_SHARE_CLASS_LEVEL is not null 
and			sb.SHARE_CLASS_LEVEL is null