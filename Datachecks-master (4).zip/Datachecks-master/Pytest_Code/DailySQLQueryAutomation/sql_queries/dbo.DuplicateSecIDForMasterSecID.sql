-- Multiple SecId's for Same MasterSecID
-- Run Daily
-- Sev-4

SELECT 
				   s.SecId
				   ,ms.IdCode as 'MasterSecID'
				   ,sc.IdCode as 'SecCode'
				


			  FROM               [PriceMaster].[dbo].[Sec] s
			  Left Join          [PriceMaster].[dbo].[SecId] ms on ms.secid = s.secid and ms.SecIdTypeId = 30007
			  Left Join          [PriceMaster].[dbo].[SecId] sc on sc.secid = s.secid and sc.SecIdTypeId = 30010
			  Where				 ms.idcode in
			  			(SELECT		ms.IdCode as 'MasterSecID'
						FROM		PriceMaster.dbo.Sec s
						Join   PriceMaster.dbo.SecId ms 
						on			ms.secid = s.secid 
						and			ms.SecIdTypeId = 30007
						Group by ms.IdCode 
						having count(s.secid) > 1)
order by 2