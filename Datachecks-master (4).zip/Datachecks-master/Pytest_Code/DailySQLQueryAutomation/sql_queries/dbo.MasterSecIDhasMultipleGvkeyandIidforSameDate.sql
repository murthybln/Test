
SELECT Distinct      convert(varchar(100), CONVERT (INT,s.MasterSecID )) [MasterSecID],smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 300019,GetDate()) as 'SEC_CODE', smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 300110,GetDate()) as 'GLOBAL_ID', smgc.[dbo].[fn_GetActualIdentifier] (s.SecId, 300003,GetDate()) as 'SEDOL', i.GvKey, i.IID,i.CreateDate,i.ChangeDate,i.StartDate,i.EndDate
FROM          smgc.dbo.UDF_QuantInvID i
JOIN          smgc.dbo.UDF_QuantInvID i2

ON                   i.GvKey = i2.GvKey
AND                  i.iid = i2.iid
AND                  i.UDF_QuantInvIDID <> i2.UDF_QuantInvIDID
Join smgc.dbo.sec s on s.secid = i.secid
WHERE         (i.startdate between i2.startdate AND i2.endDate
OR                   i.enddate between i2.startdate and i2.enddate)

order by 5,6
