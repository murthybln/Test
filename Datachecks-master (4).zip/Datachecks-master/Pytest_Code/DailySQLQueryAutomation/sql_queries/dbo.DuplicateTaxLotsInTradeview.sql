-- Duplicate TaxLots in TradeView
-- Run Once a day

Select Distinct 
			    
                     GenevaTradeDate,
                     GenevaSymbol,
                     GenevaBroker,
                     GenevaPrimaryBroker,
                     CommissionBrokerName

from	Mav.dbo.TradeView with (nolock)
where	GenevaTaxLotId in

			(Select
					GenevaTaxLotId

			from		Mav.dbo.TradeView  with (nolock)
			where		GenevaBrokerQuantity <> 0
			and			GenevaTradeDate > DATEADD(s,-1,DATEADD(yy,DATEDIFF(yy,0,GETDATE()),0))
			group by	GenevaTaxLotId
			Having		count(GenevaSymbol) > 1)

order by 1