-- HedgeServ Positions Custodian Account not in MDS
-- Serv 4
-- Run Daily

Declare @dt as Date = GetDate()-2
SELECT Distinct 
      [HS Fund Code]
      ,[CL_CustAccount]
      ,[CL_MasterSecID]
      ,[Instrument ID]
  FROM [Polaris].[dbo].[Polaris_PreStaging_HS_Position] pl
 Where CL_CustAccount not in (Select code from lsBOBISQL.ReferenceData.mdm.CustodianAccount)
 and day > @dt
 
 
 