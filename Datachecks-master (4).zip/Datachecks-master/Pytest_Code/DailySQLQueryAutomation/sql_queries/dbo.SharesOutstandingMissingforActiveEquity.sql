SELECT 
	Distinct
	convert(varchar(100), CONVERT (INT,t.MasterSecID )) [MasterSecID]
	,t.Sec_Code
	,t.GLOBAL_ID
	,t.TradingStatus
	,t.SharesOutstanding
	,t.InvestmentType
	,LegalEntityUDFGroupID
	,rt.TypeName as 'SecTypeName'

FROM		SMGC.dbvw.UserDefinedFields t
Join		SMGC.dbo.RefSecType rt
on			rt.RefSecTypeId = t.INTERNAL_SECURITY_SECTYPE_ID
Where		TradingStatus not in ('Delisted','Excluded','Matured','Ticker Change','Price Not Available','Restricted','Private Company','Unlisted','EXPIRED')
and			rt.TypeName in ('Equity','Depository Receipt','Equity Unit') 
and			(t.SharesOutstanding is null or t.SharesOutstanding = '9999999.990000')
and			t.MasterSecID not in ('1409073','1412341')