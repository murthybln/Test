SELECT 
		a.MasterSecID , 	
		a.SecCode, RestrictedEntities, AssetType , InvestmentType, a.Country, a.ResourceType
FROM	SMGC.client.ReconView a
WHERE 
		(a.AssetType in ('Bond','OP','SWAP')
		or a.ResourceType = 'Private'
		or a.Country in ('IN') 
		or a.InvestmentType in ('RCVYLOCK','CDS','CDX','COMMON_R','SV')
		
		)
		and a.RestrictedEntities not like ('%SHH%') 
		and InvestmentType not in ('TRS','BLLT','INT','INDEX','RATE','CCY','HEDGE','FDWFX')
		and a.TradingStatus not in ('Delisted','Expired','Excluded','Matured')
		and a.InvestmentType not in ('CMSV')

