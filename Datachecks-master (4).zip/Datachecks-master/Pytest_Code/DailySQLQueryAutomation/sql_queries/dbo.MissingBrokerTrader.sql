Declare @ed as Date = GetDate() 
Declare @sd as Date = DATEADD(month,-3,@ed)  

SELECT 
      TaxLotId ,
	  TradeDate,
	  TransactionType,        
	  Portfolio,
	  CustodianAccount,
	  Symbol,
	  MasterSecID,
	  InvestmentType,
	  Quantity,
	  Commissions,
	  TradeFees,
	  Broker, 
	  PrimaryBroker, 
	  Tradername,
	  Strategy,
	  ExchangeCode
	
FROM	Mav.dbo.Trade tv
Where	TradeDate between @sd and @ed
and		( 
		Tradername = '' 
		or Broker = '' 
		or Strategy = ''
		or Symbol = ''
		or Symbol is null
		or Portfolio = ''
		or Portfolio is null
		or MasterSecId is null
		or MasterSecId = ''
		or CustodianAccount = ''
		or CustodianAccount is null
		or PrimaryBroker = ''
		or PrimaryBroker is null
		or TransactionType = ''
		or TransactionType is null
		
		)
and		TransactionType in ('Buy','Sell','SellShort','CoverShort')
and		AssetType not in ('Cash','Financing')  
and		Commissions <> 0

  order by  2,1
