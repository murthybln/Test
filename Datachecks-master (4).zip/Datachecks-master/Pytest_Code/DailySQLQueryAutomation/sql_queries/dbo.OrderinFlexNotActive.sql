--Order in Flex Not Active
-- Daily
--Sev 2

SELECT 
			Distinct 
			cord_symbol,
			rec.TradingStatus,
			rec.RestrictedFromTrading
FROM		MaverickFlexTrade.dbo.CurrentSymbols s
Left Join	lspaldsql.smgc.client.reconview rec
on			rec.SecCode = s.cord_symbol
Where		Cord_symbol not in ('BEST.SP')
and			(rec.TradingStatus not in ('Active') 
or			RestrictedFromTrading = 'True')
