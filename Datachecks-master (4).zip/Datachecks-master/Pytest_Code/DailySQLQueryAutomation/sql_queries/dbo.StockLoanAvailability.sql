-- StockLoanAvailability
-- Daily
-- Sev-2

/*There is a sproc on MAVG-SQL in the Mav database:  Checks.spStockLoanAvailability

It checks if we received zero records today or if we received significantly fewer records today than the prior day (1500 tolerance).

It will return records only if it fails one of these conditions for any of the 7 brokers (BA, CG, CS, DB, GS, JP, MS).
*/


SET NOCOUNT ON; exec mav.Checks.spStockLoanAvailability

