SELECT     	inv.MasterSecID,
            inv.TradingStatus,
			inv.Sec_Code,
			replace(replace(eq.TICKER_AND_EXCH_CODE,' US',''),' ','.') as 'BBG_SECCODE',
			Case when replace(replace(eq.TICKER_AND_EXCH_CODE,' US',''),' ','.') <> inv.Sec_Code then 'N' else 'Y' end as 'IsSameSecCode', 
			eq.ID_BB_GLOBAL,
			inv.GLOBAL_ID,
			eq.ID_SEDOL1 as 'BBG_SEDOL1', 
			eq.ID_SEDOL2 as 'BBG_SEDOL2',
			inv.Sedol as 'PALD_SEDOL',
			Case when eq.ID_SEDOL1 <> inv.Sedol then 'N' else 'Y' end as 'IsSameSEDOL',
			eq.ID_ISIN as 'BBG_ISIN', 
			inv.ISIN as 'PALD_ISIN',
			Case when eq.ID_ISIN <> inv.ISIN then 'N' else 'Y' end as 'IsSameISIN',
			eq.ID_CUSIP as 'BBG_CUSIP',
			Inv.CUSIP as 'PALD_CUSIP',
			Case when eq.ID_CUSIP <> inv.CUSIP then 'N' else 'Y' end as 'IsSameCUSIP',
			eq.ID_CINS as 'BBG_CINS',
			inv.ID_CINS as 'PALD_CINS',
			Case when eq.ID_CINS <> inv.ID_CINS then 'N' else 'Y' end as 'IsSameCINS',
			eq.MARKET_STATUS as 'BBG_Status',
			inv.TradingStatus as 'PALD_STATUS'
			
From smgc.dbvw.Identifiers inv 	with (nolock)
Join BBGSecMaster.dbo.EQUITY_DESCRIPTIVE eq with (nolock)
on inv.GLOBAL_ID = eq.ID_BB_GLOBAL
where inv.GLOBAL_ID is not null

and
	   (isnull(eq.ID_SEDOL2,eq.ID_SEDOL1) <> inv.Sedol
		or eq.ID_ISIN <> inv.ISIN
		or eq.ID_CUSIP <> Inv.CUSIP
		or eq.ID_CINS <> inv.ID_CINS

		or eq.MARKET_STATUS is null
	
		or replace(replace(eq.TICKER_AND_EXCH_CODE,' US',''),' ','.') <> inv.Sec_Code
		)
and inv.TradingStatus not in ('Delisted','Acquired','Private Company','Expired')
and MasterSecID not in ('1383785','1407449','1426973','1412890','1442896')

order by 5