-- Gap Analysis gvkey/iid to mastersecid 
-- Sev 2
-- Daily


;WITH gvkeys AS 
       (
       SELECT DISTINCT gvkey, iid, dt
       FROM   Mavericksmgc.Reference.GVKeyIIDMasterSecIdMapping
       )
, AsOfRange AS 
       (
       SELECT        dt, gvkey, iid, DATEADD(day, -ROW_NUMBER() OVER (PARTITION BY gvkey, iid ORDER BY gvkey,iid, dt), DT) FirstDateChange
       FROM          gvkeys
       )
, Final AS (
                     SELECT        gvkey, iid, FirstDateChange
                                         , MIN(DT) MappingPeriodStart, max(dt) MappingPeriodEnd
                                         , COUNT(FirstDateChange) OVER (PARTITION BY gvkey, iid ORDER BY gvkey, iid) cnt
                     FROM          AsOfRange
                     GROUP BY      gvkey, iid, FirstDateChange
                     )
SELECT        *
FROM          Final
WHERE         cnt > 1
ORDER BY      cnt DESC, gvkey,iid, FirstDateChange
