SELECT TradingSymbol, count(TradingSymbol) [Num]
FROM mav.dbo.AllMavPositionHist 
WHERE HistDate = (Select max(HistDate) from  mav.dbo.AllMavPositionHist) 
		AND source = 'AMAV'
GROUP BY TradingSymbol 
HAVING COUNT(TradingSymbol)>1
	
