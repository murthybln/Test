
SELECT
		a.MasterSecID
		,a.Sec_Code
		,a.TradingStatus
		,Case when cp.MasterSecID is null then 'N'
		else 'Y' end as 'IsCurrentPosition'

  FROM		SMGC.dbvw.MIU a
  Left Join smgc.dbvw.CurrentPositions cp
  on		cp.MasterSecID = a.MasterSecID
  where		a.TradingStatus in ('Delisted','Acquired','Expired')