--Current MavSector equals SN
-- Daily
--Sev 3


Select 

	SecCode,
	MasterSecId,
	MavSector,
	AttributionSector,
	pl.IPO_Date,
	pl.Next_Date,
	pl.SectorHead

from lspaldsql.smgc.client.reconview rec
Left Join
	(SELECT 
		Distinct 
		min(AsOfDate) as 'IPO_Date',
		DateAdd(DAY,1,min(asOfDate)) as 'Next_Date',
		SecMasterID,
		securitycode,
		SecMavSector,
		SecAttributionSector,
		sh.SectorHead
       FROM Polaris.dbo.Polaris_PositionPnLBookDeNormalized p
	   Left Join (SELECT [SectorHead]
						,[SectorCode]
						,CONVERT(VARCHAR(10),[StartDate],120) [StartDate]
						,CONVERT(VARCHAR(10),[EndDate],120) [EndDate]
						,CONVERT(VARCHAR(10),[Ranking_StartDate],120) [RankingStartDate]
						,CONVERT(VARCHAR(10),[Ranking_EndDate],120) [RankingEndDate]
     
				FROM [Polaris].[dbo].[Polaris_Ref_SectorHead_Details]
				Where EndDate > '9999-01-01' and SectorHead not in ('Unassigned')) SH
				On SH.SectorCode = p.SecAttributionSector
	   Where SecMavSector = 'SN' and AsOfDate > GetDate() -10
	   and (LongQty <> 0 or ShortQty <> 0 or IVPGroup_Summary_AllRevExpDailyBook <> 0)
group by SecMasterID,
		securitycode,
		SecMavSector,
		SecAttributionSector,
		sh.SectorHead) pl
on		pl.SecMasterID = rec.MasterSecID
where	rec.MavSector = 'SN'
and		pl.SecMasterID is not null

	



