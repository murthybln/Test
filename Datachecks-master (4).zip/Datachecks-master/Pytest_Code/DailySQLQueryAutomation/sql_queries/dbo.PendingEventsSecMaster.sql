Declare @sd as Date = GetDate()
Declare @ed as Date = GetDate()+1
select		Distinct 
			CONVERT(VARCHAR(10),ev.CreateDate,101) as 'CreateDate',
			ev.RefClientID,
			smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as SEC_CODE,
			sec.MasterSecID,
			smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300007,GetDate()) as BLMBRG_ID,
			re.Description as 'ActionType',
			rs.Description as 'Status',
			cat.CodeName as 'Corporate Action Type'
			,ca.Msg as 'Reason'
			,ca.code
			
			
		
FROM		SMGC.dbo.Event ev with (nolock)
join		SMGC.dbo.RefEventAction re
on			re.RefEventActionID = ev.RefEventActionID
Join		smgc.dbo.RefEventStatus rs
on			rs.RefEventStatusID = ev.RefEventStatusID
Left Join	BBGSecMaster.etl.vwBBG_Corax ca
on			ca.EventID = ev.eventid
Left Join	smgc.dbo.RefCoraxEventCode cat
on			cat.code = ca.code
join		smgc.dbo.Sec sec
on			ev.secid = sec.secid
where		ev.RefEventStatusID in (2,4)
 			and 
			ev.CreateDate between  @sd and @ed
			--and re.Description  like 'Retrieve%'
			  and ca.code not in ('MEET','BBAK','DVST','LIST','OTHR','CPAR','DLST')
			  --and ca.Msg not like '%Cancel%'
			  and ca.Msg not like '%Discontinue%'
			--and sec.MasterSecID = '1297472'

