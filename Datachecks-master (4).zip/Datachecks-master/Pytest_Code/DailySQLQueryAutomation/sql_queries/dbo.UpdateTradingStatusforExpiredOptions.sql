-- Update Trading Status for Expired Options
-- Run Daily
-- Sev-3

Select MasterSecID,Sec_Code,UnderlyingSecCode,OptionExpirationDate, TradingStatus,CalcExpirationDate,
       case when OptionExpirationDate <> CalcExpirationDate then 'Y' else 'N' end as 'UpdateExpirationDate'


from 


(Select 
			sec.refsecTypeID,
			a.MasterSecID,
			Cast(Substring(Substring(Sec_Code,Len(UnderlyingSecCode) +1,6),0,3) +'-'+ Substring(Substring(Sec_Code,Len(UnderlyingSecCode)+1 ,6),3,2) +'-'+ Substring(Substring(Sec_Code,Len(UnderlyingSecCode)+1 ,6),5,2) as datetime)  CalcExpirationDate,
			InvestmentType,
			UnderlyingSecCode,
			OptionRedemType,
			OptionStrikePrice,	
			OptionExpirationDate,		
			Case when (datepart(dw,OptionExpirationDate) = 7) then OptionExpirationDate-1 else OptionExpirationDate end [CalcOptionExpirationDate],
			Case when RefSecTypeID = 62 
				then UnderlyingSecCode+right('0' + cast(MONTH(a.OptionExpirationDate-1) as varchar),2)+ right('0'+ cast(Day(a.OptionExpirationDate-1) as varchar),2)+right(cast(Year(a.OptionExpirationDate-1) as CHAR(4)),2)+a.OptionRedemType+convert(varchar(100),cast(a.OptionStrikePrice as float)) 
				when RefSecTypeID = 634 
				then UnderlyingSecCode+right('0' + cast(MONTH(a.OptionExpirationDate-1) as varchar),2)+ right('0'+ cast(Day(a.OptionExpirationDate-1) as varchar),2)+right(cast(Year(a.OptionExpirationDate-1) as CHAR(4)),2)+a.OptionRedemType+convert(varchar(100),cast(a.OptionStrikePrice as float))+'O' 
				else 'Missing' end [CalcSecCode],
		
			Sec_Code,
			BLMBRG_ID,
			BBG_ALT_ID,
			SecurityName,
			TradingStatus	
		
			
		

		from smgc.dbvw.investmentdetails a
		Join smgc.dbo.sec sec on sec.MasterSecID = a.MasterSecID
		where TradingStatus Not in ('Expired','Delisted') and InvestmentType in ('OOTC','LOPT')
	          and a.MasterSecID not in ('1397442','1397444')	
		) x

		where  CalcOptionExpirationDate < GetDate()-1


