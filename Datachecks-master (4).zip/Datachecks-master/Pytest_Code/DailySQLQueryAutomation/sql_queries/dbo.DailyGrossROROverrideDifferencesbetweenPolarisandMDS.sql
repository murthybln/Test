-- DailyGrossROROverride Differences between Polaris and MDS
-- Serv 4
-- Run Daily


SELECT
		 md.HistDate
		,pl.HistDate
		,md.EntityCode_Code
		,pl.EntityCode
		,md.GrossReturnCode_Code
		,pl.GrossReturnCode
		,md.OverrideColumn
		,pl.OverrideColumn
		,md.OverrideValue
		,pl.OverrideValue
    	
  FROM Polaris.dbo.Polaris_Performance_DailyGrossROROverride pl
  Full Outer Join lsBOBISQL.ReferenceData.mdm.DailyGrossROROverride md
  on	md.HistDate = pl.HistDate
  and   md.EntityCode_Code = pl.EntityCode
  and	md.GrossReturnCode_Code = pl.GrossReturnCode
  and	md.OverrideColumn = pl.OverrideColumn

  where round(md.OverrideValue,7) <> round(pl.OverrideValue,7)