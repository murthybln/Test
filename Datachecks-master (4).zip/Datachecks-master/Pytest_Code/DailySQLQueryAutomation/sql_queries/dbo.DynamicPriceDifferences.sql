Declare @sd as Date = Case when DatePArt(dw,GetDate()) = 2 then GetDate()-3 else GetDate()-1 end
Declare @ed as Date = GetDate()

Select 
	HistDate,
	DatePArt(dw,GetDate()),
	MasterSecID,
    Sec_Code,
	UnderlyingMasterSecID,
	UnderlyingSecCode,
	Underlying_Price_Local,
	StartingPriceMultiplier + ((1 - StartingPriceMultiplier)/TotalDays) * (TotalDays - DaysRemaining) as 'PriceMultiplier' ,
	Underlying_Price_Local * Round((StartingPriceMultiplier + ((1 - StartingPriceMultiplier)/TotalDays) * (TotalDays - DaysRemaining) ),6) as 'CalcPrice',
	Round(lpr.value,6) as 'PM_Price',
	Underlying_Price_Local * Round((StartingPriceMultiplier + ((1 - StartingPriceMultiplier)/TotalDays) * (TotalDays - DaysRemaining) ),6) - lpr.value as 'Difference'




From 


(Select
	Sb.MasterSecID,
	Sb.Sec_Code,
	Sb.UnderlyingMasterSecID,
	Sb.UnderlyingSecCode,
	pmf.DynamicPriceMultiplierStartDate as 'StartDate',
	pmf.DynamicPriceMultiplierEndDate as 'EndDate',
	pmf.DynamicPriceMultiplierStartingPriceMultiplier as 'StartingPriceMultiplier',
	convert(DateTime,lp.dayid,103) as 'HistDate',
	lp.value as 'Underlying_Price_Local',
	DateDiff(Day,pmf.DynamicPriceMultiplierStartDate,pmf.DynamicPriceMultiplierEndDate) as 'TotalDays',
	DateDiff(Day,convert(DateTime,lp.dayid,103),pmf.DynamicPriceMultiplierEndDate) as  'DaysRemaining',
	DynamicPriceMultiplierStartDate 


from		smgc.dbvw.Identifiers sb with (nolock)
Join		SMGC.primatemplates.PriceMasterFields pmf
on			pmf.MasterSecID = sb.MasterSecID
Join		PriceMaster.dbo.SecId sm 
on			sm.IdCode = Sb.UnderlyingMasterSecID 
and			sm.SecIdTypeId = '30007'
Join		PriceMaster.dbo.sec s 
on			s.SecId = sm.SecID
Left Join	PriceMaster.MarketValue.Data_RefSrc1_Price_Local lp
on			lp.SecId = S.SecID
and			convert(DateTime,lp.dayid,103) between @sd and @ed



where	InvestmentType = 'COMMON_R'
and		DynamicPriceMultiplierStartDate <= convert(DateTime,lp.dayid,103)
and		pmf.DynamicPriceMultiplierEndDate > convert(DateTime,lp.dayid,103)

) x

Join		PriceMaster.dbo.SecId sm 
on			sm.IdCode = x.MasterSecID 
and			sm.SecIdTypeId = '30007'
Join		PriceMaster.dbo.sec s 
on			s.SecId = sm.SecID
Left Join	PriceMaster.MarketValue.Data_RefSrc1_Price_Local lpr
on			lpr.SecId = S.SecID
and			convert(DateTime,lpr.dayid,103) = x.HistDate
Where		abs(Underlying_Price_Local * Round((StartingPriceMultiplier + ((1 - StartingPriceMultiplier)/TotalDays) * (TotalDays - DaysRemaining) ),6) - lpr.value) > .0001 
and			MasterSecID not in ('1416270')
	
