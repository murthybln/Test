-- No SecCode in any Watchlist
-- Hourly
-- Sev 1

select     Distinct 
			sec.MasterSecID, 
			sb.BLMBRG_ID,
			sb.InvestmentType,
			sb.RegionName,
			gics.Description [GICSIndustry_Name],
			sb.Exchange,
			sec.IssueTicker
			
			--CustAttr.Code as 'SecurityGroup'
from        smgc.dbo.Sec sec with (nolock)
Left Join	SMGC.client.SecBaseView sb
on			sb.secid = sec.secid
Left Join	SMGC.dbo.vw_SecIndustry secind with (nolock)
on			secind.SecID = sec.SecID 
and			secind.RefIndustryCodeID_GICS is not null
Left Join	smgc.dbo.vw_RefIndustryCode gics with (nolock)
on			gics.RefIndustryCodeID = secind.RefIndustryCodeID_GICS
Left Join   SMGC.dbo.SecAttribute attr with (nolock)
on          attr.SecID = sec.SecID
Left Join	SMGC.dbo.CustomAttribute CustAttr with (nolock)
on			CustAttr.CustomAttributeID = attr.CustomAttributeID 
Where		smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) is null
and			Attr.InDate is not null
and			Attr.OutDate is null
and			Attr.CustomAttributeID <> 1
and			sec.MasterSecID not in ('1303953','1412472','1412473','1412544','1412545','1388451')
and			sb.InvestmentType not in ('RGHT')

order by 2


