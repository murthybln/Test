-- DailyNetROROverride Differences between Polaris and MDS
-- Serv 4
-- Run Daily


SELECT
		 md.HistDate
		,pl.HistDate
		,md.EntityCode_Code
		,pl.EntityCode
		,md.NetReturnCode_Code
		,pl.NetReturnCode
		,md.OverrideColumn
		,pl.OverrideColumn
		,md.OverrideValue
		,pl.OverrideValue
    	
  FROM Polaris.dbo.Polaris_Performance_DailyNetROROverride pl
  Full Outer Join lsBOBISQL.ReferenceData.mdm.DailyNetROROverride md
  on	md.HistDate = pl.HistDate
  and   md.EntityCode_Code = pl.EntityCode
  and	md.NetReturnCode_Code = pl.NetReturnCode
  and	md.OverrideColumn = pl.OverrideColumn

  where md.OverrideValue <> pl.OverrideValue

