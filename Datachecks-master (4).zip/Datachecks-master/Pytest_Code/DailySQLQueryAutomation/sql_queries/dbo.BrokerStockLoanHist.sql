-- BrokerStockLoanHist
-- Daily
-- Sev-2



SET NOCOUNT ON; exec mav.Checks.spBrokerStockLoanHist

