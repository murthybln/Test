declare @ed DATE;
SET @ed = GetDate();
DECLARE @sd DATE;
SET @sd= DATEADD(day,-30,@ed)  
SELECT 

	p.PrimarySector
	,p.SecMavSector
	,p.ResourceType
	,p.SectorHead
	,p.securitycode
	,p.PrimarySymbol
	,Case when p.secinvestmenttypecode in ('TRS','BLLT') then sec.UnderlyingMasterSecId
			else p.SecMasterID
			end as 'MasterSecID'
	,SH.SectorHead as 'DefaultSectorHead'
	,Min(p.AsOfDate) as 'StartDate'
	
FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized p with (nolock)
Left Join	Polaris.dbo.Polaris_Security sec
on			sec.SecurityId = p.SecMasterID
	Left Join (SELECT [SectorHead]
						,[SectorCode]
						,CONVERT(VARCHAR(10),[StartDate],120) [StartDate]
						,CONVERT(VARCHAR(10),[EndDate],120) [EndDate]
						,CONVERT(VARCHAR(10),[Ranking_StartDate],120) [RankingStartDate]
						,CONVERT(VARCHAR(10),[Ranking_EndDate],120) [RankingEndDate]
     
				FROM [Polaris].[dbo].[Polaris_Ref_SectorHead_Details]
				Where EndDate > '9999-01-01' and SectorHead not in ('Unassigned')) SH
	On SH.SectorCode = p.SecMavSector
WHERE p.AsOfDate between @sd and @ed
and p.AsOfDate > '01/01/2023'
		and p.stratcode in ('LDC','LEV','USA','BUL','ELF','M02') 
		and p.secgenevaassettype not in ('Cash') 
		and PerfTotalPnLDailyBook <> 0
		and p.ResourceType = 'Public'
		and p.securitycode not in ('1005722Q','UBER','UBER_R','UBERX','WORKX','WORK_X','UBER_X','WORKYC','LGFTY','SCHALLOCATION','ASO','DKS')
		and sh.SectorHead <> p.SectorHead
group by
	p.SectorHead
	,p.PrimarySector
	,p.SecMavSector
	,p.ResourceType
	,p.securitycode
	,SH.SectorHead
	,p.PrimarySymbol
	,Case when p.secinvestmenttypecode in ('TRS','BLLT') then sec.UnderlyingMasterSecId
			else p.SecMasterID
			end
