-- LongShortNet is Long and Short for Investment Group by Portfolio 


Declare @sd as Date = GetDate() -60
Declare @ed as Date = GetDate() -1

Select 
		p.AsOfDate,
		p.SecInvestmentGroup_TS as 'InvGroup',
		p.Portfolio,
		p.Stratcode,
        p.LongShortNet,
		Round(sum(p.LongQty),6) as 'LongQty',
		Round(sum(p.ShortQty),6) as 'ShortQty',
		Round(sum(p.NetQuantity),6) as 'NetQty',
		Round(sum(p.AssetAllocation_MarketValueBook),0) as 'AssetAllocation_MarketValueBook',
		Round(sum(p.PerfTotalPnLDailyBook),2) as 'PerfTotalPnLDailyBook'

From	Polaris.dbo.Polaris_PositionPnLBookDeNormalized p

Join 

(Select a.AsOfDate,
		a.InvGroup,
		a.Portfolio,
		Case	when Count(*) > 1 
				then 'Yes' Else 'No' 
				end as LongAndShort

From


(SELECT Distinct
		AsOfDate,
		SecInvestmentGroup_TS as 'InvGroup',
		portfolio,
        LongShortNet

FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized
Where		AsOFDate between @sd and @ed 
and			Portfolio not in ('LDC','USA')
and			secgenevaassettype not in ('Cash','Financing') 
and			(PerfTotalPnLDailyBook > .01 or PerfTotalPnLDailyBook < -.01 or LongQty > 0 or ShortQty < 0)
)a

	   Group by a.InvGroup,a.Portfolio,a.AsOfDate
	   Having Count(*) > 1
) x
on		x.AsOfDate = p.AsOfDate
and		x.portfolio = p.portfolio
and		x.InvGroup = p.SecInvestmentGroup_TS
Where 	(PerfTotalPnLDailyBook > .01 or PerfTotalPnLDailyBook < -.01 or LongQty > 0 or ShortQty < 0)
Group by
		p.AsOfDate,
		p.SecInvestmentGroup_TS,
		p.portfolio,
		p.stratcode,
        p.LongShortNet
	