-- Gap Analysis  mastersecid to gvkey/iid 
-- Sev 2
-- Daily


; WITH MasterSecIDs AS 
       (
       SELECT DISTINCT MasterSecID, dt
       FROM   Mavericksmgc.Reference.GVKeyIIDMasterSecIdMapping
       )
, AsOfRange AS 
       (
       SELECT        dt, MasterSecID, DATEADD(day, -ROW_NUMBER() OVER (PARTITION BY MasterSecID ORDER BY MasterSecID, dt), DT) FirstDateChange
       FROM          MasterSecIDs
       )
, Final AS (
                     SELECT        MasterSecID, FirstDateChange
                                         , MIN(DT) MappingPeriodStart, max(dt) MappingPeriodEnd
                                         , COUNT(FirstDateChange) OVER (PARTITION BY MasterSecID ORDER BY MasterSecID) cnt
                     FROM          AsOfRange
                     GROUP BY      MasterSecID, FirstDateChange
                     )
SELECT        *
FROM          Final
WHERE         cnt > 1
ORDER BY      cnt DESC, MasterSecID, FirstDateChange
