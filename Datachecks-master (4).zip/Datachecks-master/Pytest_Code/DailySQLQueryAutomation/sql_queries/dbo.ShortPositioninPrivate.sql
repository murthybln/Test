 
 SELECT 
	Distinct 
 	AsOfDate,
 	Portfolio,
	stratcode,
	SecMasterID,
 	a.SecurityCode,
	a.SecInvestmentGroup_TS,
	u.SecurityCode as 'UnderlyingSecurityCode',
	a.MavPriceLocal,
	sec.StrikePrice,
	sec.OptionContractSize,
	sec.OptionRedemType,
	sec.ExpirationDate,
	udf.[UDF Value] as 'RelatedPartyMember'
	


	


FROM		Polaris.dbo.Polaris_PositionPnLBookDeNormalized  a with (nolock)
Join		Polaris.dbo.Polaris_Security sec
on			sec.SecurityId = a.SecMasterID
Join		Polaris.dbo.Polaris_Security u
on			u.SecurityId = sec.UnderlyingMasterSecId 
Left Join	Polaris.dbo.Polaris_UDF udf
on			udf.[Entity Id] = sec.LegalEntity
and			udf.[UDF Name] = 'Related Party Member'
and			udf.FromDate <= a.AsofDate
and			udf.ToDate >= a.AsOfDate
Where		AsOfDate = (Select max(AsOfDate) from Polaris.dbo.Polaris_PositionPnLBookDeNormalized)
and			(ShortQty <> 0 or LongQty <> 0 ) 
and			secinvestmenttypecode in ('OOTC','LOPT','WRNT')
order by	ExpirationDate 
