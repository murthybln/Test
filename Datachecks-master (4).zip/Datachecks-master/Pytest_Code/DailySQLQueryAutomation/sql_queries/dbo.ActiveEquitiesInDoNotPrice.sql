

Select 
convert(varchar(100), CONVERT (INT,a.MasterSecID )) [MasterSecID],
a.SecCode


from			SMGC.client.ReconView a with (nolock)
	Left Join	SMGC.dbo.sec sec with (nolock)
	on			sec.MasterSecID = a.MasterSecID 
	Left Join	smgc.dbo.UDF_Miscellaneous_0 msc with (nolock)
	on			msc.SecID = sec.SecID

where 
			isjunksecuritygroup not in ('TR','JUNK')
	and		TradingStatus not in ('Delisted','Excluded','Matured','Ticker Change','Price Not Available','Restricted')
	and		RegTypeName not in ('Private','Exclude')
	and		SecType in ('Equity','Depository Receipt','Equity Unit','Equity Unit') 
	and		a.MasterSecId not in ('1285295','1283857','1383655','1387341','1288547','1288567','1401969','1399981','1398255','1398254','1397581') 
	and		a.SecCode is not null
	AND		datepart(dw,GetDate()) not in (1,7)

	and		a.MasterSecID in 
				(	Select Distinct sec.MasterSecID
					from		SMGC.dbo.SecAttribute a
						Join	SMGC.dbo.CustomAttribute CustAttr
						on		CustAttr.CustomAttributeID = a.CustomAttributeID
						join	smgc.dbo.Sec sec
						on		sec.SecID = a.SecID
					where		CustAttr.Name = 'Do not Price' and OutDate is null)
