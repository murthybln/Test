declare @ed DATE;
SET @ed = GetDate();
DECLARE @sd DATE;
SET @sd= DATEADD(month,-12,@ed)  




Select 
Distinct
	tr.GenevaTransactionId as 'TransactionId',
	tr.GenevaTradeDate as 'TradeDate',
	tr.GenevaSymbol as 'Symbol',
	tr.GenevaPrimaryBroker as 'PrimaryBroker', 
	tr.GenevaBroker as 'Broker', 
	tr.GenevaCommRegion as 'CommRegion', 
	--tr.GenevaBrokerType,
	tr.FirmType,
	tr.CAPSExecDeskType_Desc,
	--cap.CommissionRegion,
	tr.GenevaProductType as 'ProductType',
	
 case when tr.GenevaBroker is null then 'Missing Broker'
       when tr.CAPSExecDeskType_Desc is null then 'Broker Mapping Not Setup in Caps'
	   else '' end as 'Comments'
	    
from
		(select
				Distinct  
					GenevaPrimaryBroker, 
					GenevaBroker, 
					GenevaCommRegion, 
					Case GenevaProductType
						When 'Swap' then 'Equity'
						When 'Swaption' then 'Equity'
						Else GenevaProductType end as 'GenevaProductType',

					GenevaInvestmentType,
					GenevaBrokerType,
					FirmType,
					GenevaExchangeType,
					GenevaSymbol,
					GenevaTradername,
					GenevaTransactionType,
					CAPSExecDeskType_Desc,
					GenevaTransactionId,
					GenevaTradeDate
				from mav.dbo.TradeView t
		where 
			GenevaTradeDate between @sd and @ed
			and GenevaExchangeType not in ('PVT','Private')
			and GenevaInvestmentType not in ('CMSV','MMKT','INT','CASH_R')
			and GenevaAssetType not in ('Financing','Cash')
				and GenevaTransactionType in ('Buy','Sell','CoverShort','SellShort')
				and GenevaBrokerType not in ('REBAL','REORG','OTHER')
				and GenevaTradername not in ('HFA','REORG','PVT','JM')
				and GenevaBroker not in ('CROSS','ROL','PVT')
				and GenevaPortfolio not in ('GRO','MDI')
				) tr
		Left Join 
		(SELECT 
			Distinct
				dsk.ExecDesk_RollupCode [RollupBroker]
			,Case When reg.Name = 'US' then 'U.S.' else reg.Name end [CommissionRegion]
				,pt.ProductType_Desc [ProductType]
				,dt.ExecDeskType_Desc
			FROM MavNY.dbo.ExecutionDesk dsk
			Left Join  MavNY.dbo.BusinessRegion br on br.BusinessRegion_Id = dsk.BusinessRegion_Id
			Left  Join MavNY.dbo.Region reg
				on reg.ID = br.Region_Id
			Left Join MavNY.dbo.ProductType pt
				on pt.ProductType_Id = dsk.ProductType_Id
			Left Join MavNY.dbo.ExecutionDeskType dt on dt.ExecDeskType_Id = dsk.ExecDeskType_Id
	Where dsk.ExecDesk_RollupCode is not null 
) cap on cap.RollupBroker = tr.GenevaBroker 
and cap.CommissionRegion = tr.GenevaCommRegion 
and cap.ProductType = tr.GenevaProductType
Where cap.CommissionRegion is null
and tr.GenevaBroker <> '' 
and tr.GenevaBroker is not null
--and datepart(dw,GetDate()) not in (1,7)
--and tr.CAPSExecDeskType_Desc is not null
order by 1,2,3

