SELECT 
		q.Mastersecid ,
		q.gvkey ,
		q.iid ,
		'01/01/1990' as 'StartDate',
		'12/31/2899' as 'EndDate' 
FROM	MavCapIQ.dbo.vwCurrentGVKeyIIDMasterSecIDMapping q with (nolock) 
wHERE   NOT EXISTS (SELECT * FROM lspaldsql.mavericksmgc.[Quant].[SecuritiesWithGvKeyIID] p 
					WHERE p.mastersecid = q.mastersecid)