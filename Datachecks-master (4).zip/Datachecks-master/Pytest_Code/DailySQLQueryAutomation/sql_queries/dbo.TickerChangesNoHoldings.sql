Declare @sd as Date = GetDate()
Declare @ed as Date = GetDate()+1


SELECT DIstinct 
		convert(varchar(100), CONVERT (INT,si.SecID)) [SecID]
		,convert(varchar(100), CONVERT (INT,s.MasterSecID )) [MasterSecID]
		,st.TypeName as 'SecTypeName'
		,si.IdStartDate
		,si.SecIdCodeTypeId
		,sit.CodeTypeName as 'SecIdCodeTypeName'
		,si.SecCode as 'New BLMBRG_ID',
		isnull(tl.symbol,tl2.Symbol) as 'HoldingsSymbol',
		inv.Symbol as 'Current SecCode'



FROM		LSPALDSQL.SMGC.dbo.SecIdCode si
Join		LSPALDSQL.SMGC.dbo.RefSecIDCodeType sit 
on			sit.SecIDCodeTypeID = si.SecIdCodeTypeId
Join		LSPALDSQL.smgc.dbo.sec s 
on			s.secid = si.secid
Join	    LSPALDSQL.SMGC.dbo.RefSecType st 
on			st.RefSecTypeId = s.RefSecTypeID
Join		mav.dbo.investment inv 
on			inv.mastersecid = s.mastersecid
Left Join	mav.dbo.TaxLotPositionHist tl 
on			tl.symbol = inv.symbol 
and			HistDate = @ed
Left Join	mav.dbo.TaxLotPositionHist tl2 
on			inv.UnderlyingSymbol = tl2.Symbol 
and			tl2.HistDate = @ed
where		sit.CodeTypeName in ('SEC_CODE','BLMBRG_ID')
and			s.RefSecTypeID not in ('1','2','3','801','401')
and			si.IdStartDate between @sd and @ed
and			replace(replace(si.SecCode,' US',''),' ','.') <> inv.Symbol
and			tl.symbol is null 
and			tl2.Symbol is null
and			s.MasterSecID not in ('1293578')
Order by 4
