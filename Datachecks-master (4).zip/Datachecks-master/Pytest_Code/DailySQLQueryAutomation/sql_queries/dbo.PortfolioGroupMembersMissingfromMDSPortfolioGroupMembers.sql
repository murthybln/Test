
SELECT 
     
			 pg.Code as 'PortfolioGroup_MAVG'
			,pgs.code as 'PortfolioGroup_MDS'
			,p.Code as 'Portfolio_MAVG'
			,mds.GroupPortfolio_Code as 'Portfolio_MDS'
			,pgs.PortfolioGroupType_Code as 'PortfolioGroupType'
			,CONVERT(VARCHAR(10),pgm.EffectiveStartDate,101) as 'EffectiveStartDate'
			,CONVERT(VARCHAR(10),EffectiveEndDate,101) as 'EffectiveEndDate'
   
FROM				Mav.dbo.PortfolioGroupMembers pgm
join				Mav.dbo.PortfolioGroups pg on pg.id = Pgm.PortfolioGroupID
join				Mav.dbo.Portfolios p on p.ID = pgm.PortfolioID
Full outer	Join	lsbobisql.ReferenceData.mdm.PortfolioGroupMembers mds
on					mds.GroupPortfolio_Code = pg.Code
and					mds.Portfolio_Code = p.code
and					mds.EffEndDate > GetDate()
full outer Join		lsbobisql.ReferenceData.mdm.PortfolioGroups pgs
 on					pg.Code = pgs.code
wHERE				(EffectiveEndDate > GetDate() -5 
or					EffectiveEndDate is null)
and 				pg.Code not in ('HEDGESERVTEST','AMAVEX','OLDAMAVX1','HES','MSF','MSP','STABLE','GENEVAPNL','HEDGESERVPRICES','MAV','ALL','Long','LongEnhanced','M01','M02','M03','MAV','Neutral')
and					p.code not in ('MSM','QNEOVER','UCQOVER','QESOVER','AMAVEX')
and					(mds.Portfolio_Code is null 
or					mds.GroupPortfolio_Code  is null)

order by			pg.Code

