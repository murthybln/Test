SELECT 
		Distinct 
		s.MasterSecID
		,sb.SecCode  
		,sb.GlobalID  
		,ISNULL(ritm.Value, rit.Code) InvestmentType
		,rts.Name TradingStatus
		,PriceList.Code PriceList
	
FROM		smgc.dbo.Sec s  with (nolock)
Left Join	Smgc.dbo.vw_SecBasic sb with (nolock)
on			sb.secid = s.Secid
LEFT JOIN	smgc.dbo.SecAuxCustomValues aux with (nolock)
ON			s.SecID = aux.SecID  
LEFT JOIN	smgc.dbo.RefInvestmentType rit with (nolock)
ON			aux.RefInvestmentTypeID = rit.RefInvestmentTypeID    
LEFT JOIN	smgc.dbo.RefInvestmentTypeCode ritm with (nolock)
ON			rit.RefInvestmentTypeID = ritm.RefInvestmentTypeID 
AND			ritm.RefExternalCodeTypeID = 2
LEFT JOIN	smgc.dbo.RefRegType reg with (nolock)
ON			aux.RefRegTypeID = reg.RefRegTypeID
LEFT JOIN	smgc.dbo.RefTradingStatus rts with (nolock)
ON			aux.RefTradingStatusID = rts.RefTradingStatusID
LEFT JOIN	(SELECT udf.secid, li.* from smgc.[dbo].[UDF_Miscellaneous_0] udf JOIN smgc.dbo.[UDF_RefMiscellaneousPriceList] li ON udf.[PriceList$Integer] = li.UDF_RefMiscellaneousPriceListID) PriceList ON s.SecID = PriceList.SecID
Where		PriceList.Code <> 'DoNotPrice'
and			ISNULL(ritm.Value, rit.Code) not in ('INT','CVTB','CMSV','PFD','PART','SV','CORB','CONVERTNOTE','TDEP','CONVERTNOTE','CASH_R','CORPNOTE') 
and			rts.Name in ('Delisted','Matured','InActive','Acquired') 
and			sb.MAsterSecID not in ('1418906')
and			sb.SecCode is not null

order by 3
