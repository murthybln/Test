-- New Sec Type
-- Daily
-- Sev 3

Select 
	 SecType,
	 AssetType,
	 InvestmentType,
	 SecCode,
	 MasterSecId

from	smgc.client.reconview rec
where SecType not in (SELECT Code from SMGC.dbo.UDF_RefCurrentSecTypes)

