--Mav Sector Changes
--Daily
--Sev 2


Declare @SD as Date = GetDate()-2
Declare @eD as Date = GetDate()


Select distinct
   
	   sec.MasterSecID
	   ,smgc.[dbo].[fn_GetActualIdentifier] (sec.SecId, 300019,GetDate()) as 'SEC_CODE'
	  ,ms.ChangeDate
      ,s.Code as 'MavSector'
	  ,CONVERT(VARCHAR(10),MavSectorDate$Date,101) as 'MavSectorDate'
      ,sh1.Code as 'SectorHead1'
	  ,sh2.code as 'SectorHead2'
	  ,u.Login as 'ChangedBy'
	  
	 
	 

FROM		[AuditSMGC].[dbo].[Audit_UDF_MavSector_0] ms
join		smgc.dbo.sec sec 
on			sec.secid = ms.secid
Left join	smgc.dbo.secidCode si
on			si.secid = ms.secid
and			si.SecIdCodeTypeId = '300019'
left join	smgc.dbo.RefAnalyst s 
on			s.RefAnalystID = ms.MavSector$Integer
Join		smgc.dbo.UDF_RefSectorHead sh1 
on			sh1.UDF_RefSectorHeadID = ms.SHead1$Integer
Left Join	smgc.dbo.UDF_RefSectorHead sh2 
on			sh2.UDF_RefSectorHeadID = ms.SHead2$Integer
Left Join	smgc.dbo.[User] u 
on			u.UserID = ms.ChangedBy
where ms.SecId in 
		(Select SecId from [AuditSMGC].[dbo].[Audit_UDF_MavSector_0] where ChangeDate Between @sd and @ed)
and		MavSectorDate$Date is not null
and		CONVERT(VARCHAR(10),si.CreateDate,101) <> CONVERT(VARCHAR(10),ms.ChangeDate,101)


Order by 1,3 desc
   
   
   
   
 