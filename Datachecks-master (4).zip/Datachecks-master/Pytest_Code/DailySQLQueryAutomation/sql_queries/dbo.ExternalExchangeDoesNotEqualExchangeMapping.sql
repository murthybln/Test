

Select 
	recon.SecCode,
	recon.MasterSecID,
	recon.BloombergExchangeCode,
	recon.Exchange,
	ext.Code as 'DefaultExchangeCode',
	ext.Description as 'DefaultExchangeName'

from smgc.client.reconview recon
	Left Join SMGC.dbo.RefExchange ex
		on ex.Code = recon.BloombergExchangeCode
	Left Join [SMGC].[dbo].[ExchangeMapping] mp
		on mp.RefExchangeID = ex.RefExchangeID
	Left Join SMGC.dbo.RefExternalExchange ext
		on ext.RefExternalExchangeID = mp.RefExternalExchangeID
Where	recon.BloombergExchangeCode not like 'OTC%' 
		and recon.Exchange <> ext.Code and AssetType not in ('Cash','Index','Financing','Bond','Swap')
		and TradingStatus not in ('Delisted') 
		and recon.Exchange NOT IN ('LI','LO','GQ')
		and datepart(dw,GetDate()) not in (1,7)