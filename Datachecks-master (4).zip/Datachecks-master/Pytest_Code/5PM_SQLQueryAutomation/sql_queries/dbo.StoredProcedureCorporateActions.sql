Declare @sd as Date = GetDate()
Declare @ed as Date = GetDate()+3

SET NOCOUNT ON; exec [MaverickSMGC].dbo.[spGetCorporateActions] @sd,@ed

