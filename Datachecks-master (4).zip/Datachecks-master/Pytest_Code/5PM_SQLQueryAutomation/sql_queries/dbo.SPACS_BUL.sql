Declare @dt as Date = GetDate()

(SELECT 
       e.HistDate
      ,e.AMAVSymbol
      ,e.EntityCode
	  ,REPLACE(CONVERT(VARCHAR,CAST(e.Quantity AS MONEY), 1),'.00', '') as 'Quantity'
   	  ,a.MarketPrice
	  ,REPLACE(CONVERT(VARCHAR,CAST(ROUND(e.MarketValue,0) AS MONEY), 1),'.00', '') as 'MarketValue'
	  ,a.ExposureMult
	 ,REPLACE(CONVERT(VARCHAR,CAST(ROUND((e.MarketValue* a.ExposureMult),0) AS MONEY),1), '.00','') as 'AmavMarketValue'
	 ,REPLACE(CONVERT(VARCHAR,CAST(ROUND((e.MarketValue-(e.MarketValue* a.ExposureMult)),0) AS MONEY),1), '.00','') as 'MarketValueDifference'
	 ,inv.InvType
	  ,Case when sp.IsSPAC = 1 then 'Yes' else 'No' end as 'IsSPAC'	 
      
FROM		Mav.dbo.AllMavPositionHistByEntityView e
Join		Mav.dbo.AllMavPositionHistView a
on			a.HistDate = e.HistDate
and			a.AMAVSymbol = e.AMAVSymbol
and			a.PosType = e.PosType
Left Join   mav.dbo.Investment inv
on			inv.InvId = a.InvID
Left Join	lspaldsql.smgc.dbo.Sec sec with (nolock)
on			sec.MasterSecID = inv.MasterSecID
Left Join	lspaldsql.[SMGC].[dbo].[UDF_Miscellaneous_0] sp with (nolock)
on			sp.SecID = sec.SecID 


where		e.HistDate = @dt
--and			(Select convert(varchar, DateTimeValue, 101) as 'CoseDate' FROM mav.dbo.Settings WHERE Code = 'AMAVDoneForDay') = @dt
and			e.EntityCode = 'BUL'
and		    (sp.IsSPAC = '1'
or			a.ExposureMult <>  1)
and			inv.Product not in ('OP')
and			inv.InvType not in ('CDS','CDX','MMKT')) 

Union All 





(SELECT 
       
	   e.HistDate
      ,'Grand Total' as AMAVSymbol
      ,e.EntityCode
      ,null as 'Quantity'
	  ,null as 'MarketPrice'
	  ,REPLACE(CONVERT(VARCHAR,CAST(ROUND(SUM(e.MarketValue),0) AS MONEY), 1),'.00', '') as 'MarketValue'
	  ,null as 'ExposureMult'
	       
	  --,Round(sum((e.MarketValue* a.ExposureMult)),0) as 'AmavMarketValue'
	  ,REPLACE(CONVERT(VARCHAR,CAST(ROUND(SUM(e.MarketValue* a.ExposureMult),0) AS MONEY),1), '.00','') as 'AmavMarketValue'
	  ,REPLACE(CONVERT(VARCHAR,CAST(ROUND(SUM(e.MarketValue-(e.MarketValue* a.ExposureMult)),0) AS MONEY),1), '.00','') as 'MarketValueDifference'
	 -- ,Round(sum(e.MarketValue-(e.MarketValue* a.ExposureMult)),0)  as 'MarketValueDifference'
	  , '' as 'InvType'
	  ,'' as 'IsSPAC'
      
FROM		Mav.dbo.AllMavPositionHistByEntityView e
Join		Mav.dbo.AllMavPositionHistView a
on			a.HistDate = e.HistDate
and			a.AMAVSymbol = e.AMAVSymbol
and			a.PosType = e.PosType
Left Join   mav.dbo.Investment inv
on			inv.InvId = a.InvID
Left Join	lspaldsql.smgc.dbo.Sec sec with (nolock)
on			sec.MasterSecID = inv.MasterSecID
Left Join	lspaldsql.[SMGC].[dbo].[UDF_Miscellaneous_0] sp with (nolock)
on			sp.SecID = sec.SecID 


where		e.HistDate = @dt
--and			(Select convert(varchar, DateTimeValue, 101) as 'CoseDate' FROM mav.dbo.Settings WHERE Code = 'AMAVDoneForDay') = @dt
and			e.EntityCode = 'BUL'
and		    (sp.IsSPAC = '1'
or			a.ExposureMult <>  1)
and			inv.Product not in ('OP')
and			inv.InvType not in ('CDS','CDX','MMKT')

Group by
	  e.HistDate
      ,e.EntityCode) 




