Declare @date DATE = GetDate()+1

SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#box') IS NOT NUlL
BEGIN
	DROP TABLE #box
END

IF OBJECT_ID('tempdb..#tbox') IS NOT NUlL
BEGIN
	DROP TABLE #tbox
END
Select	
			HistDate,
			PrimarySymbol,
			EntityCode
into #box				
from 
		(SELECT			Distinct 
						HistDate,
						a.Symbol,
						isnull(i.underlyingSymbol,i.Symbol) as 'PrimarySymbol',
						EntityCode,
						Case 
							when Quantity < 0 then 'S'
							When Quantity > 0 then 'L'
							Else 'LS' end as 'PosType',
						Quantity
		FROM		mav.dbo.TaxLotPositionHist a with (nolock)
		Left Join   mav.dbo.Investment i 
		on			i.Symbol = a.symbol
		and			i.InvType not in ('Hedge','FDWFX')
		Where	a.HistDate = @date) ps
Group by
			HistDate,
			--Symbol,
			PrimarySymbol,
			EntityCode
Having 
		sum(Case 
				When PosType = 'L' then Quantity
				else 0 end) <> 0
and		sum(Case 
				When PosType = 'S' then Quantity
				else 0 end)  <> 0 
Select	
			HistDate,
			PrimarySymbol,
			EntityCode
into #tbox				
from 
		(SELECT			Distinct 
						HistDate,
						--a.Symbol,
						isnull(i.underlyingSymbol,i.Symbol) as 'PrimarySymbol',
						EntityCode,
						Case 
							when Quantity < 0 then 'S'
							When Quantity > 0 then 'L'
							Else 'LS' end as 'PosType',
						Quantity
		FROM	mav.dbo.TaxLotPositionHist a with (nolock)
		Left Join   mav.dbo.Investment i 
		on			i.Symbol = a.symbol
		and			i.InvType not in ('Hedge','FDWFX')
		Where	a.HistDate = @date) ps
Group by
			HistDate,
			PrimarySymbol,
			EntityCode
Having 
		sum(Case 
				When PosType = 'L' then Quantity
				else 0 end) <> 0
and		sum(Case 
				When PosType = 'S' then Quantity
				else 0 end)  <> 0 






Select
		tl.HistDate,
		tl.Symbol,
		case when i.UnderlyingSymbol is null then i.Symbol else i.UnderlyingSymbol end as 'PrimarySymbol',
		tl.EntityCode,
		tl.Strategy,
		cust.PrimeBroker,
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity > 0 then Quantity
				else 0 end) 
				AS MONEY), 1),'.00', '') as LongQuantity,
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity < 0 then Quantity
				else 0 end) 
				AS MONEY), 1),'.00', '') as ShortQuantity,
		max(Price) as 'Price',
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity > 0 then (tl.Quantity *isnull(price,0))
				else 0 end) 
				AS MONEY), 1),'.00', '') as 'Long Market Value',
		
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity < 0 then (tl.Quantity *isnull(price,0))
				else 0 end) 
				AS MONEY), 1),'.00', '') as 'Short Market Value',
				REPLACE(CONVERT(VARCHAR,CAST(sum(tl.Quantity *isnull(price,0)) AS MONEY), 1),'.00', '') as 'NetMarketValue'



		
		


		
FROM	mav.dbo.TaxLotPositionHist tl with (nolock) 
Join	mav.dbo.CustAccountView cust
on		cust.CustAccount = tl.CustAccount
Join    mav.dbo.Investment i
on		i.symbol = tl.Symbol

Join	#box bx
on		bx.HistDate = tl.HistDate
and		bx.EntityCode = tl.EntityCode
and		bx.PrimarySymbol = case when i.UnderlyingSymbol is null then i.Symbol else i.UnderlyingSymbol end
Where	tl.HistDate = @date 
and		bx.EntityCode = 'LEV'
	


Group by
	    tl.HistDate,
		tl.EntityCode,
		case when i.UnderlyingSymbol is null then i.Symbol else i.UnderlyingSymbol end ,
		tl.Symbol,
		cust.PrimeBroker,
		tl.Strategy
Union ALL
Select
		tl.HistDate,
		'Grand Total' as 'Symbol',
		'' as 'PrimarySymbol',
		tl.EntityCode,
		tl.Strategy,
		'' as 'PrimeBroker',
		null as LongQuantity,
		null  as ShortQuantity,
		null as 'Price',
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity > 0 then (tl.Quantity *isnull(price,0))
				else 0 end) 
				AS MONEY), 1),'.00', '') as 'Long Market Value',
		
		REPLACE(CONVERT(VARCHAR,CAST(
				SUM(Case 
				When Quantity < 0 then (tl.Quantity *isnull(price,0))
				else 0 end) 
				AS MONEY), 1),'.00', '') as 'Short Market Value',
				REPLACE(CONVERT(VARCHAR,CAST(sum(tl.Quantity *isnull(price,0)) AS MONEY), 1),'.00', '') as 'NetMarketValue'
FROM	mav.dbo.TaxLotPositionHist tl with (nolock) 
Join	mav.dbo.CustAccountView cust
on		cust.CustAccount = tl.CustAccount
Join    mav.dbo.Investment i
on		i.symbol = tl.Symbol
Join	#tbox bx
on		bx.HistDate = tl.HistDate
and		bx.EntityCode = tl.EntityCode
and		bx.PrimarySymbol = (case when i.UnderlyingSymbol is null then i.Symbol else i.UnderlyingSymbol end)
Where	tl.HistDate = @date 
and		bx.EntityCode = 'LEV'


Group by
	    tl.HistDate,
		tl.EntityCode,
		--tl.Symbol,
		--cust.PrimeBroker,
		tl.Strategy
