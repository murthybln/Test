-- Missing Avg Daily Vol for Tax Lot Holdings
-- Daily 
-- Sev 2

DECLARE @dt DATE = GETDATE()


select 
		
			distinct 
			@dt as 'PriceDate',
			s2.PrimarySymbol as Symbol , 
			--s2.SecCode,
			si.secid,
			s2.Country, 
			s2.TradingZone,
			s2.InvestmentType,
			s2.TradingStatus,
			Case When hc.Country is null then 'No' else 'Yes' end as 'IsTradingHoliday',
			pl.value [Price_Local],
			REPLACE(CONVERT(VARCHAR,CAST(dv.value AS MONEY), 1),'.00', '') as 'AvgDailyVol'

		
from		mav.dbo.TaxLotPositionHist s1 with (nolock) 	
Left Join	lsPALDSQL.smgc.client.reconview s2 with (nolock)
on			s2.SecCode = s1.Symbol 
left Join	lspaldsql.PriceMaster.dbo.SecId si 
on			si.IdCode = s2.PrimarySymbol 
and			si.SecIdTypeId = '30010'
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_Price_Local pl
on			pl.SecID = si.secid 
and			convert(DateTime,pl.dayid,103)  = @DT
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_AvgDailyVol dv
on			dv.SecID = si.secid 
and			convert(DateTime,dv.dayid,103)  = @DT

Left Join   mav.FinancialCalendar.HolidayCalendarByCountryView hc
on			hc.Country = s2.Country
and			hc.HolidayDate = @dt
and			hc.Type = 'SE Trading'
Where		s1.HistDate =  @dt 
and         s2.PvtType = 'None'
and			s2.InvestmentType not in ('BKDT','MMKT','CDS')
and         s2.GroupID not in ('GOVT-US','LGFTY','SCHALLOCATION','IBOXHYSE')
and			s2.PrimarySymbol not in ('COUPANGCCY','RR/.LN-C','1005722Q','BEST.SP')
and			hc.Country is null
and			dv.value is null
and			s2.TradingStatus not in ('Unlisted','Delisted','Expired','Matured')
and         si.secid not in ('357755','355348','373125')
and			pl.value is not null
order by 2,1,6 desc, 4,3