Declare @dt as Date  = (Select max(HistDate) from mav.dbo.TaxLotPositionHist)

SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#temp') IS NOT NUlL
BEGIN
	DROP TABLE #temp
END

Select
		tl.HistDate,
		
		tl.EntityCode as 'Portfolio',
		tl.Symbol,
	    sb.INTERNAL_SECURITY_NAME AS 'SecurityName',
		sb.InvestmentType,
		inv.Product as 'AssetType',
		cust.PrimeBroker as 'Custodian',
		tl.Strategy,
		sb.CurrencyCode,
		Case When Quantity > 0 then 'Long' else 'Short' end as 'LongShortGross',
		Sum(Quantity) as 'NetQuantity',
		max(Price) as 'BookPrice',
		Case when sb.InvestmentType in ('TRS','BLLT') then 
				SUM(tl.Quantity *isnull(price,0)*isnull(sb.PriceMultiplier,1)) 
				else sum(tl.MarketValue) end 
			 as 'MarketValueBook',
		cust.AccountType,
		tl.CustAccount,
		sb.PvtType,
		tl.LoadDateTime
into #temp		
			
FROM		mav.dbo.TaxLotPositionHist tl with (nolock) 
Join		lspaldsql.smgc.dbvw.securitybuilder sb
on			sb.Sec_Code = tl.Symbol
Join		mav.dbo.CustAccountView cust
on			cust.CustAccount = tl.CustAccount
Left Join	mav.dbo.Investment inv
on			inv.Symbol = tl.symbol
Where		tl.HistDate = @dt
and			tl.Strategy = 'LEV'
AND			(sb.PvtType Not IN ('None') or cust.AccountType = 'Pvt')
AND			sb.investmenttype Not IN ('CDS')
and			sb.ResourceType not in ('Portfolio')

Group by 
			tl.HistDate,
			tl.Symbol,
			tl.EntityCode,
			tl.Strategy,
			tl.CustAccount,
			cust.PrimeBroker,
			inv.Product,
			sb.INTERNAL_SECURITY_NAME,
			sb.InvestmentType,
			sb.CurrencyCode,
			Case When Quantity > 0 then 'Long' else 'Short' end,
			cust.AccountType,
			sb.PvtType,
			tl.LoadDateTime

-----------
Select 
		HistDate,
		Portfolio,
		Symbol,
	    SecurityName,
		InvestmentType,
		AssetType,
		Custodian,
		Strategy,
		CurrencyCode,
		LongShortGross,
		REPLACE(CONVERT(VARCHAR,CAST(NetQuantity AS MONEY), 1),'.00', '') as 'NetQuantity' ,
		BookPrice,
		REPLACE(CONVERT(VARCHAR,CAST(MarketValueBook AS MONEY), 1),'.00', '') as 'MarketValueBook' ,
		AccountType,
		CustAccount,
		PvtType,
		LoadDateTime
From #temp

Union all 

	Select 
		HistDate,
		Portfolio,
		'' as 'Symbol',
	    '' as 'SecurityName',
		'' as 'InvestmentType',
		'' as 'AssetType',
		'' as 'Custodian',
		'' as 'Strategy',
		'' as 'CurrencyCode',
		'' as 'LongShortGross',
		null as 'NetQuantity',
		null as 'BookPrice',
		REPLACE(CONVERT(VARCHAR,CAST(sum(MarketValueBook) AS MONEY), 1),'.00', '') as 'MarketValueBook' ,
		'' as 'AccountType',
		'' as 'CustAccount',
		'' as 'PvtType',
		'' as 'LoadDateTime'
From #temp
	
Group by HistDate,Portfolio
