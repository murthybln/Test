-- Missing Shares Outstanding for Tax Lot Holdings
-- Daily 
-- Sev 2

DECLARE @dt DATE = GETDATE()


select 
		
			distinct 
			@dt as 'PriceDate',
			s2.PrimarySymbol as Symbol , 
			--s2.SecCode,
			si.secid,
			s2.mastersecid,
			si.IdCode,
			s2.CountryCOde, 
			s2.TradingZone,
			s2.InvestmentType,
			s2.TradingStatus,
			Case When hc.Country is null then 'No' else 'Yes' end as 'IsTradingHoliday',
					REPLACE(CONVERT(VARCHAR,CAST(dv.value AS MONEY), 1),'.00', '') as 'SharesOutstanding'
,s2.UnderlyingInvestmentType
		
from		mav.dbo.TaxLotPositionHist s1 with (nolock) 	
Left Join	lsPALDSQL.smgc.dbvw.UserDefinedFields s2 with (nolock)
on			s2.Sec_Code = s1.Symbol 
left Join	lspaldsql.PriceMaster.dbo.SecId si 
on			si.IdCode = s2.PrimarySymbol 
and			si.SecIdTypeId = '30010'
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_Price_Local pl
on			pl.SecID = si.secid 
and			convert(DateTime,pl.dayid,103) = @dt
Left Join   lspaldsql.PriceMaster.MarketValue.Data_RefSrc1_EQY_SH_OUT_ACTUAL dv
on			dv.SecID = si.secid 
and			convert(DateTime,dv.dayid,103) = @dt
and         dv.dayid = pl.dayid



Left Join   mav.FinancialCalendar.HolidayCalendarByCountryView hc
on			hc.Country = case when s2.CountryCode = 'JE' then 'GB' else s2.CountryCOde end 
and			hc.HolidayDate = @dt
and			hc.Type = 'SE Trading'
Where		s1.HistDate =  @dt 
and         s2.PvtType = 'None'
and			s2.InvestmentType not in ('BKDT','MMKT','CDS','fxop','WTS','RIGHTS','HEDGE','Index','FDWFX','CCY','RATE','FUT','LOPT','OOTC')
and			s2.UnderlyingInvestmentType not in ('BKDT','MMKT','CDS','fxop','WTS','RIGHTS','Index','FUT','LOPT','OOTC')
and			hc.Country is null
and			dv.value is null
and			s2.TradingStatus not in ('Unlisted','Delisted','Expired','Matured')
order by 2,1,6 desc, 4,3