This folder consists of all the sql queries which are scheduld to run at 5 am daily.
