This folder consists of all the sql queries which are scheduld to run at 30mins interval daily.
