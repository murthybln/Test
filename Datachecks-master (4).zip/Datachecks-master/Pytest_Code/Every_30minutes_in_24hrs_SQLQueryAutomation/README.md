This job is scheduled to run every 30 mins intervals in a day.
